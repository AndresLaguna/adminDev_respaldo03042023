declare interface Window {
  // dataLayer is injected via vite-plugin-radar
  dataLayer?: any[]
}
