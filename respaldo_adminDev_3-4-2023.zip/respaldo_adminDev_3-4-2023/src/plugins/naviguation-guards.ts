import { GET_DATOS_USUARIO } from '/@src/services/general'
import { definePlugin } from '/@src/app'
import { onAuthStateChanged } from 'firebase/auth'
import { auth } from '/@src/services/config'
import { useUserSession } from '/@src/stores/userSession'

const userStore = useUserSession()

export default definePlugin(({ router }) => {
  router.beforeEach((to) => {
    if (to.meta.requiresAuth) {
      onAuthStateChanged(auth, (userAuth) => {
        if (userAuth) {
          GET_DATOS_USUARIO(userAuth.uid).then((user) => {
            if (
              user?.datosUsuario.rol === 'Entrenador' &&
              to.fullPath.includes('entrenador')
            ) {
              userStore.setUserData(
                user.datosUsuario,
                userAuth.uid,
                userAuth.email || '',
                'Entrenador',
                user?.datosUsuario.especial || ''
              )
              return {
                name: 'auth',
                query: { redirect: to.fullPath },
              }
            } else if (
              user?.datosUsuario.rol === 'Deportista' &&
              to.fullPath.includes('deportista')
            ) {
              userStore.setUserData(
                user.datosUsuario,
                userAuth.uid,
                userAuth.email || '',
                'Deportista',
                ''
              )
              return {
                name: 'auth',
                query: { redirect: to.fullPath },
              }
            } else if (
              user?.datosUsuario.rol === 'Admin' &&
              to.fullPath.includes('admin')
            ) {
              userStore.setUserData(
                user.datosUsuario,
                userAuth.uid,
                userAuth.email || '',
                'Admin',
                ''
              )
              return {
                name: 'auth',
                query: { redirect: to.fullPath },
              }
            } else {
              router.push('/')
            }
          })
        } else {
          router.push('/')
        }
      })
    }
  })
})
