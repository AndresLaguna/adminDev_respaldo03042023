<script setup lang="ts">
import { ref, reactive } from 'vue'
// import { useRouter, useRoute } from 'vue-router'

// import { useRouter } from 'vue-router'
import { useHead } from '@vueuse/head'

import { useDarkmode } from '/@src/stores/darkmode'
// import { useUserSession } from '/@src/stores/userSession'
import { useNotyf } from '/@src/composable/useNotyf'
import { RECUPERARCONTRA } from '/@src/services/auth'

const isLoading = ref(false)
const darkmode = useDarkmode()
// const route = useRoute()
const notif = useNotyf()
// const userSession = useUserSession()
// const redirect = route.query.redirect as string
const dataUser = reactive({
  name: '',
  passwd: '',
})

const handleLogin = async () => {
  const uid = await RECUPERARCONTRA(dataUser.name)
  console.log(uid)
  notif.success('cambio de contraseña')
}

useHead({
  title: 'Auth Recuperar - Vuero',
})
</script>

<template>
  <div class="auth-wrapper-inner columns is-gapless">
    <!-- Image section (hidden on mobile) -->
    <div class="column login-column is-8 h-hidden-mobile h-hidden-tablet-p hero-banner">
      <div class="hero login-hero is-fullheight is-app-grey">
        <div class="hero-body">
          <div class="columns">
            <div class="column is-10 is-offset-1">
              <img
                class="light-image has-light-shadow has-light-border"
                src="/@src/assets/illustrations/apps/vuero-banking-light.png"
                alt=""
              />
              <img
                class="dark-image has-light-shadow"
                src="/@src/assets/illustrations/apps/vuero-banking-dark.png"
                alt=""
              />
            </div>
          </div>
        </div>
        <div class="hero-footer">
          <p class="has-text-centered"></p>
        </div>
      </div>
    </div>

    <!-- Form section -->
    <div class="column is-4">
      <div class="hero is-fullheight is-white">
        <div class="hero-heading">
          <label
            class="dark-mode ml-auto"
            tabindex="0"
            @keydown.space.prevent="(e) => (e.target as HTMLLabelElement).click()"
          >
            <input
              type="checkbox"
              :checked="!darkmode.isDark"
              @change="darkmode.onChange"
            />
            <span></span>
          </label>
          <div class="auth-logo">
            <RouterLink :to="{ name: 'index' }">
              <AnimatedLogo width="36px" height="36px" />
            </RouterLink>
          </div>
        </div>
        <div class="hero-body">
          <div class="container">
            <div class="columns">
              <div class="column is-12">
                <div class="auth-content">
                  <h2>Recuperar contraseña</h2>
                  <p>Por favor ingresa tu correo para recuperar contraseña</p>
                  <RouterLink :to="{ name: 'auth-login' }">
                    Ya tengo una cuenta
                  </RouterLink>
                </div>
                <div class="auth-form-wrapper">
                  <!-- Login Form -->
                  <form @submit.prevent="handleLogin">
                    <div class="login-form">
                      <!-- Username -->
                      <VField>
                        <VControl icon="feather:user">
                          <VInput
                            v-model="dataUser.name"
                            type="text"
                            placeholder="Correo Electronico"
                            autocomplete="username"
                          />
                        </VControl>
                      </VField>
                      <!-- Submit -->
                      <div class="login">
                        <VButton
                          class="btn-degrade-blue"
                          :loading="isLoading"
                          color="primary"
                          type="submit"
                          bold
                          fullwidth
                          raised
                        >
                          Recuerar Contraseña
                        </VButton>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
