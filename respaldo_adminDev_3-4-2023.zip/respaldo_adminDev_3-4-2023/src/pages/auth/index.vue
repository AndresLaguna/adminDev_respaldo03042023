<route lang="yaml">
redirect:
  name: auth-login
</route>
