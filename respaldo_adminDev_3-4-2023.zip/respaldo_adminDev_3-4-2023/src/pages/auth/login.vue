<script setup lang="ts">
import { ref, reactive, computed } from 'vue'
// import { useRouter, useRoute } from 'vue-router'

import { useRouter } from 'vue-router'
import { useHead } from '@vueuse/head'

import { useDarkmode } from '/@src/stores/darkmode'
// import { useUserSession } from '/@src/stores/userSession'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { LOGIN_USER_PASSWD } from '/@src/services/auth'
import { GET_DATOS_USUARIO } from '/@src/services/general'

const isLoading = ref(false)
const darkmode = useDarkmode()
const router = useRouter()
// const route = useRoute()
const notif = useNotyf()
// const userSession = useUserSession()
// const redirect = route.query.redirect as string
const dataUser = reactive({
  name: '',
  passwd: '',
})

const validarSesion = computed(() => {
  if (dataUser.name.length < 1 || dataUser.passwd.length < 6) {
    return false
  }
  return true
})

const handleLogin = async () => {
  const uid = await LOGIN_USER_PASSWD(dataUser.name, dataUser.passwd)
  if (!isLoading.value) {
    isLoading.value = true

    await sleep(1500)

    if (uid) {
      notif.dismissAll()
      const datosUsuraio: any = await GET_DATOS_USUARIO(uid)
      if (datosUsuraio.datosUsuario.rol === 'Admin') {
        router.push('/administrador')
        notif.success('Bienvenido: ' + datosUsuraio.datosUsuario.nombres)
      } else {
        notif.error('Tus datos estan incorrectos')
      }
    } else {
      notif.dismissAll()
      notif.error('Error usuario o contraseña incorrectos')
    }
    isLoading.value = false
  }
}

useHead({
  title: 'Auth Login - Vuero',
})
</script>

<template>
  <div class="auth-wrapper-inner columns is-gapless">
    <!-- Image section (hidden on mobile) -->
    <div class="column login-column is-8 h-hidden-mobile h-hidden-tablet-p hero-banner">
      <div class="hero login-hero is-fullheight is-app-grey">
        <div class="hero-body">
          <div class="columns">
            <div class="column is-10 is-offset-1">
              <img
                class="light-image has-light-shadow has-light-border"
                src="/@src/assets/illustrations/apps/vuero-banking-light.png"
                alt=""
              />
              <img
                class="dark-image has-light-shadow"
                src="/@src/assets/illustrations/apps/vuero-banking-dark.png"
                alt=""
              />
            </div>
          </div>
        </div>
        <div class="hero-footer">
          <p class="has-text-centered"></p>
        </div>
      </div>
    </div>

    <!-- Form section -->
    <div class="column is-4">
      <div class="hero is-fullheight is-white">
        <div class="hero-heading">
          <label
            class="dark-mode ml-auto"
            tabindex="0"
            @keydown.space.prevent="(e) => (e.target as HTMLLabelElement).click()"
          >
            <input
              type="checkbox"
              :checked="!darkmode.isDark"
              @change="darkmode.onChange"
            />
            <span></span>
          </label>
          <div class="auth-logo">
            <RouterLink :to="{ name: 'index' }">
              <AnimatedLogo width="36px" height="36px" />
            </RouterLink>
          </div>
        </div>
        <div class="hero-body">
          <div class="container">
            <div class="columns">
              <div class="column is-12">
                <div class="auth-content">
                  <h2>Bienvenido de vuelta</h2>
                  <p>Por favor ingresa tus datos para iniciar sesión</p>
                </div>
                <div class="auth-form-wrapper">
                  <!-- Login Form -->
                  <form @submit.prevent="handleLogin">
                    <div class="login-form">
                      <!-- Username -->
                      <VField>
                        <VControl icon="feather:user">
                          <VInput
                            v-model="dataUser.name"
                            type="text"
                            placeholder="Correo Electronico"
                            autocomplete="username"
                          />
                        </VControl>
                      </VField>

                      <!-- Password -->
                      <VField>
                        <VControl icon="feather:lock">
                          <VInput
                            v-model="dataUser.passwd"
                            type="password"
                            placeholder="Constraseña"
                            autocomplete="current-password"
                          />
                        </VControl>
                      </VField>

                      <!-- Switch -->
                      <!-- <VField>
                        <VControl class="setting-item">
                          <VCheckbox label="Recordarme" paddingless />
                        </VControl>
                      </VField> -->

                      <!-- Submit -->
                      <div class="login">
                        <VButton
                          class="btn-degrade-blue"
                          :loading="isLoading"
                          :disabled="!validarSesion"
                          color="primary"
                          type="submit"
                          bold
                          fullwidth
                          raised
                        >
                          Iniciar Sesión
                        </VButton>
                      </div>
                      <RouterLink :to="{ name: 'auth-recuperar' }">
                        <div class="forgot-link has-text-centered">
                          <a>Recuperar Contraseña?</a>
                        </div>
                      </RouterLink>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
