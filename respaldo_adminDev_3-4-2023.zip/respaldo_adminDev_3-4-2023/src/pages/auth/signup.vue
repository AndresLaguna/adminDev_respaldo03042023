<script setup lang="ts">
import type { TinySliderInstance } from 'tiny-slider/src/tiny-slider'
import { tns } from 'tiny-slider/src/tiny-slider'
import { useHead } from '@vueuse/head'
import { ref, reactive, onMounted, onUnmounted, onBeforeMount, computed } from 'vue'
import { useRouter } from 'vue-router'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'
import { z as zod } from 'zod'
import { useI18n } from 'vue-i18n'

import sleep from '/@src/utils/sleep'
import { useNotyf } from '/@src/composable/useNotyf'
import { CREARUSER } from '/@src/services/auth'
import { getImagenesSignUp, preview, signUpImagen } from '/@src/services/managePictures'

let slider: TinySliderInstance
const sliderElement = ref<HTMLElement>()
const router = useRouter()
const notif = useNotyf()
const step = ref(0)
const selectedAvatar = ref(2)
const isLoading = ref(false)
const terminos = ref(false)
const terminosEntrenador = ref(false)
const politica = ref(false)
const modalTerminosOpen = ref(false)
const modalEntrenadorOpen = ref(false)
const modalPoliticaOpen = ref(false)
const uploadModalOpen = ref(false)
const mensajeNombre = ref('')
const mensajeApellido = ref('')
const { t } = useI18n()
// Define a validation schema
const validationSchema = toFormValidator(
  zod
    .object({
      email: zod
        .string({
          required_error: t('auth.errors.email.required'),
        })
        .email(t('auth.errors.email.format')),
      password: zod
        .string({
          required_error: t('auth.errors.password.required'),
        })
        .min(8, t('auth.errors.password.length')),
      passwordCheck: zod.string({
        required_error: t('auth.errors.passwordCheck.required'),
      }),
    })
    .refine((data) => data.password === data.passwordCheck, {
      message: t('auth.errors.passwordCheck.match'),
      path: ['passwordCheck'],
    })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    email: '',
    password: '',
    passwordCheck: '',
  },
})

const dataUserSignUp = reactive({
  firstName: '',
  lastName: '',
  email: '',
  perfil: 'Deportista',
  nameUser: '',
  passwd: '',
  passwordCheck: '',
  picture: '',
})

let imagen = reactive({
  accept: false,
  message: '',
  dataUrl: '',
})

const previewImage = async (event) => {
  const prevImagen = await preview(event)
  dataUserSignUp.picture = prevImagen.file
  if (prevImagen.accept) {
    const file = event.target.files[0]
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = async (e) => {
      imagen.dataUrl = e.target.result
      imagen.message = prevImagen.message
      imagen.accept = prevImagen.accept
    }
  } else {
    imagen.accept = false
    imagen.message = ''
    imagen.dataUrl = ''
    notif.error('La extension de archivo o tamaño no cumple con los requisitos')
  }
}

const onAvatarChanged = (info: any) => {
  // direct access to info object
  const indexPrev = info.indexCached
  const indexCurrent = info.index

  // update style based on index
  info.slideItems[indexPrev].classList.remove('active')
  info.slideItems[indexCurrent].classList.add('active')

  if (info.displayIndex) {
    selectedAvatar.value = info.displayIndex - 1
  }
}

const getRandomNumber = async (max: number) => {
  return Math.floor(Math.random() * max)
}

const verificarEstado = computed(() => {
  let disabled = true
  if (dataUserSignUp.perfil == 'Deportista') {
    if (
      dataUserSignUp.firstName != '' &&
      dataUserSignUp.lastName != '' &&
      terminos.value === true &&
      politica.value === true
    ) {
      disabled = false
    } else {
      disabled = true
    }
  } else if (dataUserSignUp.perfil == 'Entrenador') {
    if (
      dataUserSignUp.firstName != '' &&
      dataUserSignUp.lastName != '' &&
      terminos.value === true &&
      terminosEntrenador.value === true &&
      politica.value === true
    ) {
      disabled = false
    } else {
      disabled = true
    }
  }
  return disabled
})

const confirmarTerminos = () => {
  terminos.value = true
  modalTerminosOpen.value = false
}

const confirmarTerminosE = () => {
  terminosEntrenador.value = true
  modalEntrenadorOpen.value = false
}

const confirmarPolitica = () => {
  politica.value = true
  modalPoliticaOpen.value = false
}

const validarNombre = () => {
  let estado = false
  if (dataUserSignUp.firstName == '') {
    mensajeNombre.value = '"Nombre requerido"'
    estado = true
  }
  return estado
}

const validarApellido = () => {
  let estado = false
  if (dataUserSignUp.lastName == '') {
    mensajeApellido.value = '"Apellido requerido"'
    estado = true
  }
  return estado
}

const returnNombre = () => {
  dataUserSignUp.firstName = dataUserSignUp.firstName.replace(/[0-9]/g, '')
  return dataUserSignUp.firstName
}

const returnApellido = () => {
  dataUserSignUp.lastName = dataUserSignUp.lastName.replace(/[0-9]/gi, '')
  return dataUserSignUp.lastName
}

const onSignup = handleSubmit(async () => {
  CREARUSER(dataUserSignUp)
  if (!isLoading.value) {
    step.value++
    isLoading.value = true

    await sleep(2000)

    notif.dismissAll()
    notif.success('Welcome')

    router.push({ name: 'auth-login' })
    isLoading.value = false
  }
})
useHead({
  title: 'Auth Signup',
})

onBeforeMount(async () => {
  const imagenes = await getImagenesSignUp()
  const numero = await getRandomNumber(Object.keys(imagenes).length)
  const ancho = window.innerWidth
  if (ancho <= 450) {
    signUpImagen('signUpMovil', imagenes[numero], true)
  } else {
    signUpImagen('signUp', imagenes[numero])
  }
})

onMounted(() => {
  if (sliderElement.value) {
    slider = tns({
      container: sliderElement.value,
      controls: false,
      nav: false,
      mouseDrag: true,
      startIndex: 0,
      fixedWidth: 100,
      gutter: 40,
      slideBy: 1,
      swipeAngle: false,
      center: false,
      loop: true,
      edgePadding: 325,
    })
    slider.events.on('indexChanged', onAvatarChanged)
    onAvatarChanged(slider.getInfo())
  }
})

onUnmounted(() => {
  if (slider) {
    slider.events.off('indexChanged', onAvatarChanged)
    slider.destroy()
  }
})
</script>

<template>
  <div>
    <div class="signup-nav">
      <div class="signup-nav-inner">
        <RouterLink :to="{ name: 'index' }" class="logo">
          <AnimatedLogo width="36px" height="36px" />
        </RouterLink>
      </div>
    </div>

    <div id="vuero-signup" class="signup-wrapper">
      <div class="signup-steps" :class="[step === 0 && 'is-hidden']">
        <div class="steps-container">
          <div
            class="step-icon is-active"
            :class="[step >= 1 && 'is-active', step < 1 && 'is-inactive']"
            @keydown="step = 0"
            @click="step = 0"
          >
            <div class="inner">
              <i aria-hidden="true" class="iconify" data-icon="feather:user"></i>
            </div>
            <span class="step-label">Paso 1</span>
          </div>
          <div
            class="step-icon"
            :class="[step >= 2 && 'is-active', step < 2 && 'is-inactive']"
            @keydown="step = 1"
            @click="step = 1"
          >
            <div class="inner">
              <i aria-hidden="true" class="iconify" data-icon="feather:shield"></i>
            </div>
            <span class="step-label">Imagen Perfil</span>
          </div>
          <div
            class="step-icon"
            :class="[step >= 3 && 'is-active', step < 3 && 'is-inactive']"
            @keydown="step = 2"
            @click="step = 2"
          >
            <div class="inner">
              <i aria-hidden="true" class="iconify" data-icon="feather:check"></i>
            </div>
            <span class="step-label">Registro</span>
          </div>
          <progress class="progress" :value="step - 1" :max="2">25%</progress>
        </div>
      </div>

      <img
        id="signUpImagen"
        :class="[step != 0 && 'is-hidden']"
        class="card-bg-init"
        src=""
        alt=""
      />
      <img
        :class="[step == 0 && 'is-hidden']"
        class="card-bg"
        src="/@src/assets/backgrounds/signup/signup-fondo.png?format=webp"
        alt=""
      />
      <div class="hero is-fullheight">
        <div class="hero-body">
          <div class="container">
            <!-- Step 1 -->
            <div class="columns signup-columns" :class="[step !== 0 && 'is-hidden']">
              <div class="column is-4 is-offset-1">
                <h1 id="main-signup-title" class="title is-3 signup-title">
                  Bienvenido a My Virtual Trainer
                </h1>
                <!-- <h2 id="main-signup-subtitle" class="subtitle signup-subtitle">
                  Iniciemos tu registro.
                </h2> -->
                <div class="signup-card">
                  <form class="signup-form is-mobile-spaced" @submit="onSignup">
                    <div class="columns is-multiline">
                      <div class="column is-6">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="dataUserSignUp.firstName"
                              type="text"
                              autocomplete="given-name"
                              :value="returnNombre()"
                            />
                            <VLabel raw class="auth-label">PRIMER NOMBRE</VLabel>
                            <p v-if="validarNombre()" class="help is-danger">
                              {{ mensajeNombre }}
                            </p>
                          </VControl>
                        </VField>
                      </div>
                      <div class="column is-6">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="dataUserSignUp.lastName"
                              type="text"
                              autocomplete="family-name"
                              :value="returnApellido()"
                            />
                            <VLabel raw class="auth-label">PRIMER APELLIDO</VLabel>
                            <p v-if="validarApellido()" class="help is-danger">
                              {{ mensajeApellido }}
                            </p>
                          </VControl>
                        </VField>
                      </div>
                      <div class="column is-12">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="dataUserSignUp.nameUser"
                              type="text"
                              autocomplete="username"
                            />
                            <VLabel raw class="auth-label">USUARIO</VLabel>
                          </VControl>
                        </VField>
                      </div>
                      <div class="column is-12">
                        <div class="signup-type">
                          <div class="box-wrap">
                            <input
                              v-model="dataUserSignUp.perfil"
                              type="radio"
                              name="signup_type"
                              value="Deportista"
                              checked
                            />
                            <div class="signup-box">
                              <i aria-hidden="true" class="lnil lnil-coffee-cup"></i>
                              <div class="meta">
                                <span>Deportista</span>
                              </div>
                            </div>
                          </div>
                          <div class="box-wrap">
                            <input
                              v-model="dataUserSignUp.perfil"
                              type="radio"
                              name="signup_type"
                              value="Entrenador"
                            />
                            <div class="signup-box">
                              <i aria-hidden="true" class="lnil lnil-crown-alt-1"></i>
                              <div class="meta">
                                <span>Entrenador</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- Terminos y Condiciones -->
                    <div class="control is-agree">
                      <input
                        v-if="terminos === true"
                        id="checkbox"
                        v-model="terminos"
                        type="checkbox"
                      />
                      <input
                        v-else
                        id="checkbox"
                        v-model="terminos"
                        type="checkbox"
                        disabled
                      />
                      <span
                        class="px-2"
                        @click="modalTerminosOpen = true"
                        @keydown="modalTerminosOpen = true"
                      >
                        <a rel="noopener noreferrer"> Terminos y Condiciones </a>
                      </span>
                    </div>

                    <!-- Terminos y Condiciones Entrenador -->
                    <div
                      v-show="dataUserSignUp.perfil === 'Entrenador'"
                      class="control is-agree"
                    >
                      <input
                        v-if="terminosEntrenador === true"
                        id="checkbox"
                        v-model="terminosEntrenador"
                        type="checkbox"
                      />
                      <input
                        v-else
                        id="checkbox"
                        v-model="terminosEntrenador"
                        disabled
                        type="checkbox"
                      />

                      <span
                        class="px-2"
                        @click="modalEntrenadorOpen = true"
                        @keydown="modalEntrenadorOpen = true"
                      >
                        <a rel="noopener noreferrer">
                          Terminos y Condiciones Adicionales
                        </a>
                      </span>
                    </div>

                    <!-- Politicas de Privacidad -->
                    <div class="control is-agree">
                      <input
                        v-if="politica === true"
                        id="checkbox"
                        v-model="politica"
                        type="checkbox"
                      />
                      <input
                        v-else
                        id="checkbox"
                        v-model="politica"
                        disabled
                        type="checkbox"
                      />
                      <span
                        class="px-2"
                        @click="modalPoliticaOpen = true"
                        @keydown="modalPoliticaOpen = true"
                      >
                        <a rel="noopener noreferrer"> Politica de Privacidad </a>
                      </span>
                    </div>

                    <div class="button-wrap has-help">
                      <VButton
                        class="btn-degrade-blue"
                        color="primary"
                        size="big"
                        :disabled="verificarEstado"
                        bold
                        fullwidth
                        rounded
                        @click="step++"
                      >
                        Continuar
                      </VButton>
                      <span>
                        o
                        <RouterLink :to="{ name: 'auth-login' }"> INGRESA </RouterLink>
                        con tu cuenta.
                      </span>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            <!-- Step 2 -->
            <div class="columns signup-columns" :class="[step !== 1 && 'is-hidden']">
              <form class="column is-8" @submit.prevent>
                <div class="signup-profile-wrapper">
                  <h1 class="title is-5 signup-title has-text-centered">
                    Agregar imagen de Perfil
                  </h1>
                  <!-- <h2 class="subtitle signup-subtitle has-text-centered">
                    Asi te veran los demas
                  </h2> -->
                  <div class="picture-selector">
                    <div class="image-container">
                      <img v-if="imagen.accept" :src="imagen.dataUrl" alt="" />
                      <img v-else src="/images/avatars/svg/vuero-1.svg" alt="" />
                      <div
                        class="upload-button"
                        role="button"
                        tabindex="0"
                        @keydown.space.prevent="uploadModalOpen = true"
                        @click="uploadModalOpen = true"
                      >
                        <i
                          aria-hidden="true"
                          class="iconify"
                          data-icon="feather:plus"
                        ></i>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="button-wrap is-centered has-text-centered">
                  <VButton color="primary" size="big" rounded lower @click="step++">
                    Continuar
                  </VButton>
                </div>
              </form>
            </div>

            <!-- Step 3 -->
            <div class="columns signup-columns" :class="[step !== 2 && 'is-hidden']">
              <div class="column is-4 is-offset-4 username-form">
                <h1 class="title is-5 signup-title has-text-centered">
                  Nombre de Usuario
                </h1>
                <form class="signup-form" @submit="onSignup">
                  <div class="columns is-multiline">
                    <div class="column is-12">
                      <VField id="email" v-slot="{ field }">
                        <VControl>
                          <VInput
                            v-model="dataUserSignUp.email"
                            type="text"
                            autocomplete="email"
                          />
                          <VLabel raw class="auth-label">Correo Electronico</VLabel>
                          <p v-if="field?.errorMessage" class="help is-danger">
                            {{ field.errorMessage }}
                          </p>
                        </VControl>
                      </VField>
                    </div>
                    <div class="column is-12">
                      <VField id="password" v-slot="{ field }">
                        <VControl>
                          <VInput
                            v-model="dataUserSignUp.passwd"
                            type="password"
                            autocomplete="new-password"
                          />
                          <VLabel raw class="auth-label">Contraseña</VLabel>
                          <p v-if="field?.errorMessage" class="help is-danger">
                            {{ field.errorMessage }}
                          </p>
                        </VControl>
                      </VField>
                    </div>
                    <div class="column is-12">
                      <VField id="passwordCheck" v-slot="{ field }">
                        <VControl>
                          <VInput
                            v-model="dataUserSignUp.passwordCheck"
                            type="password"
                          />
                          <VLabel raw class="auth-label">Confirmar Contraseña</VLabel>
                          <p v-if="field?.errorMessage" class="help is-danger">
                            {{ field.errorMessage }}
                          </p>
                        </VControl>
                      </VField>
                    </div>
                  </div>

                  <div class="button-wrap is-centered has-text-centered">
                    <VButton
                      size="big"
                      color="primary"
                      type="submit"
                      rounded
                      primary
                      lower
                      :loading="isLoading"
                    >
                      Finalizar
                    </VButton>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- upload modal -->
    <VModal
      :open="uploadModalOpen"
      title="Sube tu foto"
      actions="center"
      size="small"
      @close="uploadModalOpen = false"
    >
      <template #content>
        <div class="has-text-centered">
          <div class="upload-demo-wrap">
            <VAvatar size="big" :picture="imagen.dataUrl" />
          </div>
          <!-- <img id="imagen" alt="" rounded="circle" :src="imagen.datoImagen" /> -->
          <!-- <small class="help-text">Use the slider to resize the image:</small> -->

          <!-- <VField class="resize-handler">
            <VControl>
              <Slider v-model="resizeValue" :tooltips="false" />
            </VControl>
          </VField> -->
        </div>
      </template>
      <template #cancel><wbr /></template>
      <template #action>
        <VField grouped>
          <VControl>
            <div class="file">
              <label class="file-label">
                <input
                  class="file-input"
                  type="file"
                  name="resume"
                  @change="previewImage($event)"
                />
                <span class="file-cta">
                  <span class="file-icon">
                    <i aria-hidden="true" class="fas fa-cloud-upload-alt"></i>
                  </span>
                  <span class="file-label"> Escoge un archivo… </span>
                </span>
              </label>
            </div>
          </VControl>
          <VControl>
            <VButton
              class="upload-result"
              size="big"
              outlined
              @keydown.space.prevent="uploadModalOpen = false"
              @click="uploadModalOpen = false"
            >
              Confirmar
            </VButton>
          </VControl>
        </VField>
      </template>
    </VModal>
  </div>

  <!-- MODAL TERMINOS Y CONDICIONES -->
  <VModal
    :open="modalTerminosOpen"
    title="Terminos y Condiciones"
    size="big"
    actions="center"
    @close="modalTerminosOpen = false"
  >
    <template #content>
      <iframe
        src="https://drive.google.com/file/d/1EB6NDN65pBubMpcFa9ZT2t56Mg4yv8lF/preview"
        title="Terminos y Condiciones"
        width="770"
        height="400"
        allow="autoplay"
      ></iframe>
    </template>
    <template #action>
      <VButton color="primary" raised @click="confirmarTerminos">
        Estoy de Acuerdo
      </VButton>
    </template>
  </VModal>

  <!-- MODAL TERMINOS Y CONDICIONES ADICIONALES -->
  <VModal
    :open="modalEntrenadorOpen"
    size="big"
    title="Terminos Entrenador"
    actions="center"
    @close="modalEntrenadorOpen = false"
  >
    <template #content>
      <iframe
        src="https://drive.google.com/file/d/1Xrw3OSqvSTtSsTuLl0-Og-Nhmg2zIka8/preview"
        title="Terminos Entrenador"
        width="770"
        height="400"
        allow="autoplay"
      ></iframe>
    </template>
    <template #action>
      <VButton color="primary" raised @click="confirmarTerminosE">
        Estoy de Acuerdo
      </VButton>
    </template>
  </VModal>

  <!-- MODAL POLITICA DE PRIVACIDAD -->
  <VModal
    :open="modalPoliticaOpen"
    size="big"
    title="Politica de Privacidad"
    actions="center"
    @close="modalPoliticaOpen = false"
  >
    <template #content>
      <iframe
        src="https://drive.google.com/file/d/1OpZgDoYoDGSWsEvMiRJBPsmZIQVRJvRw/preview"
        title="Politica de Privacidad"
        width="770"
        height="400"
        allow="autoplay"
      ></iframe>
    </template>
    <template #action>
      <VButton color="primary" raised @click="confirmarPolitica">
        Estoy de Acuerdo
      </VButton>
    </template>
  </VModal>
</template>

<style lang="scss">
.signup-nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 65px;
  z-index: 99;

  .signup-nav-inner {
    position: relative;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;

    .logo {
      img {
        display: block;
        min-width: 48px;
        max-width: 48px;
      }
    }
  }
}

.signup-steps {
  position: absolute;
  top: 80px;
  left: 0;
  right: 0;
  margin: 0 auto;
  max-width: 380px;

  .steps-container {
    position: relative;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .progress {
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      transform: translateY(-50%);
      width: calc(100% - 80px);
      margin: 0 auto;
      height: 0.35rem !important;
      background-color: var(--white);
      z-index: 0;

      &::-webkit-progress-value {
        background-color: var(--primary);
        transition: width 0.5s ease;
      }

      &::-moz-progress-bar {
        background-color: var(--primary);
        transition: width 0.5s ease;
      }

      &::-ms-fill {
        background-color: var(--primary);
        transition: width 0.5s ease;
      }
    }

    .step-icon {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 46px;
      width: 46px;
      border-radius: var(--radius-rounded);
      background: var(--fade-grey);
      cursor: pointer;
      z-index: 1;

      &.is-active {
        .inner {
          background: var(--white);
          border-color: var(--primary);

          svg {
            color: var(--primary);
          }
        }
      }

      &.is-done {
        .inner {
          background: var(--primary);
          border-color: var(--primary);

          svg {
            color: var(--smoke-white);
          }
        }
      }

      &.is-inactive {
        pointer-events: none;
      }

      .inner {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 40px;
        width: 40px;
        border-radius: var(--radius-rounded);
        border: 2px solid var(--primary-grey);
        background: var(--primary-grey);
      }

      .step-label {
        position: absolute;
        top: 45px;
        left: 0;
        right: 0;
        margin: 0 auto;
        text-align: center;
        min-width: 100px;
        transform: translateX(-25%);
        font-size: 0.8rem;
        font-weight: 500;
        color: var(--dark-text);
      }

      svg {
        height: 16px;
        width: 16px;
        color: var(--muted-grey);
      }
    }
  }
}

.signup-columns {
  animation: fadeInLeft 0.5s;

  .column.is-8 {
    margin: 0 auto;
  }
}

.signup-wrapper {
  position: relative;
  min-height: 100vh;
  background: var(--fade-grey);

  .card-bg {
    position: fixed;
    margin: auto;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: block;
    width: 90%;
    transition: all 0.3s; // transition-all test

    &.faded {
      opacity: 0;
    }
  }

  .card-bg-init {
    position: fixed;
    right: 0;
    bottom: 0;
    display: block;
    width: 90%;
    transition: all 0.3s; // transition-all test

    &.faded {
      opacity: 0;
    }
  }

  .signup-title {
    font-family: var(--font-alt);
    color: var(--dark-text);
  }

  .signup-subtitle {
    font-family: var(--font);
    color: var(--muted-grey);
    font-size: 1rem;
  }

  .hero {
    .signup-form {
      .control {
        position: relative;
        width: 100%;

        &.has-switch {
          display: flex;
          align-items: center;

          span {
            display: block;
            color: var(--muted-grey);
          }

          > div {
            margin-left: auto;
            transform: scale(0.8);
          }
        }

        &.is-agree {
          span {
            color: var(--placeholder-dark-8);

            a {
              color: var(--muted-grey);
              font-weight: 500;
              transition: color 0.3s;

              &:hover,
              &:focus {
                color: var(--primary);
              }
            }
          }
        }

        .input {
          padding-top: 10px;
          height: 60px;
          padding-left: 10px;
          border-radius: 8px;
          transition: all 0.3s; // transition-all test

          &:focus {
            background: var(--fade-grey-light-6);
            border-color: var(--placeholder);

            ~ .auth-label,
            ~ .autv-icon i {
              color: var(--muted-grey);
            }
          }
        }

        .error-text {
          color: var(--danger);
          font-size: 0.8rem;
          display: none;
          padding: 2px 6px;
        }

        .auth-label {
          position: absolute;
          top: 6px;
          left: 10px;
          font-size: 0.8rem;
          color: var(--dark-text);
          font-weight: 500;
          z-index: 2;
          transition: all 0.3s; // transition-all test
        }

        .autv-icon {
          position: absolute;
          top: 0;
          left: 0;
          height: 60px;
          width: 60px;
          display: flex;
          justify-content: center;
          align-items: center;

          i {
            font-size: 24px;
            color: var(--placeholder);
            transition: all 0.3s; // transition-all test
          }
        }

        &.has-validation {
          .validation-icon {
            position: absolute;
            top: 0;
            right: 0;
            height: 60px;
            width: 60px;
            display: none;
            justify-content: center;
            align-items: center;

            .icon-wrapper {
              height: 20px;
              width: 20px;
              display: flex;
              justify-content: center;
              align-items: center;
              border-radius: var(--radius-rounded);

              svg {
                height: 10px;
                width: 10px;
                stroke-width: 3px;
                color: var(--white) !important;
              }
            }

            &.is-success {
              .icon-wrapper {
                background: var(--success);
              }
            }

            &.is-error {
              .icon-wrapper {
                background: var(--danger);
              }
            }
          }

          &.has-success {
            .validation-icon {
              &.is-success {
                display: flex;
              }

              &.is-error {
                display: none;
              }
            }
          }

          &.has-error {
            .input {
              border-color: var(--danger);
            }

            .error-text {
              display: block;
            }

            .validation-icon {
              &.is-error {
                display: flex;
              }

              &.is-success {
                display: none;
              }
            }
          }
        }

        &.is-flex {
          display: flex;
          align-items: center;

          a {
            display: block;
            margin-left: auto;
            color: var(--muted-grey);
            font-weight: 500;
            font-size: 0.9rem;
            transition: color 0.3s;

            &:hover,
            &:focus {
              color: var(--primary);
            }
          }

          .remember-me {
            font-size: 0.9rem;
            color: var(--muted-grey);
            font-weight: 500;
          }
        }
      }
    }

    .button-wrap {
      margin: 20px 0 0;

      &.has-help {
        display: flex;
        align-items: center;

        > span {
          margin-left: 12px;
          font-family: var(--font);

          a {
            color: var(--primary);
            font-weight: 500;
            padding: 0 3px;
          }
        }
      }

      &.is-centered {
        margin-top: 40px;
        text-align: center;

        .button {
          min-width: 180px;
          margin-left: 0 !important;
        }
      }

      .button {
        height: 46px;
        width: 190px;
        margin-left: 6px;

        &:first-child {
          &:hover {
            opacity: 0.95;
            box-shadow: var(--primary-box-shadow);
          }
        }

        &:nth-child(2) {
          color: var(--dark-text);
          border-color: var(--placeholder);
        }
      }
    }

    .signup-type {
      display: flex;
      align-items: center;

      // margin-top: 16px;

      .box-wrap {
        width: 100%;
        position: relative;

        input {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          opacity: 0;
          cursor: pointer;

          &:checked + .signup-box {
            border-color: var(--primary);

            i {
              color: var(--primary);
            }

            .meta {
              span:first-child {
                color: var(--primary);
              }
            }
          }
        }

        .signup-box {
          display: flex;
          align-items: center;
          padding: 12px;
          background: var(--white);
          border: 1px solid var(--fade-grey-dark-3);
          border-radius: var(--radius-large);
          transition: all 0.3s; // transition-all test

          i {
            font-size: 2rem;
            color: var(--muted-grey);
          }

          .meta {
            margin-left: 10px;

            span {
              display: block;

              &:first-child {
                font-size: 0.85rem;
                font-weight: 500;
                color: var(--dark-text);
              }

              &:nth-child(2) {
                font-size: 0.8rem;
                color: var(--muted-grey);
              }
            }
          }
        }

        &:first-child {
          margin-right: 6px;
        }

        &:nth-child(2) {
          margin-left: 6px;
        }
      }
    }
  }
}

.signup-profile-wrapper {
  padding: 80px 60px 10px;

  .title,
  .subtitle {
    text-align: center;
  }

  .title {
    font-family: var(--font-alt);
    font-size: 1.4rem;
  }

  .subtitle {
    font-family: var(--font);
    font-size: 1rem;
  }

  .picture-selector,
  .skill-picture-selector {
    width: 100%;
    text-align: center;

    .image-container {
      position: relative;
      width: 140px;
      height: 140px;
      margin: 10px auto;
      border-radius: var(--radius-rounded);

      img {
        width: 140px;
        height: 140px;
        border-radius: var(--radius-rounded);
        display: block;
        border: 4px solid #e8e8e8;
        margin-left: -1px;
      }

      .upload-button {
        position: absolute;
        bottom: 18px;
        right: 0;
        width: 36px;
        height: 36px;
        display: flex;
        justify-content: center;
        align-items: center;
        background: var(--white);
        border-radius: var(--radius-rounded);
        border: 1px solid var(--fade-grey-dark-4);
        z-index: 5;
        transition: all 0.3s; // transition-all test
        cursor: pointer;

        &:hover,
        &:focus {
          box-shadow: var(--light-box-shadow);
        }

        svg {
          height: 16px;
          width: 16px;
          color: var(--dark-text);
        }
      }
    }
  }
}

.avatar-carousel {
  text-align: center;

  // max-width: 550px;
  // margin: 0 auto 20px auto;

  &:hover,
  &:focus .slick-custom {
    opacity: 1;
  }

  .carousel-item {
    margin: 0 10px;
  }

  .image-wrapper {
    position: relative;

    &.is-smaller img {
      height: 70px;
      width: 70px;
    }

    img {
      height: 70px;
      width: 70px;
      border-radius: var(--radius-rounded);
      margin: 0 auto;
      transition: all 0.3s; // transition-all test
    }
  }

  .tns-item {
    max-width: 120px;
    text-align: center;
    cursor: pointer;

    img {
      opacity: 0.6;
      border: 4px solid transparent;
      transform: scale(0.75);
    }

    &.active {
      img {
        opacity: 1;
        transform: scale(1);
        border: 2px solid var(--primary);
      }
    }
  }

  .slick-dots {
    bottom: -60px !important;
  }

  .slick-prev::before,
  .slick-next::before {
    color: var(--muted-grey);
  }

  .slick-custom {
    position: absolute;
    top: calc(50% - 15px);
    display: flex;
    justify-content: center;
    align-items: center;
    border: 1px solid var(--fade-grey);
    width: 30px;
    height: 30px;
    background: var(--white);
    border-radius: 100px;
    cursor: pointer;
    color: var(--dark-text);
    transition: all 0.3s; // transition-all test
    z-index: 25;
    opacity: 0;

    svg {
      height: 16px;
      width: 16px;
      color: var(--primary);
      transition: all 0.3s; // transition-all test
    }

    &:hover {
      border-color: var(--fade-grey-dark-4);
      color: var(--white);
      box-shadow: var(--light-box-shadow);
    }

    &.is-prev {
      left: -6px;
    }

    &.is-next {
      right: -6px;
    }
  }
}

.resize-handler {
  max-width: 200px;
  margin: 7px auto 10px;
}

.username-form {
  padding-top: 80px;
}

.is-dark {
  .signup-wrapper {
    background: var(--dark-sidebar-light-10);
  }

  .signup-steps {
    .steps-container {
      .progress {
        &::-webkit-progress-value {
          background: var(--primary);
        }

        &::-moz-progress-bar {
          background: var(--primary);
        }

        &::-ms-fill {
          background: var(--primary);
        }
      }

      .step-icon {
        background: var(--dark-sidebar-light-7);

        &.is-active {
          background: var(--dark-sidebar-light-16);

          .inner {
            background: var(--primary);

            svg {
              color: var(--white);
              stroke: var(--white);
            }
          }

          .step-label {
            color: var(--primary);
            opacity: 1;
          }
        }

        .inner {
          background: var(--dark-sidebar-light-9);
          border-color: var(--dark-sidebar-light-9);
        }

        .step-label {
          color: var(--dark-dark-text);
          opacity: 0.6;
        }
      }
    }
  }

  .hero {
    .signup-form {
      .control {
        .auth-label {
          color: var(--light-text);
        }

        .input {
          &:focus {
            background: var(--dark-sidebar-dark-4);
            border-color: var(--dark-sidebar-light-12);

            ~ .auth-label,
            ~ .auth-icon i {
              color: var(--primary);
            }
          }
        }
      }

      .signup-type {
        .box-wrap {
          input {
            &:checked + .signup-box {
              border-color: var(--primary);

              i {
                color: var(--primary);
              }

              .meta {
                span:first-child {
                  color: var(--primary);
                }
              }
            }
          }

          .signup-box {
            background-color: var(--dark-sidebar-light-2);
            border-color: var(--dark-sidebar-light-4);

            .meta {
              span:first-child {
                color: var(--dark-dark-text);
              }
            }
          }
        }
      }

      .button-wrap {
        &.has-help {
          > span {
            color: var(--light-text);

            a {
              color: var(--primary);
            }
          }
        }
      }
    }
  }

  .signup-profile-wrapper {
    .picture-selector {
      .image-container {
        img {
          border-color: var(--dark-sidebar-light-10);
        }

        .upload-button {
          background-color: var(--dark-sidebar-light-2);
          border-color: var(--dark-sidebar-light-10);

          svg {
            color: var(--light-text);
            stroke: var(--light-text);
          }
        }
      }
    }
  }

  .divider-container {
    .divider {
      span {
        &::before,
        &::after {
          border-color: var(--dark-sidebar-light-18);
        }
      }
    }
  }

  .avatar-carousel {
    .slick-slide {
      &.slick-current {
        img {
          border-color: var(--primary);
        }
      }
    }

    .slick-custom {
      background-color: var(--dark-sidebar-light-2);
      border-color: var(--dark-sidebar-light-10);

      &::before,
      &::after {
        color: var(--light-text);
      }
    }
  }
}

@media only screen and (max-width: 767px) {
  .steps-container {
    padding: 0 1rem;
  }

  .signup-wrapper {
    .card-bg {
      bottom: -75px;
    }

    .columns {
      padding: 0;
      text-align: center;
    }

    .signup-columns {
      max-width: 100vw;
    }

    .signup-subtitle {
      max-width: 330px;
      margin-left: auto;
      margin-right: auto;
    }

    .avatar-carousel .carousel-item {
      margin: 0;
    }

    .button-wrap {
      &.has-help {
        justify-content: center;
      }
    }
  }
}

@media only screen and (min-width: 768px) and (max-width: 1024px) and (orientation: portrait) {
  .signup-wrapper {
    .card-bg {
      bottom: -75px;
    }

    .columns {
      padding: 0 80px;
      text-align: center;
    }

    .signup-columns {
      max-width: 100vw;
    }

    .signup-subtitle {
      max-width: 330px;
      margin-left: auto;
      margin-right: auto;
    }

    .button-wrap {
      &.has-help {
        justify-content: center;
      }
    }
  }
}
</style>
