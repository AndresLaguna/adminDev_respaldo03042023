<script setup lang="ts">
import { useHead } from '@vueuse/head'
import { onMounted, ref } from 'vue'
import { ACTUALIZAR_PASO_BIENVENIDA } from '/@src/services/entrenador'
import { useUserSession } from '/@src/stores/userSession'
const userSession = useUserSession()

const estadoBienvenida = ref(1)

useHead({
  title: 'Main Dashboard - My app',
})

const ActualizarBienvenida = async (paso: number) => {
  estadoBienvenida.value = paso
  await ACTUALIZAR_PASO_BIENVENIDA(userSession.userId, paso)
}

onMounted(() => {
  estadoBienvenida.value = userSession.userData?.pasoBienvenida
})
</script>

<template>
  <div v-if="userSession.userData?.pasoBienvenida !== 0" class="page-content-inner">
    <div class="account-wrapper">
      <div class="columns">
        <div class="column is-12">
          <VButtons>
            <VButton :disabled="estadoBienvenida > 1" color="info">
              Datos personales
            </VButton>
            <VButton :disabled="estadoBienvenida > 2" color="info">
              Datos Deporte
            </VButton>
          </VButtons>
        </div>
      </div>
    </div>
    <div v-if="estadoBienvenida === 1" class="account-wrapper">
      <div class="columns">
        <div class="column is-12">
          <RouterView>
            <Transition name="translate-page-y" mode="in-out">
              <EditProfileGeneralEntrenador @updated="ActualizarBienvenida(2)" />
            </Transition>
          </RouterView>
        </div>
      </div>
    </div>

    <div v-if="estadoBienvenida === 2" class="account-wrapper">
      <div class="columns">
        <div class="column is-12">
          <RouterView>
            <Transition name="translate-page-y" mode="in-out">
              <EditProfileEntrenadorDeporte @updated="ActualizarBienvenida(0)" />
            </Transition>
          </RouterView>
        </div>
      </div>
    </div>
  </div>
</template>
