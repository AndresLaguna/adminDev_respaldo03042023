<template>
  <SolicitudesAprobadas />
</template>
