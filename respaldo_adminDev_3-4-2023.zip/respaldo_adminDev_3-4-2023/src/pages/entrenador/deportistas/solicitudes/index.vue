<template>
  <SolicitudesEntrenador />
</template>
