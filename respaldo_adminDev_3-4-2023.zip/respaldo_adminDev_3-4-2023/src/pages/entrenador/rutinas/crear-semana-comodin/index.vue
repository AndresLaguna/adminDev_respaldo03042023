<script setup lang="ts">
import { ENOpcionesCru } from '/@src/services/constantes'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
</script>

<template>
  <SemanaComodin
    v-if="userSession.userEspecial === 'SuperEntrenador'"
    :opcioncrudplanes="ENOpcionesCru.CREAR"
    crear
    ver
    editar
    eliminar
  />
</template>
