<script setup lang="ts">
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
</script>

<template>
  <ListadoRutinasComodin
    v-if="userSession.userEspecial === 'SuperEntrenador'"
    ver
    editar
    eliminar
  />
</template>
