<script setup lang="ts">
import { ENOpcionesCru } from '/@src/services/constantes'
</script>

<template>
  <PlanGratuito :opcioncrudplanes="ENOpcionesCru.CREAR" crear ver editar eliminar />
</template>
