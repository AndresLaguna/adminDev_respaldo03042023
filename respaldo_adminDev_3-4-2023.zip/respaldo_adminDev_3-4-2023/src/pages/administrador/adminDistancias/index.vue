<script setup lang="ts">
import { useHead } from '@vueuse/head'
import { LISTARDISTANCIAS, ACTUALIZAR_DISTANCIA } from '../../../services/administracion'
import { useViewWrapper } from '/@src/stores/viewWrapper'
import { onMounted, ref } from 'vue'
import { administracionStore } from '../../../stores/administracionStore'
import { storeToRefs } from 'pinia'
import { useNotyf } from '/@src/composable/useNotyf'

const viewWrapper = useViewWrapper()
const notif = useNotyf()
const { distancias } = storeToRefs(administracionStore())
const distancia = ref('')
const valorDistancia = ref('')
viewWrapper.setPageTitle('Administrar distancias')

useHead({
  title: 'Perfil',
})
onMounted(() => {
  LISTARDISTANCIAS()
})
const crearDistancia = () => {
  notif.dismissAll()
  const nuevaClave = distancia.value
  const nuevoValor = parseFloat(valorDistancia.value)

  if (nuevaClave !== '' && !isNaN(nuevoValor)) {
    if (distancias.value.hasOwnProperty(nuevaClave)) {
      notif.error('La clave ya existe. Por favor, ingrese una clave diferente.')
    } else {
      distancias.value[nuevaClave] = nuevoValor
      ACTUALIZAR_DISTANCIA(distancias.value)
      distancia.value = ''
      valorDistancia.value = ''
      notif.success('Se agrego con exito la nueva distancia')
    }
  } else if (nuevaClave === '' || isNaN(nuevoValor)) {
    notif.error('Los campos estan vacios o el valor no es un número flotante')
  }
}

const eliminar = async (distancia) => {
  if (distancias.value.hasOwnProperty(distancia)) {
    delete distancias.value[distancia]
    try {
      await ACTUALIZAR_DISTANCIA(distancias.value)
      notif.success('La distancia ha sido eliminada con éxito')
    } catch (error) {
      notif.error('Error al eliminar la distancia')
    }
  } else {
    notif.error('La clave no existe en el objeto')
  }
}
</script>

<template>
  <div>
    <table class="table is-striped is-fullwidth">
      <tbody>
        <tr>
          <td>
            <VField>
              <VControl>
                <VInput
                  v-model="distancia"
                  type="text"
                  placeholder="Descripcion distancia"
                />
              </VControl>
            </VField>
          </td>
          <td>
            <VField>
              <VControl>
                <VInput
                  v-model="valorDistancia"
                  type="number"
                  placeholder="Distancia en Kms"
                />
              </VControl>
            </VField>
          </td>
          <td>
            <VButton color="primary" @click="crearDistancia">Agregar</VButton>
          </td>
        </tr>
      </tbody>
    </table>
    <table class="table is-striped is-fullwidth">
      <thead>
        <tr>
          <th scope="col">Nombre</th>
          <th scope="col">Distancia en Kms</th>
          <th scope="col">Modificar distancia</th>
          <th scope="col">Eliminar distancia</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(vars, index) in distancias" :key="index">
          <td>{{ index }}</td>
          <td>{{ vars }}</td>
          <td v-if="index !== 'Otro'"><distanciasModal :data="{ index }" /></td>
          <td v-if="index !== 'Otro'">
            <VButton :bold="true" color="danger" @click="eliminar(index)"
              >Eliminar
            </VButton>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>