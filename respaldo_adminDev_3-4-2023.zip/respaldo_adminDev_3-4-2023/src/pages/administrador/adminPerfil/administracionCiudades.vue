<script setup lang="ts">
import { useHead } from '@vueuse/head'

import { useViewWrapper } from '/@src/stores/viewWrapper'

const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Administracion de ciudades')

useHead({
  title: 'Perfil',
})
</script>

<template>
  <adminCiudades />
</template>
