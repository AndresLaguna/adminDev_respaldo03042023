<script setup lang="ts">
import { useHead } from '@vueuse/head'

import { useViewWrapper } from '/@src/stores/viewWrapper'

const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Administracion')

useHead({
  title: 'Main Dashboard - My app',
})
</script>

<template>
  <div>
    <h2>Panel Administracion</h2>
  </div>
</template>
