<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { onValue, ref as reff } from 'firebase/database'
import { database } from '/@src/services/config'
import { useViewWrapper } from '/@src/stores/viewWrapper'
import { GET_ENTRENADORES_VALIDOS } from '/@src/services/entrenador'
import { getDatosDeportista, OBTENER_PLAN_DEPORTISTA } from '/@src/services/deportista'
import { GET_SOLICITUDES_DEPORTISTA, VERIFICAR_MATCH } from '/@src/services/match'
import { useUserSession } from '/@src/stores/userSession'
import { EditarDatosDeportista } from '/@src/services/models/Deportista'

const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Tu Entrenador')

const userSession = useUserSession()

let entrenadores = ref([])
let entrenador = ref({})
let solicitudes: any[] = ref([])
let resMatch = ref({})
let datosDeportista = ref<EditarDatosDeportista>({
  nombres: '',
  apellidos: '',
  email: '',
  descripcion: '',
  nameUser: '',
  identificacion: '',
  fecha_nacimiento: '',
  fecha_registro: '',
  telefono: '',
  genero: '',
  ciudad: '',
  pais: '',
  pictureName: '',
})
const plan = await OBTENER_PLAN_DEPORTISTA(userSession.userId)
const contadorSolicitudes = ref()

onMounted(async () => {
  datosDeportista.value = await getDatosDeportista(userSession.userId)
  contadorSolicitudes.value = plan.solicitudesEnviadas
  onValue(reff(database, 'users'), (snapshot) => {
    if (snapshot.exists()) {
      entrenadores.value = GET_ENTRENADORES_VALIDOS(snapshot.val())
    } else {
      entrenadores = null
    }
  })

  onValue(reff(database, 'solicitudes'), (snapshot) => {
    if (snapshot.exists()) {
      solicitudes.value = GET_SOLICITUDES_DEPORTISTA(userSession.userId, snapshot.val())
      resMatch.value = VERIFICAR_MATCH(userSession.userId, snapshot.val())
      if (resMatch.value.match) {
        onValue(reff(database, 'users/' + resMatch.value.entrenador), (snapshot) => {
          if (snapshot.exists()) {
            entrenador.value = snapshot.val()
            entrenador.value.id = resMatch.value.entrenador
          } else {
            console.log('no existe')
            entrenador = null
          }
        })
      }
    } else {
      solicitudes = null
    }
  })

  onValue(
    reff(database, 'users/' + userSession.userId + '/plan/solicitudesEnviadas'),
    (snapshot) => {
      if (snapshot.exists()) {
        contadorSolicitudes.value = snapshot.val()
      } else {
        contadorSolicitudes.value = null
      }
    }
  )
})
</script>

<template>
  <div class="page-content-inner">
    <!--Edit Profile-->
    <!-- <div class="account-wrapper">
      <div class="list-flex-toolbar flex-list-v1">
        <VField>
          <VControl icon="feather:search">
            <input
              v-model="filters"
              class="input custom-text-filter"
              placeholder="Buscar..."
            />
          </VControl>
        </VField>
      </div>
      <VPlaceholderPage
        v-if="!filteredData.length"
        title="No pudimos encontrar ningún resultado coincidente."
        subtitle="Parece que no pudimos encontrar ningún resultado que coincida con los términos de búsqueda que ingresó. Pruebe diferentes términos o criterios de búsqueda."
        larger
      >
      </VPlaceholderPage>

      <VFlexTable
        v-if="filteredData.length"
        :data="filteredData"
        :columns="columns"
        compact
      >
        <template #body>
          <TransitionGroup name="list" tag="div" class="flex-list-inner">
            <div v-if="resMatch.match" class="flex-table-item">
              <VFlexTableCell :column="{ media: true, grow: true }">
                <VAvatar
                  :picture="entrenador.foto_url"
                  :badge="entrenador.badge"
                  :color="entrenador.color"
                  :initials="entrenador.initials"
                  size="medium"
                />
                <div>
                  <span class="item-name dark-inverted">
                    {{ entrenador.nombres }} {{ entrenador.apellidos }}</span
                  >
                  <span class="item-meta">
                    <span>{{ entrenador.rol }}</span>
                  </span>
                </div>
              </VFlexTableCell>
              <VFlexTableCell>
                <i
                  v-for="estrellas in entrenador.estrellas"
                  :key="estrellas"
                  class="fas fa-star"
                  aria-hidden="true"
                >
                </i>
              </VFlexTableCell>
              <VFlexTableCell>
                <RouterLink
                  :to="{
                    name: 'deportista-profile-preViewEntrenador',
                    params: { data: JSON.stringify(entrenador) },
                  }"
                >
                  <VButton rounded raised color="primary" bold> Visitar Perfil </VButton>
                </RouterLink>
              </VFlexTableCell>
              <VFlexTableCell :column="{ align: 'end' }">
                <VTags>
                  <VTag
                    rounded
                    size="medium"
                    color="green"
                    label="Este es tu entrenador"
                  />
                </VTags>
              </VFlexTableCell>
            </div>
          </TransitionGroup>
        </template>
      </VFlexTable>
    </div> -->
    <ViewEntrenador v-if="resMatch.match" :data="entrenador" />
    <VPlaceholderPage
      v-else
      title="No tienes un entrenador."
      subtitle="Cuando un entrenador acepte la solicitud, sus datos se mostraran aquí."
      larger
    >
    </VPlaceholderPage>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/abstracts/all';

.is-navbar {
  .account-wrapper {
    margin-top: 30px;
  }
}

.account-wrapper {
  padding-bottom: 60px;

  .account-box {
    @include vuero-s-card;

    &.is-navigation {
      .media-flex-center {
        padding-bottom: 20px;

        .flex-meta {
          span {
            &:first-child {
              font-size: 1.3rem;
            }
          }
        }
      }

      .account-menu {
        .account-menu-item {
          display: flex;
          align-items: center;
          padding: 12px 16px;
          border: 1px solid transparent;
          border-radius: 8px;
          margin-bottom: 5px;
          transition: all 0.3s; // transition-all test

          &.router-link-exact-active {
            box-shadow: var(--light-box-shadow);
            border-color: var(--fade-grey-dark-3);

            span,
            i {
              color: var(--primary);
            }

            .end {
              display: block;
            }
          }

          &:not(.router-link-exact-active) {
            &:hover {
              background: var(--fade-grey-light-3);
            }
          }

          i {
            margin-right: 8px;
            font-size: 1.1rem;
            color: var(--light-text);

            &.fas,
            .fal,
            .far {
              font-size: 0.9rem;
            }
          }

          span {
            font-family: var(--font-alt);
            font-size: 0.95rem;
            color: var(--dark-text);
          }

          .end {
            margin-left: auto;
            display: none;
          }
        }
      }
    }

    &.is-form {
      padding: 0;

      &.is-footerless {
        padding-bottom: 20px;
      }

      .form-head,
      .form-foot {
        padding: 12px 20px;

        .form-head-inner,
        .form-foot-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
      }

      .form-head {
        border-bottom: 1px solid var(--fade-grey-dark-3);
        transition: all 0.3s; // transition-all test

        &.is-stuck {
          background: var(--white);
          padding-right: 80px;
          border-left: 1px solid var(--fade-grey-dark-3);
        }

        .left {
          h3 {
            font-family: var(--font-alt);
            font-size: 1.2rem;
            line-height: 1.3;
          }

          p {
            font-size: 0.95rem;
          }
        }
      }

      .form-foot {
        border-top: 1px solid var(--fade-grey-dark-3);
      }

      .form-body {
        padding: 20px;

        .fieldset {
          padding: 20px 0;
          max-width: 480px;
          margin: 0 auto;

          .fieldset-heading {
            margin-bottom: 20px;

            h4 {
              font-family: var(--font-alt);
              font-weight: 600;
              font-size: 1rem;
            }

            p {
              font-size: 0.9rem;
            }
          }

          .v-avatar {
            position: relative;
            display: block;
            margin: 0 auto;

            .edit-button {
              position: absolute;
              bottom: 0;
              right: 0;
            }
          }

          .setting-list {
            .setting-form {
              text-align: center;

              .filepond-profile-wrap {
                margin: 0 auto 10px !important;
              }
            }

            .setting-item {
              display: flex;
              align-items: center;
              margin-bottom: 24px;

              .icon-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                background: var(--fade-grey-light-2);
                border: 1px solid var(--fade-grey-dark-3);
                color: var(--light-text);

                &.has-img {
                  border-color: var(--primary);

                  img {
                    width: 36px;
                    min-width: 36px;
                    height: 36px;
                  }
                }

                i {
                  font-size: 1.4rem;
                }
              }

              img {
                display: block;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                border: 1px solid transparent;
              }

              .meta {
                margin-left: 10px;

                > span {
                  font-family: var(--font);
                  display: block;

                  &:first-child {
                    font-family: var(--font-alt);
                    font-weight: 600;
                    color: var(--dark-text);
                    font-size: 0.9rem;
                  }

                  &:nth-child(2),
                  &:nth-child(3) {
                    font-size: 0.85rem;
                    color: var(--light-text);

                    i {
                      position: relative;
                      top: -2px;
                      font-size: 4px;
                      margin: 0 6px;
                    }
                  }

                  &:nth-child(3) {
                    color: var(--primary);
                  }

                  span {
                    display: inline-block;
                  }
                }
              }

              .end {
                margin-left: auto;
              }
            }
          }
        }
      }
    }
  }
}

.is-dark {
  .account-wrapper {
    .account-box {
      @include vuero-card--dark;

      &.is-navigation {
        .account-menu {
          .account-menu-item {
            &.router-link-exact-active {
              background: var(--dark-sidebar-light-8);
              border-color: var(--dark-sidebar-light-12);

              i,
              span {
                color: var(--primary);
              }
            }

            &:not(.router-link-exact-active) {
              &:hover {
                background: var(--dark-sidebar-light-10);
              }
            }

            span {
              color: var(--dark-dark-text);
            }
          }
        }
      }

      &.is-form {
        .form-head,
        .form-foot {
          border-color: var(--dark-sidebar-light-12);
        }

        .form-head {
          &.is-stuck {
            background: var(--dark-sidebar);
            border-color: var(--dark-sidebar-light-6);
          }

          .left {
            h3 {
              color: var(--dark-dark-text);
            }
          }
        }

        .form-body {
          .fieldset {
            .fieldset-heading {
              h4 {
                color: var(--dark-dark-text);
              }
            }

            .setting-list {
              .setting-item {
                > img,
                > .icon-wrap,
                > .icon-wrap img {
                  border-color: var(--dark-sidebar-light-12);
                }

                > .icon-wrap {
                  background: var(--dark-sidebar-light-2);
                }

                .meta {
                  > span {
                    &:nth-child(3) {
                      color: var(--primary);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
