<script setup lang="ts">
import { useHead } from '@vueuse/head'

import { useViewWrapper } from '/@src/stores/viewWrapper'

const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Rendimiento')

useHead({
  title: 'Perfil',
})
</script>

<template>
  <Rendimiento />
</template>
