<script setup lang="ts">
import { useHead } from '@vueuse/head'
import { onBeforeMount, ref } from 'vue'
import { useViewWrapper } from '/@src/stores/viewWrapper'

const parametros = ref({})
const viewWrapper = useViewWrapper()
viewWrapper.setPageTitle('Preview Entrenador')

useHead({
  title: 'Profile Entrenador',
})

const props = defineProps({
  data: {
    type: String,
    required: true,
  },
})

onBeforeMount(async () => {
  parametros.value = JSON.parse(props.data)
})
</script>

<template>
  <div class="page-content-inner">
    <ViewEntrenador :data="parametros" />
  </div>
</template>
