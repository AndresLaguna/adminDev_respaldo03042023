<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, ref } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { EditarDatosDeportista } from '/@src/services/models/Deportista'
import { getDatosDeportista, updateDatosDeportista } from '/@src/services/deportista'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const isLoading = ref(false)
const notyf = useNotyf()
const { y } = useWindowScroll()

const emit = defineEmits(['update'])

const isScrolling = computed(() => {
  return y.value > 40
})

const activarBoton = computed(() => {
  let disabled = true
  if (
    Number(datosDeportista.value.identificacion) > 0 &&
    Number(datosDeportista.value.telefono) > 0 &&
    datosDeportista.value.genero != null &&
    datosDeportista.value.pais != null &&
    datosDeportista.value.ciudad != null
  ) {
    disabled = false
  } else {
    disabled = true
  }

  return disabled
})

const onSave = async () => {
  isLoading.value = true
  await sleep()
  await updateDatosDeportista(userSession.userId, datosDeportista.value)
  emit('update')
  notyf.success('Your changes have been successfully saved!')
  isLoading.value = false
}

const datosDeportista = ref<EditarDatosDeportista>({
  nombres: '',
  apellidos: '',
  email: '',
  descripcion: '',
  nameUser: '',
  identificacion: '',
  fecha_nacimiento: '',
  fecha_registro: '',
  telefono: '',
  genero: '',
  ciudad: '',
  pais: '',
  pictureName: '',
})

onMounted(async () => {
  datosDeportista.value = await getDatosDeportista(userSession.userId)
})
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Forma de Pago</h3>
          <p>Edita la informacíon de pago</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'deportista-rutinas' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="activarBoton"
              tabindex="0"
              @keydown.space.prevent="onSave"
              @click="onSave"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <form action="signup-form" @submit="onSave">
      <div class="form-body">
        <!--Fieldset-->
        <div class="fieldset">
          <div class="columns is-multiline">
            <!--Field-->
            <div class="column is-6">
              <VField>
                <VControl>
                  <VSwitchBlock
                    v-if="datosDeportista.pagoRecurrente"
                    v-model="datosDeportista.pagoRecurrente"
                    color="success"
                    label="El pago se realizara automaticamente cada mes"
                  />
                  <VSwitchBlock
                    v-if="!datosDeportista.pagoRecurrente"
                    v-model="datosDeportista.pagoRecurrente"
                    color="warning"
                    label="Tendras que pagar manualmente cada mes"
                  />
                  <VTags>
                    <VTag
                      v-if="datosDeportista.pagoRecurrente"
                      color="green"
                      label="El pago se realizara automaticamente cada mes"
                    />
                    <VTag
                      v-if="!datosDeportista.pagoRecurrente"
                      color="warning"
                      label="Tendras que pagar manualmente cada mes"
                    />
                  </VTags>
                </VControl>
              </VField>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</template>

<style lang="scss">
.picture-selector,
.skill-picture-selector {
  width: 100%;
  text-align: center;

  .image-container {
    position: relative;
    width: 110px;
    height: 110px;
    margin: 10px auto;
    border-radius: var(--radius-rounded);

    img {
      width: 110px;
      height: 110px;
      border-radius: var(--radius-rounded);
      display: block;
      border: 4px solid #e8e8e8;
      margin-left: -1px;
    }

    .upload-button {
      position: absolute;
      bottom: 18px;
      right: 0;
      width: 36px;
      height: 36px;
      display: flex;
      justify-content: center;
      align-items: center;
      background: var(--white);
      border-radius: var(--radius-rounded);
      border: 1px solid var(--fade-grey-dark-4);
      z-index: 5;
      transition: all 0.3s; // transition-all test
      cursor: pointer;

      &:hover,
      &:focus {
        box-shadow: var(--light-box-shadow);
      }

      svg {
        height: 16px;
        width: 16px;
        color: var(--dark-text);
      }
    }
  }
}

.picture-selector {
  .image-container {
    img {
      border-color: var(--dark-sidebar-light-10);
    }

    .upload-button {
      background-color: var(--dark-sidebar-light-2);
      border-color: var(--dark-sidebar-light-10);

      svg {
        color: var(--light-text);
        stroke: var(--light-text);
      }
    }
  }
}
</style>
