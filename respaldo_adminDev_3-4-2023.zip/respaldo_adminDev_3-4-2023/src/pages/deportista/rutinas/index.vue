<script setup lang="ts">
import { useHead } from '@vueuse/head'

import { useViewWrapper } from '/@src/stores/viewWrapper'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const viewWrapper = useViewWrapper()

viewWrapper.setPageTitle('Planes')

useHead({
  title: 'Planes',
})
</script>

<template>
  <div>
    <Calendario :iddeportista="userSession.userId" />
  </div>
</template>
