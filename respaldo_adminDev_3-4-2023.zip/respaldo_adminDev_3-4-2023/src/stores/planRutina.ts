import {
  CONVERT_SEMANA_RUTINA,
  REVERT_SEMANA_RUTINA,
} from './../services/funciones/rutina'
import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import { ACTUALIZAR_PLAN_GRATUITO, CREAR_PLAN_GRATUITO } from './../services/rutinas'
import { Rutina, PlanRutina } from './../services/models/Rutinas'
import { useUserSession } from '/@src/stores/userSession'

export type UserData = Record<string, any> | null

const storeUseUserSession = useUserSession()

export const usePlanRutina = defineStore('planRutina', () => {
  const semanasRutina = ref<any[]>([
    [{}, {}, {}, {}, {}, {}, {}],
    [{}, {}, {}, {}, {}, {}, {}],
    [{}, {}, {}, {}, {}, {}, {}],
    [{}, {}, {}, {}, {}, {}, {}],
  ])

  const validarSemana = computed(() => {
    let value = true
    const numDiasValido = 1
    const numSesiones = 1
    semanasRutina.value.forEach((semana) => {
      let dias = 0
      semana.forEach((dia: any) => {
        if (Object.keys(dia).length >= numSesiones) {
          dias++
        }
      })
      if (dias < numDiasValido) {
        value = false
      }
    })
    return value
  })

  function adicionarSesion(sesion: Partial<Rutina>, semana: number, dia: number) {
    semanasRutina.value[semana][dia] = sesion
  }

  function obtenerSesion(semanaindex: number, diaindex: number) {
    return { ...semanasRutina.value[semanaindex][diaindex] }
  }

  function eliminarSesion(semana: number, dia: number) {
    semanasRutina.value[semana][dia] = {}
  }

  function asignarBloquesSemana(semanaRutina: {}) {
    REVERT_SEMANA_RUTINA(semanasRutina.value, semanaRutina)
  }

  function resetValues() {
    semanasRutina.value = [
      [{}, {}, {}, {}, {}, {}, {}],
      [{}, {}, {}, {}, {}, {}, {}],
      [{}, {}, {}, {}, {}, {}, {}],
      [{}, {}, {}, {}, {}, {}, {}],
    ]
  }

  async function guardarPlan(plan: PlanRutina) {
    plan.plan = CONVERT_SEMANA_RUTINA(semanasRutina.value)
    plan.id_entrenador = storeUseUserSession.userId
    //plan.nombre_entrenador = storeUseUserSession.
    await CREAR_PLAN_GRATUITO(plan)
    resetValues()
  }

  async function actualizarPlan(plan: PlanRutina) {
    plan.plan = CONVERT_SEMANA_RUTINA(semanasRutina.value)
    plan.id_entrenador = storeUseUserSession.userId
    await ACTUALIZAR_PLAN_GRATUITO(plan)
    resetValues()
  }

  return {
    semanasRutina,
    validarSemana,
    adicionarSesion,
    eliminarSesion,
    asignarBloquesSemana,
    obtenerSesion,
    guardarPlan,
    resetValues,
    actualizarPlan,
  } as const
})
