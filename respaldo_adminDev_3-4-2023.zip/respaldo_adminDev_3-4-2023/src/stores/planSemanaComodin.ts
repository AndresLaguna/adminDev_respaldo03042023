import { ACTUALIZAR_RUTINA_COMODIN } from './../services/rutinas'
import { REVERT_SEMANA_RUTINA } from './../services/funciones/rutina'
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { CONVERT_SEMANA_RUTINA } from '../services/funciones/rutina'
import { Rutina, ISemanaComodin } from '../services/models/Rutinas'
import { CREAR_RUTINA_COMODIN } from '../services/rutinas'

export const usePlanSemanaComodin = defineStore('planSemanaComodin', () => {
  const semanaComodin = ref<any[]>([[{}, {}, {}, {}, {}, {}, {}]])

  const validarSemana = computed(() => {
    let value = true
    const numDiasValido = 3
    const numSesiones = 1
    semanaComodin.value.forEach((semana) => {
      let dias = 0
      semana.forEach((dia: any) => {
        if (Object.keys(dia).length >= numSesiones) {
          dias++
        }
      })
      if (dias < numDiasValido) {
        value = false
      }
    })
    return value
  })
  function adicionarSesion(sesion: Partial<Rutina>, semana: number, dia: number) {
    semanaComodin.value[semana][dia] = sesion
  }

  function obtenerSesion(semanaindex: number, diaindex: number) {
    return { ...semanaComodin.value[semanaindex][diaindex] }
  }

  function eliminarSesion(semana: number, dia: number) {
    semanaComodin.value[semana][dia] = {}
  }

  function asignarBloquesSemana(semanaRutina: {}) {
    REVERT_SEMANA_RUTINA(semanaComodin.value, semanaRutina)
  }

  function resetValues() {
    semanaComodin.value = [[{}, {}, {}, {}, {}, {}, {}]]
  }

  async function guardarPlan(plan: ISemanaComodin) {
    plan.plan = CONVERT_SEMANA_RUTINA(semanaComodin.value)
    await CREAR_RUTINA_COMODIN(plan)
    resetValues()
  }

  async function actualizarPlan(plan: ISemanaComodin) {
    plan.plan = CONVERT_SEMANA_RUTINA(semanaComodin.value)
    await ACTUALIZAR_RUTINA_COMODIN(plan)
    resetValues()
  }

  return {
    semanaComodin,
    validarSemana,
    adicionarSesion,
    eliminarSesion,
    asignarBloquesSemana,
    obtenerSesion,
    guardarPlan,
    resetValues,
    actualizarPlan,
  } as const
})
