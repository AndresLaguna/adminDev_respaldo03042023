import { defineStore } from 'pinia'

export const administracionStore = defineStore('entrenador', {
  state: (): any => ({
    entrenadores: [],
    ciudades: [],
    paises: [],
    usuarios: [],
    deportes: [],
    distancias: [],
  }),
})
