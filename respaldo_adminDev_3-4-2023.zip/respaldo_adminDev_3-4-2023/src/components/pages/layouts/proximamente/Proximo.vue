<template>
  <div class="columns is-multiline">
    <div class="column is-12">
      <div class="page-placeholder">
        <div class="placeholder-content">
          <h3>Lo Sentimos, esta página no está disponible</h3>
          <p class="is-larger">Nuestro equipo está trabajando en ella.</p>
          <img
            class="light-image"
            src="/@src/assets/illustrations/placeholders/search-7.svg"
            alt=""
            style="width: 400px"
          />
          <img
            class="dark-image"
            src="/@src/assets/illustrations/placeholders/search-7-dark.svg"
            alt=""
            style="width: 400px"
          />
        </div>
      </div>
    </div>
  </div>
</template>
