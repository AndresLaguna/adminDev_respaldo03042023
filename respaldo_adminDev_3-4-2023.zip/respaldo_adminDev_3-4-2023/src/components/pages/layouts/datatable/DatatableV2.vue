<script setup lang="ts">
import { datatableV2 } from '/@src/data/layouts/datatable-v2'
</script>

<template>
  <VSimpleDatatables :options="datatableV2" />
</template>
