<script setup lang="ts">
import { datatableV1 } from '/@src/data/layouts/datatable-v1'
</script>

<template>
  <VSimpleDatatables :options="datatableV1" />
</template>
