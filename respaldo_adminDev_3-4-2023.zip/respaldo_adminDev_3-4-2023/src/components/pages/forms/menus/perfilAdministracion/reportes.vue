<script setup lang="ts">
import { ref } from 'vue'

const hello = ref('world')
</script>

<template>
  <h1>Hola mundo</h1>
</template>>

