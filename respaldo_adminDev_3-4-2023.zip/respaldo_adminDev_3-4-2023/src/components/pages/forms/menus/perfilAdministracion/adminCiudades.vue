<script setup lang="ts">
import {
  LISTARCIUDADES,
  LISTARPAISES,
  CREAR_CIUDAD,
  ACTUALIZAR_CIUDAD,
  LISTARTODOSLOSUSUARIOS,
} from '../../../../../services/administracion'
import { onMounted, ref, watch } from 'vue'
import { storeToRefs } from 'pinia'
import { administracionStore } from '../../../../../stores/administracionStore'
import { useNotyf } from '/@src/composable/useNotyf'

const notif = useNotyf()
const ciudad = ref('')
const pais = ref('')
const { paises, ciudades, usuarios } = storeToRefs(administracionStore())

onMounted(async () => {
  await LISTARTODOSLOSUSUARIOS()
})

const crearCiudad = () => {
  notif.dismissAll()
  const index = ciudades.value.indexOf(ciudad.value)
  if (pais.value === '') {
    notif.error('Selecciona un pais')
  } else {
    if (ciudad.value.length >= 3) {
      if (index !== -1) {
        notif.error('Ya se encuentra una ciudad registrada con ese nombre')
      } else {
        ciudades.value.push(ciudad.value)
        ciudades.value.sort()
        CREAR_CIUDAD(pais.value, ciudades.value)
        notif.success('La ciudad se creo correctamente')
        ciudad.value = ''
      }
    } else {
      notif.error('La ciudad debe tener al menos tres caracteres')
    }
  }
}
const eliminarCiudad = (ciudad: string) => {
  notif.dismissAll()

  let flag = true
  usuarios.value.forEach((elemento: any) => {
    if (elemento.pais == pais.value && elemento.ciudad == ciudad) {
      notif.error('la ciudad no se puede eliminar')
      flag = false
    }
  })

  if (flag) {
    const index = ciudades.value.indexOf(ciudad)
    if (index !== -1) {
      ciudades.value.splice(index, 1)
      ACTUALIZAR_CIUDAD(pais.value, ciudades.value)
      notif.success('la ciudad se elimino satisfactoriamente')
    } else {
      notif.warning('la ciudad no se pudo eliminar')
    }
  }
}

watch(pais, () => {
  paisSeleccionado()
})

const paisSeleccionado = () => {
  LISTARCIUDADES(pais.value)
}
onMounted(() => {
  LISTARPAISES()
})
</script>
<template>
  <div>
    <table class="table is-striped is-fullwidth">
      <tbody>
        <tr>
          <td>
            <h1>Elija un pais</h1>
          </td>
          <td>
            <VField class="tabla">
              <VControl class="has-icons-left" icon="feather:globe">
                <VSelect v-model="pais">
                  <VOption v-for="(element, index) in paises" :key="index">
                    {{ element }}
                  </VOption>
                </VSelect>
              </VControl>
            </VField>
          </td>
        </tr>
      </tbody>
    </table>

    <table class="table is-striped is-fullwidth">
      <tbody>
        <tr>
          <td>
            <VField>
              <VControl>
                <VInput v-model="ciudad" type="text" placeholder="Crear ciudad" />
              </VControl>
            </VField>
          </td>
          <td>
            <VButton color="primary" @click="crearCiudad">Agregar</VButton>
          </td>
        </tr>
      </tbody>
    </table>
    <div>
      <table v-if="pais" class="table is-striped is-fullwidth">
        <thead>
          <tr>
            <th scope="col">Pais</th>
            <th scope="col">Ciudad</th>
            <th scope="col">Editar Ciuadad</th>
            <th scope="col">Eliminar Ciudad</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(city, index) in ciudades" :key="index">
            <td>{{ pais }}</td>
            <td>{{ city }}</td>
            <td>
              <CiudadesModal :data="{ city, pais }" />
            </td>
            <td>
              <VButton :bold="true" color="danger" @click="eliminarCiudad(city)"
                >Eliminar
              </VButton>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>


