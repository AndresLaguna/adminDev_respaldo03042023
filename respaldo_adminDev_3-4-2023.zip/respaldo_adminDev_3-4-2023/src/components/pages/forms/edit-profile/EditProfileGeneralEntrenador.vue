<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, ref } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { z as zod } from 'zod'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'

import { onceImageErrored } from '/@src/utils/via-placeholder'

import { IDatosGeneralesEntrenador } from '/@src/services/models/Entrenador'

import {
  ACTUALIZAR_DATOS_GENERAL_ENTRENADOR,
  GET_DATOS_GENERAL_ENTRENADOR,
} from '/@src/services/entrenador'

import { useUserSession } from '/@src/stores/userSession'
import { mayorEdadFechaString } from '/@src/services/funciones/validacionFormularios'
import { addPicture } from '/@src/services/managePictures'
import { getCiudadesOnObject } from '/@src/services/deportista'

export interface IEditProfileGeneralEntrenadorEmits {
  (value: 'updated'): void
}

const emits = defineEmits<IEditProfileGeneralEntrenadorEmits>()

const userSession = useUserSession()
const isUploading = ref(false)
const isLoading = ref(false)

const notyf = useNotyf()
const { y } = useWindowScroll()

const datosEntrenador = ref<IDatosGeneralesEntrenador>({
  nombres: '',
  apellidos: '',
  descripcion: '',
  nombre_usuario: '',
  identificacion: '',
  fecha_nacimiento: '',
  telefono: '',
  genero: '',
  pais: '',
  ciudad: '',
  direccion: '',
})

const imgProfile = ref('')
const paisesOptions = ref({})

const isScrolling = computed(() => {
  return y.value > 40
})

const onAddFile = async (error: any, file: any) => {
  if (error) {
    console.error(error)
    return
  }
  if (file.file.size < 1000000) {
    await addPicture(file.file, userSession.userId)
    notyf.success('Actualización de imagen correcto')
  } else {
    notyf.error('Error, la imagen no puede pesar mas de 1Mb')
  }

  imgProfile.value = file.file
  console.log('file added', file.file)
}

const onRemoveFile = (error: any, file: any) => {
  if (error) {
    console.error(error)
    return
  }

  console.log('file removed', file)
}

const validationSchema = toFormValidator(
  zod.object({
    nombres: zod
      .string({
        required_error: 'Ingrese nombres válidos',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    apellidos: zod
      .string({
        required_error: 'Ingrese apellidos válidos',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    descripcion: zod
      .string({
        required_error: 'Ingrese una descripción válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(25, 'Mínimo 25 digitos'),
    nombre_usuario: zod
      .string({
        required_error: 'Ingrese un nombre de usuario válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    identificacion: zod
      .string({
        required_error: 'Ingrese una Identificacion válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(7, 'Mínimo 7 digitos'),
    fecha_nacimiento: zod
      .string({
        required_error: 'Ingrese una Fecha válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(10, 'Mínimo 10 digitos'),
    telefono: zod
      .string({
        required_error: 'Ingrese una teléfono válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(7, 'Mínimo 7 digitos'),
    genero: zod.string({
      required_error: 'Ingrese una teléfono válida',
    }),
    pais: zod.string({
      required_error: 'Ingrese una teléfono válida',
    }),
  })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    semicooper: '',
  },
})

const actualizarDatos = handleSubmit(async () => {
  isLoading.value = true
  await sleep()
  await ACTUALIZAR_DATOS_GENERAL_ENTRENADOR(userSession.userId, datosEntrenador.value)
  notyf.success('Tus datos se han actualizado correctamente')
  emits('updated')
  isLoading.value = false
})

const validarGuardar = computed(() => {
  if (
    datosEntrenador.value.nombres.length < 3 ||
    datosEntrenador.value.apellidos.length < 3 ||
    datosEntrenador.value.descripcion.length < 25 ||
    !datosEntrenador.value.genero ||
    !datosEntrenador.value.pais ||
    !datosEntrenador.value.ciudad ||
    datosEntrenador.value.nombre_usuario.length < 3 ||
    datosEntrenador.value.identificacion.length < 7 ||
    datosEntrenador.value.telefono.length < 7 ||
    !mayorEdadFechaString(datosEntrenador.value.fecha_nacimiento)
  )
    return false
  return true
})

onMounted(async () => {
  const datos = await GET_DATOS_GENERAL_ENTRENADOR(userSession.userId)
  datosEntrenador.value = datos
  paisesOptions.value = await getCiudadesOnObject()
  datosEntrenador.value.ciudad = datos.ciudad
  console.log(datos.ciudad)
})
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Información Personal</h3>
          <p>Edita la informacíon personal de tu cuenta</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'entrenador' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="!validarGuardar"
              tabindex="0"
              @keydown.space.prevent="actualizarDatos"
              @click="actualizarDatos"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <div class="form-body">
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <h4>Foto de perfil</h4>
          <p>La foto de perfil ayuda a que otras personas te reconozcan</p>
        </div>
        <VAvatar size="xl" class="profile-v-avatar">
          <template #avatar>
            <img
              v-if="!isUploading"
              class="avatar"
              :src="userSession.imagenUrl"
              alt=""
              @error.once="(event) => onceImageErrored(event, '150x150')"
            />
            <VFilePond
              v-else
              class="profile-filepond"
              name="profile_filepond"
              :chunk-retry-delays="[500, 1000, 3000]"
              label-idle="<i class='lnil lnil-cloud-upload'></i>"
              :accepted-file-types="['image/png', 'image/jpeg', 'image/gif']"
              :image-preview-height="140"
              :image-resize-target-width="140"
              :image-resize-target-height="140"
              image-crop-aspect-ratio="1:1"
              style-panel-layout="compact circle"
              style-load-indicator-position="center bottom"
              style-progress-indicator-position="right bottom"
              style-button-remove-item-position="left bottom"
              style-button-process-item-position="right bottom"
              @addfile="onAddFile"
              @removefile="onRemoveFile"
            />
            <VIconButton
              v-if="!isUploading"
              icon="feather:edit-2"
              class="edit-button is-edit"
              circle
              tabindex="0"
              @keydown.space.prevent="isUploading = true"
              @click="isUploading = true"
            />
            <VIconButton
              v-else
              icon="feather:arrow-left"
              class="edit-button is-back"
              circle
              tabindex="0"
              @keydown.space.prevent="isUploading = false"
              @click="isUploading = false"
            />
          </template>
        </VAvatar>
      </div>
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <h4>Información Personal</h4>
        </div>

        <div class="columns is-multiline">
          <!--Field-->
          <div class="column is-6">
            <VField id="nombres">
              <VLabel>
                <h5>Email: {{ userSession.userEmail }}</h5>
              </VLabel>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="genero" v-slot="{ field }">
              <VLabel raw class="auth-label"
                >Genero <font size="4" color="red">*</font></VLabel
              >
              <VControl>
                <VSelect v-model="datosEntrenador.genero">
                  <VOption value="Masculino">Masculino</VOption>
                  <VOption value="Femenino">Femenino</VOption>
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VSelect>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField id="nombres" v-slot="{ field }">
              <p>Nombres <font size="4" color="red">*</font></p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.nombres"
                  type="text"
                  placeholder="Ingrese nombres"
                  autocomplete="given-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField id="apellidos" v-slot="{ field }">
              <p>Apellidos <font size="4" color="red">*</font></p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.apellidos"
                  type="text"
                  placeholder="Ingrese apellidos"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="nombre_usuario" v-slot="{ field }">
              <p>Nombre de usuario <font size="4" color="red">*</font></p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.nombre_usuario"
                  type="text"
                  placeholder="Ingrese nombre de usuario"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="pais" v-slot="{ field }">
              <VLabel raw class="auth-label"
                >Seleccione País <font size="4" color="red">*</font></VLabel
              >
              <VControl>
                <VSelect
                  v-model="datosEntrenador.pais"
                  @change="() => (datosEntrenador.ciudad = '')"
                >
                  <VOption
                    v-for="(pais, index) in Object.keys(paisesOptions)"
                    :key="index"
                    :value="pais"
                    >{{ pais }}</VOption
                  >
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VSelect>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="ciudad" v-slot="{ field }">
              <VLabel raw class="auth-label"
                >Seleccione Ciudad <font size="4" color="red">*</font></VLabel
              >
              <VControl>
                <VSelect v-model="datosEntrenador.ciudad">
                  <VOption
                    v-for="(pais, index) in paisesOptions[datosEntrenador.pais]"
                    :key="index"
                    :value="pais"
                    >{{ pais }}</VOption
                  >
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VSelect>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField>
              <p>Dirección</p>
              <VControl icon="feather:book">
                <VInput
                  v-model="datosEntrenador.direccion"
                  type="text"
                  placeholder="Ingrese Dirección"
                  autocomplete="family-name"
                />
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="identificacion" v-slot="{ field }">
              <p>Número de identificación <font size="4" color="red">*</font></p>
              <VControl icon="feather:briefcase">
                <VInput
                  v-model="datosEntrenador.identificacion"
                  type="text"
                  placeholder="Ingrese número de identificación"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="telefono" v-slot="{ field }">
              <p>Teléfono <font size="4" color="red">*</font></p>
              <VControl icon="feather:book">
                <VInput
                  v-model="datosEntrenador.telefono"
                  type="text"
                  placeholder="Ingrese número de teléfono"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <p>Fecha de nacimiento <font size="4" color="red">*</font></p>
            <VField id="fecha_nacimiento">
              <VControl icon="feather:calendar">
                <VInput
                  v-model="datosEntrenador.fecha_nacimiento"
                  type="date"
                  placeholder="Fecha de nacimiento"
                  autocomplete="family-name"
                />
                <p
                  v-if="!mayorEdadFechaString(datosEntrenador.fecha_nacimiento)"
                  class="help is-danger"
                >
                  Debe ser mayor de 25 años
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="descripcion" v-slot="{ field }">
              <VControl>
                <p>Descripción personal</p>
                <VTextarea
                  v-model="datosEntrenador.descripcion"
                  rows="4"
                  placeholder="Ingrese una corta descripción sobre usted"
                  autocomplete="off"
                  autocapitalize="off"
                  spellcheck="true"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
