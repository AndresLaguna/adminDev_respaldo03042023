<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, ref } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { useUserSession } from '/@src/stores/userSession'
import { useForm } from 'vee-validate'
import { toFormValidator } from '@vee-validate/zod'
import { z as zod } from 'zod'

import { IDatosDeportivosEntrenador } from '/@src/services/models/Entrenador'
import {
  ACTUALIZAR_DATOS_DEPORTE_ENTRENADOR,
  GET_DATOS_DEPORTE_ENTRENADOR,
} from '/@src/services/entrenador'

export interface IEditProfileEntrenadorDeporteEmits {
  (value: 'updated'): void
}

const emits = defineEmits<IEditProfileEntrenadorDeporteEmits>()

const storeUseUserSession = useUserSession()

const isLoading = ref(false)

const notyf = useNotyf()
const { y } = useWindowScroll()

const isScrolling = computed(() => {
  return y.value > 40
})

const datosEntrenador = ref<IDatosDeportivosEntrenador>({
  acerca_de: '',
  formacion_academica: '',
  formacion_deportiva: '',
  especialidad: '',
  hitos: '',
})

const validationSchema = toFormValidator(
  zod.object({
    acerca_de: zod
      .string({
        required_error: 'Ingrese datos acerca de válidas',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    formacion_academica: zod
      .string({
        required_error: 'Ingrese datos de formacion academica válidos',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    formacion_deportiva: zod
      .string({
        required_error: 'Ingrese datos de formacion deportiva válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    especialidad: zod
      .string({
        required_error: 'Ingrese especialidad válida',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
    hitos: zod
      .string({
        required_error: 'Ingrese hitos ',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(3, 'Mínimo 3 digitos'),
  })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    semicooper: '',
  },
})

const actualizarDatos = handleSubmit(async () => {
  isLoading.value = true
  await sleep()
  await ACTUALIZAR_DATOS_DEPORTE_ENTRENADOR(
    storeUseUserSession.userId,
    datosEntrenador.value
  )
  notyf.success('Tus datos se han actualizado correctamente')
  isLoading.value = false
  emits('updated')
})

const validarGuardar = computed(() => {
  if (
    datosEntrenador.value.acerca_de.length < 3 ||
    datosEntrenador.value.formacion_academica.length < 3 ||
    datosEntrenador.value.formacion_deportiva.length < 3 ||
    datosEntrenador.value.especialidad.length < 3 ||
    datosEntrenador.value.hitos.length < 3
  )
    return false
  return true
})

onMounted(async () => {
  datosEntrenador.value = await GET_DATOS_DEPORTE_ENTRENADOR(storeUseUserSession.userId)
})
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Información Entrenador</h3>
          <p>Edita la informacíon general de tu cuenta</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'entrenador' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="!validarGuardar"
              tabindex="0"
              @keydown.space.prevent="actualizarDatos"
              @click="actualizarDatos"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <div class="form-body">
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <h4>Información Deportiva</h4>
          <p>Otras personas quieren conocerte más</p>
        </div>

        <div class="columns is-multiline">
          <!--Field-->
          <div class="column is-12">
            <VField id="acerca_de" v-slot="{ field }">
              <p>Datos acerca de usted</p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.acerca_de"
                  type="text"
                  placeholder="Ingrese datos de Acerca de usted"
                  autocomplete="given-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="formacion_academica" v-slot="{ field }">
              <p>Formación académica</p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.formacion_academica"
                  type="text"
                  placeholder="Ingrese datos de información académica"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="formacion_deportiva" v-slot="{ field }">
              <p>Formación deportiva</p>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosEntrenador.formacion_deportiva"
                  type="text"
                  placeholder="Ingrese formación deportiva"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="especialidad" v-slot="{ field }">
              <p>Especialidad</p>
              <VControl icon="feather:briefcase">
                <VInput
                  v-model="datosEntrenador.especialidad"
                  type="text"
                  placeholder="Ingrese especialidad"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField id="hitos" v-slot="{ field }">
              <p>Hitos</p>
              <VControl icon="feather:book">
                <VInput
                  v-model="datosEntrenador.hitos"
                  type="text"
                  placeholder="Ingrese hitos"
                  autocomplete="family-name"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <div class="space"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
.space {
  height: 300px;
}
</style>
