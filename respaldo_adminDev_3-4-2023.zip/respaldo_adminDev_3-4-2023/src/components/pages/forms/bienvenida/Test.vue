<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, reactive, ref } from 'vue'

import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { EditarDatosSemicooper } from '../../../../services/models/Deportista'
import { getSemicooper, updateSemicooper } from '/@src/services/deportista'
import { z as zod } from 'zod'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const isLoading = ref(false)
const emit = defineEmits(['update'])
const notyf = useNotyf()
const { y } = useWindowScroll()

const isScrolling = computed(() => {
  return y.value > 40
})

const returnSemicooper = () => {
  datosSemicooper.semicooper = datosSemicooper.semicooper.replace(/e/g, '')
  return datosSemicooper.semicooper
}

const activarBoton = computed(() => {
  let disabled = true
  if (
    Number(datosSemicooper.semicooper) > 0 &&
    datosSemicooper.semicooper.substring(0, 1) != 0
  ) {
    disabled = false
  } else {
    disabled = true
  }
  return disabled
})

const validationSchema = toFormValidator(
  zod.object({
    semicooper: zod
      .string({
        required_error: 'Este campo es requerido',
        invalid_type_error: 'tipo de dato invalido',
      })
      .min(4, 'Escribe minimo 4 digitos'),
  })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    semicooper: '',
  },
})
const onSave = handleSubmit(async () => {
  isLoading.value = true
  await sleep()
  await updateSemicooper(userSession.userId, datosSemicooper)
  emit('update')
  notyf.success('¡Sus cambios han sido guardados con éxito!')
  isLoading.value = false
})

const datosSemicooper = reactive<EditarDatosSemicooper>({
  VAM: '',
  VAM_decimal: '',
  semicooper: '',
  marcas: [],
})

onMounted(async () => {
  const datos = await getSemicooper(userSession.userId)
  datosSemicooper.VAM = datos?.VAM || ''
  datosSemicooper.VAM_decimal = datos?.VAM_decimal || ''
  datosSemicooper.semicooper = datos?.semicooper || ''
  datosSemicooper.marcas = datos?.marcas || []
})
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Información General</h3>
          <p>Edita la informacíon general de tu cuenta</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'deportista' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="activarBoton"
              tabindex="0"
              @keydown.space.prevent="onSave"
              @click="onSave"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <div class="form-body">
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <h4>Test Semicooper:</h4>
          <p>
            Calienta 10 minutos y estira, luego corre la mayor distancia posible durante 6
            minutos apunta la distancia recorrida en metros.
          </p>
          <p>Obligatorio <font size="4" color="red">*</font></p>
        </div>

        <div class="columns is-multiline">
          <!--Field-->
          <div class="column is-6">
            <VField id="semicooper" v-slot="{ field }">
              <VLabel raw class="auth-label"
                >Semicooper <font size="4" color="red">*</font></VLabel
              >
              <VControl icon="feather:user">
                <VInput
                  v-model="datosSemicooper.semicooper"
                  :value="returnSemicooper()"
                  type="text"
                  placeholder="semicooper"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
