<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, ref } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { EditarDatosMorfologia } from '../../../../services/models/Deportista'
import { getMorfologiaDeportista, updateMorfologia } from '/@src/services/deportista'
import { toFormValidator } from '@vee-validate/zod'
import { z as zod } from 'zod'
import { useForm } from 'vee-validate'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const isLoading = ref(false)
const emit = defineEmits(['update'])
const notyf = useNotyf()
const { y } = useWindowScroll()
const somatipos = ['Estomorfico', 'Mesomórfico', 'Endomorfico']
const isScrolling = computed(() => {
  return y.value > 40
})

const returnFcMax = () => {
  datosMorfologia.value.FCmax = datosMorfologia.value.FCmax.replace(/e/g, '')
  return datosMorfologia.value.FCmax
}

const returnFcMin = () => {
  datosMorfologia.value.FCmin = datosMorfologia.value.FCmin.replace(/e/g, '')
  return datosMorfologia.value.FCmin
}

const returnEstatura = () => {
  datosMorfologia.value.estatura = datosMorfologia.value.estatura.replace(/e/g, '')
  return datosMorfologia.value.estatura
}

const returnPeso = () => {
  datosMorfologia.value.peso = datosMorfologia.value.peso.replace(/e/g, '')
  return datosMorfologia.value.peso
}

const activarBoton = computed(() => {
  let disabled = true
  if (
    Number(datosMorfologia.value.FCmax) >= 150 &&
    Number(datosMorfologia.value.FCmax) <= 220 &&
    datosMorfologia.value.FCmax.substring(0, 1) != 0 &&
    Number(datosMorfologia.value.FCmin) >= 35 &&
    Number(datosMorfologia.value.FCmin) <= 80 &&
    datosMorfologia.value.FCmin.substring(0, 1) != 0 &&
    Number(datosMorfologia.value.peso) >= 30 &&
    datosMorfologia.value.peso.substring(0, 1) != 0 &&
    Number(datosMorfologia.value.estatura) >= 80 &&
    Number(datosMorfologia.value.estatura) <= 220 &&
    datosMorfologia.value.estatura.substring(0, 1) != 0
  ) {
    disabled = false
  } else {
    disabled = true
  }
  return disabled
})

const validationSchema = toFormValidator(
  zod.object({
    estatura: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(2, 'Debes escribir dos digitos'),
    peso: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(2, 'Debes escribir dos digitos'),
    fcMax: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(3, 'Debes escribir tres digitos'),
    fcMin: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(2, 'Debes escribir dos digitos'),
  })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    estatura: '',
    peso: '',
    fcMax: '',
    fcMin: '',
  },
})

const onSave = handleSubmit(async () => {
  isLoading.value = true
  await sleep()
  await updateMorfologia(userSession.userId, datosMorfologia.value)
  emit('update')
  notyf.success('¡Sus cambios han sido guardados con éxito!')
  isLoading.value = false
})

const datosMorfologia = ref<EditarDatosMorfologia>({
  FCmax: '',
  FCmin: '',
  FCprom: '',
  distancia: '',
  estatura: '',
  fecha_brazo: '',
  fecha_cintura: '',
  fecha_hombros: '',
  fecha_marca: '',
  fecha_muslo: '',
  fecha_pantorrilla: '',
  fecha_pecho: '',
  grasa: '',
  medida_brazo: '',
  medida_cintura: '',
  medida_hombros: '',
  medida_muslo: '',
  medida_pantorrilla: '',
  medida_pecho: '',
  peso: '',
  ritmo: '',
  somatipo: '',
  tiempo_marca: '',
})

onMounted(async () => {
  datosMorfologia.value = await getMorfologiaDeportista(userSession.userId)
})
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Información General</h3>
          <p>Edita la informacíon general de tu cuenta</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'deportista' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="activarBoton"
              tabindex="0"
              @keydown.space.prevent="onSave"
              @click="onSave"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <div class="form-body">
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <h4>Información Morfología:</h4>
          <p>Otras personas quieren conocerte más</p>
          <p>Obligatorio <font size="4" color="red">*</font></p>
        </div>

        <div class="columns is-multiline">
          <!--Field-->
          <div class="column is-6">
            <VField id="fcMax" v-slot="{ field }">
              <VLabel raw class="auth-label">
                Frecuencia Maxima <font size="4" color="red">* </font>
                <span
                  v-tooltip.primary.bubble="
                    'Frecuencia cardiaca maxima entre [ 150 - 220 ]'
                  "
                  onclick=""
                  color="solid"
                  label="Bubble"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosMorfologia.FCmax"
                  :value="returnFcMax()"
                  type="text"
                  placeholder="FCMax"
                  required
                  autocomplete="off"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField id="fcMin" v-slot="{ field }">
              <VLabel raw class="auth-label">
                Frecuencia Minima <font size="4" color="red">* </font>
                <span
                  v-tooltip.primary.bubble="
                    'Frecuencia cardiaca minima entre [ 35 - 80 ]'
                  "
                  onclick=""
                  color="solid"
                  label="Bubble"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>
              <VControl icon="feather:user">
                <VInput
                  v-model="datosMorfologia.FCmin"
                  :value="returnFcMin()"
                  type="text"
                  placeholder="FCmin"
                  required
                  autocomplete="off"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField id="estatura" v-slot="{ field }">
              <VLabel raw class="auth-label">
                Estatura (cm)<font size="4" color="red">* </font>
                <span
                  v-tooltip.primary.bubble="'Pon una estatura entre 80 y 220 CM'"
                  onclick=""
                  color="solid"
                  label="Bubble"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>
              <VControl icon="feather:briefcase">
                <VInput
                  v-model="datosMorfologia.estatura"
                  :value="returnEstatura()"
                  type="text"
                  required
                  placeholder="Estatura"
                  autocomplete="estatura"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField id="peso" v-slot="{ field }">
              <VLabel raw class="auth-label"
                >Peso >30 (Kg) <font size="4" color="red">* </font>
                <span
                  v-tooltip.primary.bubble="'Pon una peso mayor a 30 KG'"
                  onclick=""
                  color="solid"
                  label="Bubble"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>
              <VControl icon="feather:book">
                <VInput
                  v-model="datosMorfologia.peso"
                  :value="returnPeso()"
                  required
                  type="text"
                  placeholder="Peso"
                  autocomplete="peso"
                />
                <p v-if="field?.errorMessage" class="help is-danger">
                  {{ field.errorMessage }}
                </p>
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-12">
            <VField>
              <VLabel raw class="auth-label"
                >Grasa
                <span
                  v-tooltip.primary.bubble="'Cual es el porcentaje de tu grasa corporal'"
                  onclick=""
                  class="has-tooltip-multiline"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>

              <VControl icon="feather:book">
                <VInput
                  v-model="datosMorfologia.grasa"
                  type="text"
                  placeholder="% Grasa"
                  autocomplete="% Grasa"
                />
              </VControl>
            </VField>
          </div>
          <!--Field-->
          <div class="column is-6">
            <VField v-slot="{ id }">
              <VLabel raw class="auth-label"
                >Somatipo
                <span
                  v-tooltip.primary.bubble="'Selecciona un somatipo'"
                  onclick=""
                  class="has-tooltip-multiline"
                >
                  <i
                    class="iconify"
                    data-icon="feather:help-circle"
                    aria-hidden="true"
                  ></i>
                </span>
              </VLabel>

              <VControl>
                <Multiselect
                  v-model="datosMorfologia.somatipo"
                  :value="datosMorfologia.somatipo"
                  :attrs="{ id }"
                  placeholder="Seleccione uno"
                  :options="somatipos"
                  required
                />
              </VControl>
            </VField>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
