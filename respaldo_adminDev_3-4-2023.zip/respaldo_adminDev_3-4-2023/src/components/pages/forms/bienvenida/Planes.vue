<script setup lang="ts">
import { onBeforeMount, reactive, ref } from 'vue'
import { getDatosDeportista } from '/@src/services/deportista'
import { getPlanesR } from '/@src/services/epayco'
import { useUserSession } from '/@src/stores/userSession'
import { EditarDatosDeportista } from '/@src/services/models/Deportista'
import { valorPlanes } from '../../../../services/models/ValorPlanes'

const userSession = useUserSession()
const emit = defineEmits(['update'])
const planesDisponibles = ref([])
const isLoaderActive = ref(false)
const url = import.meta.env.VITE_APP_URL_SITE
const ePaycoKey = import.meta.env.VITE_APP_PUBLIC_KEY_EPAYCO
const estadoTest = import.meta.env.VITE_APP_EPAYCO_STATE
const datosDeportista = ref<EditarDatosDeportista>({
  nombres: '',
  apellidos: '',
  email: '',
  descripcion: '',
  nameUser: '',
  identificacion: '',
  fecha_nacimiento: '',
  fecha_registro: '',
  telefono: '',
  genero: '',
  ciudad: '',
  pais: '',
  pictureName: '',
})
const planesData = reactive({
  plata: {
    id: '',
    nombre: '',
    valor: 0,
  },
  oro: {
    id: '',
    nombre: '',
    valor: 0,
  },
  platino: {
    id: '',
    nombre: '',
    valor: 0,
  },
  diamante: {
    id: '',
    nombre: '',
    valor: 0,
  },
})

// const respuestaPago = ref({})
// const viewform = ref(false)
// const selected = ref('value_2')

const selectBronce = async () => {
  emit('update')
}

onBeforeMount(async () => {
  datosDeportista.value = await getDatosDeportista(userSession.userId)
  planesDisponibles.value = await getPlanesR()
  planesDisponibles.value.forEach((plan) => {
    switch (plan.id_plan) {
      case 'PlanPlata':
        planesData.plata.id = plan.id_plan
        planesData.plata.valor = plan.amount + ' COP'
        planesData.plata.nombre = plan.description
        break
      case 'PlanOro':
        planesData.oro.id = plan.id_plan
        planesData.oro.nombre = plan.description
        planesData.oro.valor = plan.amount + ' COP'
        break
      case 'PlanPlatino':
        planesData.platino.id = plan.id_plan
        planesData.platino.nombre = plan.description
        planesData.platino.valor = plan.amount + ' COP'
        break
      case 'PlanDiamante':
        planesData.diamante.id = plan.id_plan
        planesData.diamante.nombre = plan.description
        planesData.diamante.valor = plan.amount + ' COP'
        break
      default:
        break
    }
  })
})
</script>

<template>
  <!-- Encabezado -->
  <div class="columns is-multiline">
    <div class="column is-2"></div>
    <RouterLink :to="{ name: 'deportista-profile-profile-view' }" class="column is-2">
      <VButton color="primary" raised @click="selectBronce">
        <label>Plan Bronce</label>
        <br />
        <label>Gratis</label></VButton
      >
    </RouterLink>
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.plata,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.plata.nombre }}</label>
        <br />
        <label>{{ planesData.plata.valor }}</label>
      </VButton>
    </RouterLink>
    <VLoader size="large" :active="isLoaderActive">
      <!-- =====================================================================
      ///////////   Este es su botón de Botón de pago ePayco   ///////////
    ===================================================================== -->
      <form v-if="!datosDeportista.pagoRecurrente">
        <component
          :is="'script'"
          type="application/javascript"
          src="https://checkout.epayco.co/checkout.js"
          :data-epayco-key="ePaycoKey"
          class="epayco-button"
          :data-epayco-amount="valorPlanes.PLATA"
          data-epayco-tax="0.00"
          data-epayco-tax-ico="0.00"
          :data-epayco-tax-base="valorPlanes.PLATA"
          data-epayco-name="Plan Plata"
          data-epayco-description="Plan Plata"
          data-epayco-currency="cop"
          data-epayco-country="CO"
          :data-epayco-test="estadoTest"
          data-epayco-external="false"
          :data-epayco-response="url"
          data-epayco-confirmation=""
          data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
        ></component>
      </form>
      <!-- ================================================================== -->
    </VLoader>

    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.oro,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.oro.nombre }}</label>
        <br />
        <label>{{ planesData.oro.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.ORO"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.ORO"
        data-epayco-name="Plan Oro"
        data-epayco-description="Plan Oro"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.platino,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.platino.nombre }}</label>
        <br />
        <label>{{ planesData.platino.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.PLATINO"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.PLATINO"
        data-epayco-name="Plan Platino"
        data-epayco-description="Plan Platino"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.diamante,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.diamante.nombre }}</label>
        <br />
        <label>{{ planesData.diamante.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.DIAMANTE"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.DIAMANTE"
        data-epayco-name="Plan Diamante"
        data-epayco-description="Plan Diamante"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Uso</div>
    <div class="column is-2">Limitado</div>
    <div class="column is-2">Ilimitado</div>
    <div class="column is-2">Ilimitado</div>
    <div class="column is-2">Ilimitado</div>
    <div class="column is-2">Ilimitado</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Rutina</div>
    <div class="column is-2">Preestablecida</div>
    <div class="column is-2">Entrenador Profesional</div>
    <div class="column is-2">Entrenador Profesional</div>
    <div class="column is-2">Entrenador Profesional</div>
    <div class="column is-2">Entrenador Profesional</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Entrenadores</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Analisis de Datos</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Analisis Tecnico</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Chat con entrenador</div>
    <div class="column is-2">X</div>
    <div class="column is-2">1000 caracteres al mes</div>
    <div class="column is-2">3000 caracteres al mes</div>
    <div class="column is-2">10000 caracteres al mes</div>
    <div class="column is-2">Ilimitado</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Audios con entrenador</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">5 minutos al mes</div>
    <div class="column is-2">10 minutos al mes</div>
    <div class="column is-2">30 minutos al mes</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Encuesta</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Analisis</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Objetivos</div>
    <div class="column is-2">X</div>
    <div class="column is-2">Basico</div>
    <div class="column is-2">Avanzado</div>
    <div class="column is-2">Completo</div>
    <div class="column is-2">Completo</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">LLamada con entrendor</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">SI</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Alianzas comercias, deportivas, productos o servicios</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">Limitadas</div>
    <div class="column is-2">Varias</div>
    <div class="column is-2">Completas</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Referidos</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">1 Nivel</div>
    <div class="column is-2">2 Niveles</div>
    <div class="column is-2">3 Niveles</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Videos</div>
    <div class="column is-2">X</div>
    <div class="column is-2">X</div>
    <div class="column is-2">3 Minutos</div>
    <div class="column is-2">5 Minutos</div>
    <div class="column is-2">10 Minutos</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Garantia</div>
    <div class="column is-2">X</div>
    <div class="column is-2">5 Dias</div>
    <div class="column is-2">5 Dias</div>
    <div class="column is-2">10 Dias</div>
    <div class="column is-2">10 Dias</div>
  </div>
  <hr />
  <div class="columns is-mobile">
    <div class="column is-2">Congelación</div>
    <div class="column is-2">X</div>
    <div class="column is-2">10 dias cada 12 meses</div>
    <div class="column is-2">10 dias cada 10 meses</div>
    <div class="column is-2">15 dias cada 8 meses</div>
    <div class="column is-2">20 dias cada 8 meses</div>
  </div>
  <hr />
  <div class="columns is-multiline">
    <div class="column is-2"></div>
    <RouterLink :to="{ name: 'deportista-profile-profile-view' }" class="column is-2">
      <VButton color="primary" raised @click="selectBronce">
        <label>Plan Bronce</label>
        <br />
        <label>Gratis</label></VButton
      >
    </RouterLink>
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.plata,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.plata.nombre }}</label>
        <br />
        <label>{{ planesData.plata.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
      ///////////   Este es su botón de Botón de pago ePayco   ///////////
    ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.PLATA"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.PLATA"
        data-epayco-name="Plan Plata"
        data-epayco-description="Plan Plata"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.oro,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.oro.nombre }}</label>
        <br />
        <label>{{ planesData.oro.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.ORO"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.ORO"
        data-epayco-name="Plan Oro"
        data-epayco-description="Plan Oro"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.platino,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.platino.nombre }}</label>
        <br />
        <label>{{ planesData.platino.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.PLATINO"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.PLATINO"
        data-epayco-name="Plan Platino"
        data-epayco-description="Plan Platino"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
    <RouterLink
      v-if="datosDeportista.pagoRecurrente"
      :to="{
        name: 'deportista-Subscribe-planS',
        params: {
          planS: JSON.stringify({
            plan: planesData.diamante,
            cliente: datosDeportista,
          }),
        },
      }"
      class="column is-2"
    >
      <VButton color="primary" raised>
        <label>{{ planesData.diamante.nombre }}</label>
        <br />
        <label>{{ planesData.diamante.valor }}</label>
      </VButton>
    </RouterLink>
    <!-- =====================================================================
                  ///////////   Este es su botón de Botón de pago ePayco   ///////////
                ===================================================================== -->
    <form v-if="!datosDeportista.pagoRecurrente">
      <component
        :is="'script'"
        type="application/javascript"
        src="https://checkout.epayco.co/checkout.js"
        :data-epayco-key="ePaycoKey"
        class="epayco-button"
        :data-epayco-amount="valorPlanes.DIAMANTE"
        data-epayco-tax="0.00"
        data-epayco-tax-ico="0.00"
        :data-epayco-tax-base="valorPlanes.DIAMANTE"
        data-epayco-name="Plan Diamante"
        data-epayco-description="Plan Diamante"
        data-epayco-currency="cop"
        data-epayco-country="CO"
        :data-epayco-test="estadoTest"
        data-epayco-external="false"
        :data-epayco-response="url"
        data-epayco-confirmation=""
        data-epayco-button="https://multimedia.epayco.co/dashboard/btns/btn1.png"
      ></component>
    </form>
    <!-- ================================================================== -->
  </div>
</template>

<style lang="scss">
@import '/@src/scss/abstracts/all';

.is-navbar {
  .account-wrapper {
    margin-top: 30px;
  }
}

.account-wrapper {
  padding-bottom: 60px;

  .account-box {
    @include vuero-s-card;

    &.is-navigation {
      .media-flex-center {
        padding-bottom: 20px;

        .flex-meta {
          span {
            &:first-child {
              font-size: 1.3rem;
            }
          }
        }
      }

      .account-menu {
        .account-menu-item {
          display: flex;
          align-items: center;
          padding: 12px 16px;
          border: 1px solid transparent;
          border-radius: 8px;
          margin-bottom: 5px;
          transition: all 0.3s; // transition-all test

          &.router-link-exact-active {
            box-shadow: var(--light-box-shadow);
            border-color: var(--fade-grey-dark-3);

            span,
            i {
              color: var(--primary);
            }

            .end {
              display: block;
            }
          }

          &:not(.router-link-exact-active) {
            &:hover {
              background: var(--fade-grey-light-3);
            }
          }

          i {
            margin-right: 8px;
            font-size: 1.1rem;
            color: var(--light-text);

            &.fas,
            .fal,
            .far {
              font-size: 0.9rem;
            }
          }

          span {
            font-family: var(--font-alt);
            font-size: 0.95rem;
            color: var(--dark-text);
          }

          .end {
            margin-left: auto;
            display: none;
          }
        }
      }
    }

    &.is-form {
      padding: 0;

      &.is-footerless {
        padding-bottom: 20px;
      }

      .form-head,
      .form-foot {
        padding: 12px 20px;

        .form-head-inner,
        .form-foot-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
      }

      .form-head {
        border-bottom: 1px solid var(--fade-grey-dark-3);
        transition: all 0.3s; // transition-all test

        &.is-stuck {
          background: var(--white);
          padding-right: 80px;
          border-left: 1px solid var(--fade-grey-dark-3);
        }

        .left {
          h3 {
            font-family: var(--font-alt);
            font-size: 1.2rem;
            line-height: 1.3;
          }

          p {
            font-size: 0.95rem;
          }
        }
      }

      .form-foot {
        border-top: 1px solid var(--fade-grey-dark-3);
      }

      .form-body {
        padding: 20px;

        .fieldset {
          padding: 20px 0;
          max-width: 480px;
          margin: 0 auto;

          .fieldset-heading {
            margin-bottom: 20px;

            h4 {
              font-family: var(--font-alt);
              font-weight: 600;
              font-size: 1rem;
            }

            p {
              font-size: 0.9rem;
            }
          }

          .v-avatar {
            position: relative;
            display: block;
            margin: 0 auto;

            .edit-button {
              position: absolute;
              bottom: 0;
              right: 0;
            }
          }

          .setting-list {
            .setting-form {
              text-align: center;

              .filepond-profile-wrap {
                margin: 0 auto 10px !important;
              }
            }

            .setting-item {
              display: flex;
              align-items: center;
              margin-bottom: 24px;

              .icon-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                background: var(--fade-grey-light-2);
                border: 1px solid var(--fade-grey-dark-3);
                color: var(--light-text);

                &.has-img {
                  border-color: var(--primary);

                  img {
                    width: 36px;
                    min-width: 36px;
                    height: 36px;
                  }
                }

                i {
                  font-size: 1.4rem;
                }
              }

              img {
                display: block;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                border: 1px solid transparent;
              }

              .meta {
                margin-left: 10px;

                > span {
                  font-family: var(--font);
                  display: block;

                  &:first-child {
                    font-family: var(--font-alt);
                    font-weight: 600;
                    color: var(--dark-text);
                    font-size: 0.9rem;
                  }

                  &:nth-child(2),
                  &:nth-child(3) {
                    font-size: 0.85rem;
                    color: var(--light-text);

                    i {
                      position: relative;
                      top: -2px;
                      font-size: 4px;
                      margin: 0 6px;
                    }
                  }

                  &:nth-child(3) {
                    color: var(--primary);
                  }

                  span {
                    display: inline-block;
                  }
                }
              }

              .end {
                margin-left: auto;
              }
            }
          }
        }
      }
    }
  }
}

.is-dark {
  .account-wrapper {
    .account-box {
      @include vuero-card--dark;

      &.is-navigation {
        .account-menu {
          .account-menu-item {
            &.router-link-exact-active {
              background: var(--dark-sidebar-light-8);
              border-color: var(--dark-sidebar-light-12);

              i,
              span {
                color: var(--primary);
              }
            }

            &:not(.router-link-exact-active) {
              &:hover {
                background: var(--dark-sidebar-light-10);
              }
            }

            span {
              color: var(--dark-dark-text);
            }
          }
        }
      }

      &.is-form {
        .form-head,
        .form-foot {
          border-color: var(--dark-sidebar-light-12);
        }

        .form-head {
          &.is-stuck {
            background: var(--dark-sidebar);
            border-color: var(--dark-sidebar-light-6);
          }

          .left {
            h3 {
              color: var(--dark-dark-text);
            }
          }
        }

        .form-body {
          .fieldset {
            .fieldset-heading {
              h4 {
                color: var(--dark-dark-text);
              }
            }

            .setting-list {
              .setting-item {
                > img,
                > .icon-wrap,
                > .icon-wrap img {
                  border-color: var(--dark-sidebar-light-12);
                }

                > .icon-wrap {
                  background: var(--dark-sidebar-light-2);
                }

                .meta {
                  > span {
                    &:nth-child(3) {
                      color: var(--primary);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
