<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { z as zod } from 'zod'
import { EditarDatosDeportista } from '/@src/services/models/Deportista'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'
import { preview, addPicture } from '/@src/services/managePictures'
import {
  getCiudades,
  getDatosDeportista,
  getPaises,
  updateDatosDeportista,
} from '/@src/services/deportista'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const notif = useNotyf()
const isLoading = ref(false)
const uploadModalOpen = ref(false)
const notyf = useNotyf()
const { y } = useWindowScroll()

const generoMensaje = ref('')
const paisMensaje = ref('')
const ciudadMensaje = ref('')
const nacimientoMensaje = ref('')
const paises = ref('')
const ciudades = ref('')
const fechaM = ref('')

const emit = defineEmits(['update'])

let imagen = reactive({
  accept: false,
  message: '',
  dataUrl: null,
})
const imgProfile = reactive({
  picture: '',
})

const isScrolling = computed(() => {
  return y.value > 40
})

const closeModal = () => {
  if (imagen.dataUrl) {
    //cargar imagen
    console.log('preview en acas')
    const img = document.getElementById('ImageUser')
    if (img) {
      img.setAttribute('src', imagen.dataUrl)
      console.log('cargar nueva imgaen preview')
    }
  }
  uploadModalOpen.value = false
}

const previewImage = async (event) => {
  const prevImagen = await preview(event)
  imgProfile.picture = prevImagen.file
  if (prevImagen.accept) {
    const file = event.target.files[0]
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = async (e) => {
      imagen.dataUrl = e.target.result
      imagen.message = prevImagen.message
      imagen.accept = prevImagen.accept
    }
  } else {
    imagen.accept = false
    imagen.message = ''
    imagen.dataUrl = null
    notif.error('La extension de archivo o tamaño no cumple con los requisitos')
  }
}
const activarBoton = computed(() => {
  let disabled = true
  if (
    Number(datosDeportista.value.identificacion) > 0 &&
    Number(datosDeportista.value.telefono) > 0 &&
    datosDeportista.value.pais != '' &&
    datosDeportista.value.pais != null &&
    datosDeportista.value.genero != '' &&
    datosDeportista.value.genero != null &&
    datosDeportista.value.ciudad != '' &&
    datosDeportista.value.ciudad != null &&
    datosDeportista.value.fecha_nacimiento != null
  ) {
    disabled = false
  } else {
    disabled = true
  }

  return disabled
})

const maxDate = async () => {
  const fecha = await new Date()
  const year = fecha.getFullYear() - 13
  const mes = fecha.getMonth() + 1
  const dia = fecha.getDate()
  const fechaMaxima = await new Date(mes + ' ' + dia + ' ' + year)
  return fechaMaxima
}

const selectedGender = () => {
  let existe = false
  if (datosDeportista.value.genero == null) {
    generoMensaje.value = '"Seleccione un genero por favor"'
    existe = true
  }
  return existe
}

const selectedNacimiento = () => {
  let existe = false
  if (datosDeportista.value.fecha_nacimiento == null) {
    nacimientoMensaje.value = 'Selecciona una fecha de nacimiento'
    existe = true
  }
  return existe
}

const selectedPais = () => {
  let existe = false
  if (datosDeportista.value.pais == null) {
    paisMensaje.value = '"Seleccione un país por favor"'
    datosDeportista.value.ciudad = null
    existe = true
  }
  return existe
}

const selectedCiudad = () => {
  let existe = false
  if (datosDeportista.value.ciudad == null) {
    ciudadMensaje.value = '"Seleccione una cidad por favor"'
    existe = true
  }
  return existe
}

const returnIdentificacion = () => {
  datosDeportista.value.identificacion = datosDeportista.value.identificacion.replace(
    /e/g,
    ''
  )
  return datosDeportista.value.identificacion
}

const returnTelefono = () => {
  datosDeportista.value.telefono = datosDeportista.value.telefono.replace(/e/g, '')
  return datosDeportista.value.telefono
}

const returnNombre = () => {
  datosDeportista.value.nombres = datosDeportista.value.nombres.replace(/[0-9]/g, '')
  return datosDeportista.value.nombres
}

const returnApellido = () => {
  datosDeportista.value.apellidos = datosDeportista.value.apellidos.replace(/[0-9]/gi, '')
  return datosDeportista.value.apellidos
}
const validationSchema = toFormValidator(
  zod.object({
    nombres: zod
      .string({
        required_error: 'Nombres requeridos',
        invalid_type_error: 'Caracteres invalidos',
      })
      .min(3, 'Minimo tres caracteres'),
    apellidos: zod
      .string({
        required_error: 'Apellidos requeridos',
        invalid_type_error: 'Caracteres invalidos',
      })
      .min(3, 'Minimo tres caracteres'),
    identificacion: zod
      .string({
        required_error: 'Identificación requerida',
        invalid_type_error: 'Identificación tipo invalido',
      })
      .min(8, 'El número de digitos minimo es 8'),
    telefono: zod
      .string({
        required_error: 'Telefono requerido',
        invalid_type_error: 'Telefono tipo invalido',
      })
      .min(7, 'El número de digitos minimo es 7'),
  })
)

const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    identificacion: '',
    telefono: '',
  },
})

const onSave = handleSubmit(async () => {
  isLoading.value = true
  await sleep()
  await updateDatosDeportista(userSession.userId, datosDeportista.value)
  if (imgProfile.picture) {
    addPicture(imgProfile.picture, userSession.userId)
  }
  emit('update')
  notyf.success('¡Sus cambios han sido guardados con éxito!')
  isLoading.value = false
})

const datosDeportista = ref<EditarDatosDeportista>({
  nombres: '',
  apellidos: '',
  email: '',
  descripcion: '',
  nameUser: '',
  identificacion: '',
  fecha_nacimiento: '',
  fecha_registro: '',
  telefono: '',
  genero: '',
  ciudad: '',
  pais: '',
  pictureName: '',
})

onMounted(async () => {
  fechaM.value = await maxDate()
  paises.value = await getPaises()
  datosDeportista.value = await getDatosDeportista(userSession.userId)
  // Imagen(datosDeportista.value.pictureName)
})

watch(
  () => datosDeportista.value.pais,
  async (pais, prevPais) => {
    if (prevPais != '') {
      datosDeportista.value.ciudad = null
    }
    ciudades.value = await getCiudades(pais)
  }
)
</script>

<template>
  <div class="account-box is-form is-footerless">
    <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
      <div class="form-head-inner">
        <div class="left">
          <h3>Información General</h3>
          <p>Edita la informacíon general de tu cuenta</p>
        </div>
        <div class="right">
          <div class="buttons">
            <VButton
              :to="{ name: 'deportista-rutinas' }"
              icon="lnir lnir-arrow-left rem-100"
              light
              dark-outlined
            >
              Regresar
            </VButton>
            <VButton
              color="primary"
              raised
              :loading="isLoading"
              :disabled="activarBoton"
              tabindex="0"
              @keydown.space.prevent="onSave"
              @click="onSave"
            >
              Guardar cambios
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <form action="signup-form" @submit="onSave">
      <div class="form-body">
        <!--Fieldset-->
        <div class="fieldset">
          <div class="fieldset-heading">
            <h4>
              Foto de perfil
              <span
                v-tooltip.primary.bubble="'Maximo 2MB, formato jpg, png'"
                onclick=""
                color="solid"
                label="Bubble"
              >
                <i class="iconify" data-icon="feather:help-circle" aria-hidden="true"></i>
              </span>
            </h4>
            <p>La foto de perfil ayuda a que otras personas te reconozcan</p>
          </div>
          <div class="picture-selector">
            <div class="image-container">
              <img id="ImageUser" :src="userSession.imagenUrl" alt="" />
              <div
                class="upload-button"
                role="button"
                tabindex="0"
                @keydown.space.prevent="uploadModalOpen = true"
                @click="uploadModalOpen = true"
              >
                <i aria-hidden="true" class="iconify" data-icon="feather:plus"></i>
              </div>
            </div>
          </div>
        </div>
        <!--Fieldset-->
        <div class="fieldset">
          <div class="fieldset-heading">
            <h4>Información Personal</h4>
            <p>Otras personas quieren conocerte más</p>
            <p>Obligatorio <font size="4" color="red">*</font></p>
          </div>

          <div class="columns is-multiline">
            <!--Nombres-->
            <div class="column is-6">
              <VField id="nombres" v-slot="{ field }">
                <VLabel raw class="auth-label">
                  Nombres <font size="4" color="red">* </font>
                </VLabel>
                <VControl icon="feather:user">
                  <VInput
                    v-model="datosDeportista.nombres"
                    :value="returnNombre()"
                    disabled
                    type="text"
                    placeholder="Nombres"
                    autocomplete="given-name"
                  />
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VControl>
              </VField>
            </div>

            <!--Apellidos-->
            <div class="column is-6">
              <VField id="apellidos" v-slot="{ field }">
                <VLabel raw class="auth-label">
                  Apellidos <font size="4" color="red">* </font>
                </VLabel>
                <VControl icon="feather:user">
                  <VInput
                    v-model="datosDeportista.apellidos"
                    :value="returnApellido()"
                    type="text"
                    disabled
                    placeholder="Apellidos"
                    autocomplete="family-name"
                  />
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VControl>
              </VField>
            </div>

            <!--Documento Identificacion-->
            <div class="column is-6">
              <VField id="identificacion" v-slot="{ field }">
                <VLabel raw class="auth-label"
                  >Documento de identificación <font size="4" color="red">* </font>
                  <span
                    v-tooltip.primary.bubble="'Para posible facturación'"
                    onclick=""
                    color="solid"
                    label="Bubble"
                  >
                    <i
                      class="iconify"
                      data-icon="feather:help-circle"
                      aria-hidden="true"
                    ></i> </span
                ></VLabel>
                <VControl icon="feather:briefcase">
                  <VInput
                    v-model="datosDeportista.identificacion"
                    :value="returnIdentificacion()"
                    type="text"
                    placeholder="Número de Identificación"
                    required
                    autocomplete="off"
                  />
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VControl>
              </VField>
            </div>

            <!-- Genero  -->
            <div class="column is-6">
              <VField v-slot="{ id }">
                <VLabel raw class="auth-label">
                  Genero <font size="4" color="red">* </font>
                </VLabel>
                <VControl>
                  <Multiselect
                    v-model="datosDeportista.genero"
                    :value="datosDeportista.genero"
                    :attrs="{ id }"
                    placeholder="Seleccione uno"
                    :options="['Masculino', 'Femenino']"
                    required
                  />
                  <p v-if="selectedGender()" class="help is-danger">
                    {{ generoMensaje }}
                  </p>
                </VControl>
              </VField>
            </div>

            <!-- Field  -->
            <div class="column is-6">
              <VField v-slot="{ id }">
                <VLabel raw class="auth-label">
                  Pais <font size="4" color="red">* </font>
                </VLabel>
                <VControl>
                  <Multiselect
                    v-model="datosDeportista.pais"
                    :value="datosDeportista.pais"
                    :attrs="{ id }"
                    placeholder="Seleccione uno"
                    :options="paises"
                    required
                  />
                  <p v-if="selectedPais()" class="help is-danger">
                    {{ paisMensaje }}
                  </p>
                </VControl>
              </VField>
            </div>
            <!-- Field  -->
            <div class="column is-6">
              <VField v-slot="{ id }">
                <VLabel raw class="auth-label">
                  Ciudad <font size="4" color="red">* </font>
                </VLabel>
                <VControl>
                  <Multiselect
                    v-model="datosDeportista.ciudad"
                    :value="datosDeportista.ciudad"
                    :attrs="{ id }"
                    placeholder="Seleccione uno"
                    :options="ciudades"
                    required
                  />
                  <p v-if="selectedCiudad()" class="help is-danger">
                    {{ ciudadMensaje }}
                  </p>
                </VControl>
              </VField>
            </div>

            <!--Field-->
            <div class="column is-6">
              <VField>
                <VLabel raw class="auth-label"
                  >Usuario
                  <span
                    v-tooltip.primary.bubble="'Apodo (No es obligatorio)'"
                    onclick=""
                    color="solid"
                    label="Bubble"
                  >
                    <i
                      class="iconify"
                      data-icon="feather:help-circle"
                      aria-hidden="true"
                    ></i> </span
                ></VLabel>
                <VControl icon="feather:user">
                  <VInput
                    v-model="datosDeportista.nameUser"
                    type="text"
                    placeholder="Nombre de usuario"
                    autocomplete="family-name"
                  />
                </VControl>
              </VField>
            </div>
            <!--Field-->
            <div class="column is-6">
              <VField>
                <VLabel raw class="auth-label"
                  >Correo <font size="4" color="red">*</font></VLabel
                >
                <VControl icon="feather:user">
                  <VInput
                    v-model="datosDeportista.email"
                    disabled
                    type="text"
                    placeholder="Correo"
                    autocomplete="correo"
                  />
                </VControl>
              </VField>
            </div>

            <!--Field-->
            <div class="column is-6">
              <VField id="telefono" v-slot="{ field }">
                <VLabel raw class="auth-label"
                  >Telefono <font size="4" color="red">* </font
                  ><span
                    v-tooltip.primary.bubble="
                      'Completa este campo con el número de cotacto'
                    "
                    onclick=""
                    color="solid"
                    label="Bubble"
                  >
                    <i
                      class="iconify"
                      data-icon="feather:help-circle"
                      aria-hidden="true"
                    ></i> </span
                ></VLabel>
                <VControl icon="feather:phone">
                  <VInput
                    v-model="datosDeportista.telefono"
                    :value="returnTelefono()"
                    type="text"
                    placeholder="Número de teléfono"
                    required
                    autocomplete="off"
                  />
                  <p v-if="field?.errorMessage" class="help is-danger">
                    {{ field.errorMessage }}
                  </p>
                </VControl>
              </VField>
            </div>
            <!--Field-->
            <div class="column is-6">
              <VField>
                <VLabel raw class="auth-label"
                  >Fecha de nacimiento <font size="4" color="red">* </font
                  ><span
                    v-tooltip.primary.bubble="
                      'Completa este campo con tu fecha de nacimiento'
                    "
                    onclick=""
                    color="solid"
                    label="Bubble"
                  >
                    <i
                      class="iconify"
                      data-icon="feather:help-circle"
                      aria-hidden="true"
                    ></i> </span
                ></VLabel>
                <VControl icon="feather:calendar">
                  <ClientOnly>
                    <VDatePicker
                      v-model="datosDeportista.fecha_nacimiento"
                      :max-date="fechaM"
                      color="green"
                      trim-weeks
                    >
                      <template #default="{ inputValue, inputEvents }">
                        <VField>
                          <VControl icon="feather:calendar">
                            <VInput :value="inputValue" v-on="inputEvents" />
                          </VControl>
                        </VField>
                      </template>
                    </VDatePicker>
                  </ClientOnly>
                </VControl>
                <p v-if="selectedNacimiento()" class="help is-danger">
                  {{ nacimientoMensaje }}
                </p>
              </VField>
            </div>
          </div>
        </div>
      </div>
    </form>
    <!-- upload modal -->
    <VModal
      :open="uploadModalOpen"
      title="Sube tu foto"
      actions="center"
      size="small"
      @close="uploadModalOpen = false"
    >
      <template #content>
        <div class="has-text-centered">
          <div class="upload-demo-wrap">
            <VAvatar size="big" :picture="imagen.dataUrl" />
          </div>
        </div>
      </template>
      <template #cancel><wbr /></template>
      <template #action>
        <VField grouped>
          <VControl>
            <div class="file">
              <label class="file-label">
                <input
                  class="file-input"
                  type="file"
                  name="resume"
                  @change="previewImage($event)"
                />
                <span class="file-cta">
                  <span class="file-icon">
                    <i aria-hidden="true" class="fas fa-cloud-upload-alt"></i>
                  </span>
                  <span class="file-label"> Choose a file… </span>
                </span>
              </label>
            </div>
          </VControl>
          <VControl>
            <VButton
              class="upload-result"
              size="big"
              outlined
              @keydown.space.prevent="uploadModalOpen = false"
              @click="closeModal()"
            >
              Confirm
            </VButton>
          </VControl>
        </VField>
      </template>
    </VModal>
  </div>
</template>

<style lang="scss">
.picture-selector,
.skill-picture-selector {
  width: 100%;
  text-align: center;

  .image-container {
    position: relative;
    width: 110px;
    height: 110px;
    margin: 10px auto;
    border-radius: var(--radius-rounded);

    img {
      width: 110px;
      height: 110px;
      border-radius: var(--radius-rounded);
      display: block;
      border: 4px solid #e8e8e8;
      margin-left: -1px;
    }

    .upload-button {
      position: absolute;
      bottom: 18px;
      right: 0;
      width: 36px;
      height: 36px;
      display: flex;
      justify-content: center;
      align-items: center;
      background: var(--white);
      border-radius: var(--radius-rounded);
      border: 1px solid var(--fade-grey-dark-4);
      z-index: 5;
      transition: all 0.3s; // transition-all test
      cursor: pointer;

      &:hover,
      &:focus {
        box-shadow: var(--light-box-shadow);
      }

      svg {
        height: 16px;
        width: 16px;
        color: var(--dark-text);
      }
    }
  }
}

.picture-selector {
  .image-container {
    img {
      border-color: var(--dark-sidebar-light-10);
    }

    .upload-button {
      background-color: var(--dark-sidebar-light-2);
      border-color: var(--dark-sidebar-light-10);

      svg {
        color: var(--light-text);
        stroke: var(--light-text);
      }
    }
  }
}
</style>
