<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { EditarDatosObjetivos } from '../../../../services/models/Deportista'
import {
  getCategorias,
  getObjetivos,
  getSubCategorias,
  updateObjetivo,
} from '/@src/services/deportista'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const isLoading = ref(false)
const notyf = useNotyf()
const { y } = useWindowScroll()

const categorias = ref('')
const subCategorias = ref('')

const generalMensaje = ref('')
const deporteMensaje = ref('')
const fechaMensaje = ref('')

const inputDeporte = ref(null)
const inputGeneral = ref(null)
const inputEspecifico = ref('')
const especificoHoras = ref('')
const especificotext = ref('')
const inputEspecificoH = ref(null)
const inputEspecificoM = ref(null)
const inputEspecificoS = ref(null)
const inputFecha = ref(null)
const nombreObjetivo = ref('')

const emit = defineEmits(['update'])
const isScrolling = computed(() => {
  return y.value > 40
})

// const activarBoton = computed(() => {
// let disabled = true
// if (datosDeportes.edad_deportiva != null) {
//   disabled = false
// } else {
//   disabled = true
// }
//   return disabled
// })

const estadoAddObjetivos = computed(() => {
  let botonLesion = true
  especifico()
  asignarEspecifico()
  if (
    inputGeneral.value != null &&
    inputFecha.value != null &&
    nombreObjetivo.value != '' &&
    inputEspecifico.value != ''
  ) {
    botonLesion = false
  } else {
    botonLesion = true
  }
  if (datosObjetivos.meta_deportiva.length >= 5) {
    botonLesion = true
  }
  return botonLesion
})

const especifico = async () => {
  if (inputEspecificoH.value && inputEspecificoM.value && inputEspecificoS.value) {
    especificoHoras.value =
      inputEspecificoH.value + ':' + inputEspecificoM.value + ':' + inputEspecificoS.value
  } else {
    especificoHoras.value = null
  }
}

const asignarEspecifico = () => {
  if (especificoHoras.value) {
    inputEspecifico.value = especificoHoras.value
  } else {
    inputEspecifico.value = especificotext.value
  }
}

const selectedDeporte = () => {
  let existe = false
  if (inputDeporte.value == null) {
    inputGeneral.value = null
    deporteMensaje.value = '"Escoge un Deporte"'
    existe = true
  }
  return existe
}

const selectedGeneral = () => {
  let existe = false
  if (inputGeneral.value == null) {
    generalMensaje.value = '"Escoge un objetivo general"'
    existe = true
  }
  return existe
}

const selectedFecha = () => {
  let existe = false
  if (inputFecha.value == null) {
    fechaMensaje.value = '"Escoge una fecha"'
    existe = true
  }
  return existe
}

const addObjetivo = () => {
  datosObjetivos.meta_deportiva.push({
    deporte: inputDeporte.value,
    general: inputGeneral.value,
    especifico: inputEspecifico.value,
    especificoH: inputEspecificoH.value,
    especificoM: inputEspecificoM.value,
    especificoS: inputEspecificoS.value,
    fecha: inputFecha.value,
    nombre: nombreObjetivo.value,
  })

  inputDeporte.value = null
  inputGeneral.value = null
  inputEspecifico.value = ''
  inputEspecificoH.value = null
  inputEspecificoM.value = null
  inputEspecificoS.value = null
  especificotext.value = ''
  inputFecha.value = null
  nombreObjetivo.value = ''
}

const eliminarMeta = (meta: number) => {
  datosObjetivos.meta_deportiva.splice(meta, 1)
}

const onSave = async () => {
  isLoading.value = true
  await sleep()
  await updateObjetivo(userSession.userId, datosObjetivos)
  emit('update')
  notyf.success('¡Sus cambios han sido guardados con éxito!')
  isLoading.value = false
}

const datosObjetivos = reactive<EditarDatosObjetivos>({
  meta_deportiva: [],
  dias_entrenamiento: {},
})

onMounted(async () => {
  const datos = await getObjetivos(userSession.userId)
  categorias.value = await getCategorias()
  datosObjetivos.meta_deportiva = datos?.meta_deportiva || []
  datosObjetivos.dias_entrenamiento = datos?.dias_entrenamiento || {}
})

watch(inputDeporte, async (newDeporte) => {
  inputGeneral.value = null
  inputEspecificoH.value = null
  inputEspecificoM.value = null
  inputEspecificoS.value = null
  inputEspecifico.value = ''
  subCategorias.value = await getSubCategorias(newDeporte)
})
</script>

<template>
  <div class="page-content-inner">
    <!--Edit Profile-->
    <div class="account-wrapper">
      <div class="columns">
        <!--Navigation-->
        <div class="column is-12">
          <div class="account-box is-form is-footerless">
            <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
              <div class="form-head-inner">
                <div class="left">
                  <h3>Información General</h3>
                  <p>Edita la informacíon general de tu cuenta</p>
                </div>
                <div class="right">
                  <div class="buttons">
                    <VButton
                      :to="{ name: 'deportista' }"
                      icon="lnir lnir-arrow-left rem-100"
                      light
                      dark-outlined
                    >
                      Regresar
                    </VButton>
                    <VButton
                      color="primary"
                      raised
                      :loading="isLoading"
                      :disabled="activarBoton"
                      tabindex="0"
                      @keydown.space.prevent="onSave"
                      @click="onSave"
                    >
                      Guardar cambios
                    </VButton>
                  </div>
                </div>
              </div>
            </div>
            <div class="p-6">
              <!--Fieldset-->
              <div class="fieldset">
                <div class="fieldset-heading">
                  <h4>Información Objetivos:</h4>
                  <p>Nos gustaria que registraras tus Objetivos para conocerte mejor</p>
                  <p>Obligatorio <font size="4" color="red">*</font></p>
                </div>
                <div class="m-3">
                  <VButton
                    color="primary"
                    outlined
                    :disabled="estadoAddObjetivos"
                    @click="addObjetivo"
                  >
                    Añadir Objetivos
                  </VButton>
                </div>
                <div class="columns is-multiline">
                  <!-- Field  -->
                  <div class="column is-3">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Deporte <font size="4" color="red">*</font></VLabel
                        >
                        <Multiselect
                          v-model="inputDeporte"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="categorias"
                          required
                        />
                        <p v-if="selectedDeporte()" class="help is-danger">
                          {{ deporteMensaje }}
                        </p>
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-3">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label"
                          >Objetivo General <font size="4" color="red">*</font></VLabel
                        >
                        <Multiselect
                          v-model="inputGeneral"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="subCategorias"
                          required
                        />
                        <p v-if="selectedGeneral()" class="help is-danger">
                          {{ generalMensaje }}
                        </p>
                      </VControl>
                    </VField>
                  </div>
                  <!--Field-->
                  <div class="column is-3">
                    <VField>
                      <VLabel raw class="auth-label"
                        >Fecha <font size="4" color="red">*</font></VLabel
                      >
                      <VControl>
                        <ClientOnly>
                          <VDatePicker
                            v-model="inputFecha"
                            :min-date="new Date()"
                            color="green"
                            trim-weeks
                          >
                            <template #default="{ inputValue, inputEvents }">
                              <VField>
                                <VControl icon="feather:calendar">
                                  <VInput :value="inputValue" v-on="inputEvents" />
                                </VControl>
                              </VField>
                            </template>
                          </VDatePicker>
                        </ClientOnly>
                        <p v-if="selectedFecha()" class="help is-danger">
                          {{ fechaMensaje }}
                        </p>
                      </VControl>
                    </VField>
                  </div>
                  <!--Field-->
                  <div class="column is-3">
                    <VField>
                      <VLabel raw class="auth-label"
                        >Nombre Objetivo<font size="4" color="red">*</font></VLabel
                      >
                      <VControl icon="feather:user">
                        <VInput
                          v-model="nombreObjetivo"
                          type="text"
                          placeholder="Nombre Objetivo"
                          autocomplete="off"
                        />
                        <p v-if="nombreObjetivo === ''" class="help is-danger">
                          Dale un nombre al objetivo
                        </p>
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div
                    v-if="
                      inputDeporte === 'Atletismo' ||
                      inputDeporte === 'Ciclismo' ||
                      inputDeporte === 'Natacion' ||
                      inputDeporte === 'Triatlon'
                    "
                    class="column is-6"
                  >
                    <label raw class="auth-label">
                      Tiempo Marca <font size="4" color="red">*</font>
                    </label>
                    <div class="columns is-multiline">
                      <div class="column is-4">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="inputEspecificoH"
                              type="number"
                              placeholder="HH"
                              autocomplete="off"
                              min="0"
                            />
                            <p v-if="inputEspecificoH === null" class="help is-danger">
                              Digita una Hora
                            </p>
                          </VControl>
                        </VField>
                      </div>
                      <div class="column is-4">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="inputEspecificoM"
                              type="number"
                              placeholder="MM"
                              autocomplete="off"
                              min="0"
                            />

                            <p v-if="inputEspecificoM === null" class="help is-danger">
                              Digita los minutos
                            </p>
                          </VControl>
                        </VField>
                      </div>
                      <div class="column is-4">
                        <VField>
                          <VControl>
                            <VInput
                              v-model="inputEspecificoS"
                              type="number"
                              placeholder="SS"
                              autocomplete="off"
                              min="0"
                            />
                            <p v-if="inputEspecificoS === null" class="help is-danger">
                              Digita los Segundos
                            </p>
                          </VControl>
                        </VField>
                      </div>
                    </div>
                  </div>
                  <!--Field-->
                  <div
                    v-if="inputDeporte === 'Gimnasio' || inputDeporte === 'Vida Activa'"
                    class="column is-6"
                  >
                    <VField>
                      <VLabel raw class="auth-label"
                        >Objetivo Especifico <font size="4" color="red">*</font></VLabel
                      >
                      <VControl>
                        <VTextarea
                          v-model="especificotext"
                          type="text"
                          placeholder="Objetivo Especifico"
                          autocomplete="off"
                        />
                        <p v-if="inputEspecifico === ''" class="help is-danger">
                          Ingresa el objetivo especifico
                        </p>
                      </VControl>
                    </VField>
                  </div>
                </div>
              </div>
              <div class="mt-6">
                <h1><u>Objetivos Registrados</u></h1>
              </div>
              <div
                v-for="(meta, index) in datosObjetivos.meta_deportiva"
                :key="meta"
                class="columns is-multiline m-4"
              >
                <br />
                <div class="mx-2">
                  <h1><u>Meta</u></h1>
                  <label for="meta"> {{ meta.deporte }}</label>
                </div>
                <div class="mx-2">
                  <h1><u>General</u></h1>
                  <label for="meta"> {{ meta.general }}</label>
                </div>
                <div class="mx-2">
                  <h1><u>Especialidad</u></h1>
                  <label for="meta"> {{ meta.especialidad }}</label>
                </div>
                <div class="mx-2">
                  <h1><u>Fecha</u></h1>
                  <label for="meta"> {{ meta.fecha }}</label>
                </div>
                <div class="mx-2">
                  <h1><u>Especifico</u></h1>
                  <label for="meta"> {{ meta.especifico }}</label>
                </div>
                <div class="mx-2">
                  <h1><u>Nombre</u></h1>
                  <label for="meta"> {{ meta.nombre }}</label>
                </div>
                <div class="colmuns">
                  <VIconButton
                    color="warning"
                    outlined
                    circle
                    icon="feather:trash-2"
                    @click="eliminarMeta(index)"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Segunda caja -->
      <div class="columns">
        <!-- Tablas -->
        <div class="column is-12">
          <div class="account-box is-navigation">
            <div class="form-body">
              <div class="fieldset">
                <div class="fieldset-heading">
                  <h4>Disponibilidad :</h4>
                </div>
                <div class="columns is-multiline">
                  <div class="column is-3">
                    <h1><u>Lunes</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.lunesM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.lunesT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <div class="column is-3">
                    <h1><u>Martes</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.martesM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.martesT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <div class="column is-3">
                    <h1><u>Miercoles</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.miercolesM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.miercolesT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <div class="column is-3">
                    <h1><u>Jueves</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.juevesM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.juevesT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                </div>
                <div class="columns is-multiline">
                  <div class="column is-3">
                    <h1><u>Viernes</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.viernesM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.viernesT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <div class="column is-3">
                    <h1><u>Sabado</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.sabadoM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.sabadoT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <div class="column is-3">
                    <h1><u>Domingo</u></h1>
                    <VField grouped>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.domingoM"
                          color="success"
                          label="Mañana"
                        />
                      </VControl>
                      <VControl subcontrol>
                        <VSwitchBlock
                          v-model="datosObjetivos.dias_entrenamiento.domingoT"
                          color="success"
                          label="Tarde"
                        />
                      </VControl>
                    </VField>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/abstracts/all';

.is-navbar {
  .account-wrapper {
    margin-top: 30px;
  }
}

.account-wrapper {
  padding-bottom: 60px;

  .account-box {
    @include vuero-s-card;

    &.is-navigation {
      .media-flex-center {
        padding-bottom: 20px;

        .flex-meta {
          span {
            &:first-child {
              font-size: 1.3rem;
            }
          }
        }
      }

      .account-menu {
        .account-menu-item {
          display: flex;
          align-items: center;
          padding: 12px 16px;
          border: 1px solid transparent;
          border-radius: 8px;
          margin-bottom: 5px;
          transition: all 0.3s; // transition-all test

          &.router-link-exact-active {
            box-shadow: var(--light-box-shadow);
            border-color: var(--fade-grey-dark-3);

            span,
            i {
              color: var(--primary);
            }

            .end {
              display: block;
            }
          }

          &:not(.router-link-exact-active) {
            &:hover {
              background: var(--fade-grey-light-3);
            }
          }

          i {
            margin-right: 8px;
            font-size: 1.1rem;
            color: var(--light-text);

            &.fas,
            .fal,
            .far {
              font-size: 0.9rem;
            }
          }

          span {
            font-family: var(--font-alt);
            font-size: 0.95rem;
            color: var(--dark-text);
          }

          .end {
            margin-left: auto;
            display: none;
          }
        }
      }
    }

    &.is-form {
      padding: 0;

      &.is-footerless {
        padding-bottom: 20px;
      }

      .form-head,
      .form-foot {
        padding: 12px 20px;

        .form-head-inner,
        .form-foot-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
      }

      .form-head {
        border-bottom: 1px solid var(--fade-grey-dark-3);
        transition: all 0.3s; // transition-all test

        &.is-stuck {
          background: var(--white);
          padding-right: 80px;
          border-left: 1px solid var(--fade-grey-dark-3);
        }

        .left {
          h3 {
            font-family: var(--font-alt);
            font-size: 1.2rem;
            line-height: 1.3;
          }

          p {
            font-size: 0.95rem;
          }
        }
      }

      .form-foot {
        border-top: 1px solid var(--fade-grey-dark-3);
      }

      .form-body {
        padding: 20px;

        .fieldset {
          padding: 20px 0;
          max-width: 480px;
          margin: 0 auto;

          .fieldset-heading {
            margin-bottom: 20px;

            h4 {
              font-family: var(--font-alt);
              font-weight: 600;
              font-size: 1rem;
            }

            p {
              font-size: 0.9rem;
            }
          }

          .v-avatar {
            position: relative;
            display: block;
            margin: 0 auto;

            .edit-button {
              position: absolute;
              bottom: 0;
              right: 0;
            }
          }

          .setting-list {
            .setting-form {
              text-align: center;

              .filepond-profile-wrap {
                margin: 0 auto 10px !important;
              }
            }

            .setting-item {
              display: flex;
              align-items: center;
              margin-bottom: 24px;

              .icon-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                background: var(--fade-grey-light-2);
                border: 1px solid var(--fade-grey-dark-3);
                color: var(--light-text);

                &.has-img {
                  border-color: var(--primary);

                  img {
                    width: 36px;
                    min-width: 36px;
                    height: 36px;
                  }
                }

                i {
                  font-size: 1.4rem;
                }
              }

              img {
                display: block;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                border: 1px solid transparent;
              }

              .meta {
                margin-left: 10px;

                > span {
                  font-family: var(--font);
                  display: block;

                  &:first-child {
                    font-family: var(--font-alt);
                    font-weight: 600;
                    color: var(--dark-text);
                    font-size: 0.9rem;
                  }

                  &:nth-child(2),
                  &:nth-child(3) {
                    font-size: 0.85rem;
                    color: var(--light-text);

                    i {
                      position: relative;
                      top: -2px;
                      font-size: 4px;
                      margin: 0 6px;
                    }
                  }

                  &:nth-child(3) {
                    color: var(--primary);
                  }

                  span {
                    display: inline-block;
                  }
                }
              }

              .end {
                margin-left: auto;
              }
            }
          }
        }
      }
    }
  }
}

.is-dark {
  .account-wrapper {
    .account-box {
      @include vuero-card--dark;

      &.is-navigation {
        .account-menu {
          .account-menu-item {
            &.router-link-exact-active {
              background: var(--dark-sidebar-light-8);
              border-color: var(--dark-sidebar-light-12);

              i,
              span {
                color: var(--primary);
              }
            }

            &:not(.router-link-exact-active) {
              &:hover {
                background: var(--dark-sidebar-light-10);
              }
            }

            span {
              color: var(--dark-dark-text);
            }
          }
        }
      }

      &.is-form {
        .form-head,
        .form-foot {
          border-color: var(--dark-sidebar-light-12);
        }

        .form-head {
          &.is-stuck {
            background: var(--dark-sidebar);
            border-color: var(--dark-sidebar-light-6);
          }

          .left {
            h3 {
              color: var(--dark-dark-text);
            }
          }
        }

        .form-body {
          .fieldset {
            .fieldset-heading {
              h4 {
                color: var(--dark-dark-text);
              }
            }

            .setting-list {
              .setting-item {
                > img,
                > .icon-wrap,
                > .icon-wrap img {
                  border-color: var(--dark-sidebar-light-12);
                }

                > .icon-wrap {
                  background: var(--dark-sidebar-light-2);
                }

                .meta {
                  > span {
                    &:nth-child(3) {
                      color: var(--primary);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
