<script setup lang="ts">
import { useWindowScroll } from '@vueuse/core'
import { computed, onMounted, reactive, ref } from 'vue'
import { useNotyf } from '/@src/composable/useNotyf'
import sleep from '/@src/utils/sleep'
import { EditarDatosDeportes } from '/@src/services/models/Deportista'
import { getDeportes, updateDeportes } from '/@src/services/deportista'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const isLoading = ref(false)
const edadDeportivaMensaje = ref('')
const notyf = useNotyf()
const { y } = useWindowScroll()
const inputZona = ref('')
const inputTratamieto = ref('')
const inputFecha_inicio = ref('')
const inputDuracion = ref('')
const inputLesionPresente = ref('')
const emit = defineEmits(['update'])
const isScrolling = computed(() => {
  return y.value > 40
})

const datosDeportes = reactive<EditarDatosDeportes>({
  edad_deportiva: '',
  lesiones: [],
  enfermedad_actual: '',
  enfermedad_duracion: '',
  enfermedad_fech_inicio: '',
  enfermedad_tratamiento: '',
  enfermedad_zona: '',
  esfuerzo_trabajo: '',
  nutricion: '',
  otros: {},
  otro: '',
  pulsometro: '',
  subjetivo: '',
  sueño: '',
})

const activarBoton = computed(() => {
  let disabled = true
  if (datosDeportes.edad_deportiva != null && datosDeportes.edad_deportiva != '') {
    disabled = false
  } else {
    disabled = true
  }
  return disabled
})

const selectedEdadDeportiva = () => {
  let existe = false
  if (datosDeportes.edad_deportiva == null) {
    edadDeportivaMensaje.value = '"Debes escoger un intervalo"'
    existe = true
  }
  return existe
}

const addLesion = () => {
  datosDeportes.lesiones.push({
    zona: inputZona.value,
    tratamiento: inputTratamieto.value,
    fecha_inicio: inputFecha_inicio.value,
    duracion: inputDuracion.value,
    actual: inputLesionPresente.value,
  })
  inputZona.value = ''
  inputTratamieto.value = ''
  inputFecha_inicio.value = ''
  inputDuracion.value = ''
  inputLesionPresente.value = ''
}

const eliminarLesion = (lesion: number) => {
  console.log(lesion)

  datosDeportes.lesiones.splice(lesion, 1)
}

const onSave = async () => {
  isLoading.value = true
  await sleep()
  await updateDeportes(userSession.userId, datosDeportes)
  emit('update')
  notyf.success('¡Sus cambios han sido guardados con éxito!')
  isLoading.value = false
}

onMounted(async () => {
  const datos = await getDeportes(userSession.userId)
  datosDeportes.edad_deportiva = datos?.edad_deportiva || ''
  datosDeportes.lesiones = datos?.lesiones || []
  datosDeportes.enfermedad_actual = datos?.enfermedad_actual || ''
  datosDeportes.enfermedad_duracion = datos?.enfermedad_duracion || ''
  datosDeportes.enfermedad_fech_inicio = datos?.enfermedad_fech_inicio || ''
  datosDeportes.enfermedad_tratamiento = datos?.enfermedad_tratamiento || ''
  datosDeportes.enfermedad_zona = datos?.enfermedad_zona || ''
  datosDeportes.esfuerzo_trabajo = datos?.esfuerzo_trabajo || ''
  datosDeportes.nutricion = datos?.nutricion || ''
  datosDeportes.otros = datos?.otros || ''
  datosDeportes.otro = datos?.otro || ''
  datosDeportes.pulsometro = datos?.pulsometro || ''
  datosDeportes.subjetivo = datos?.subjetivo || ''
  datosDeportes.sueño = datos?.sueño || ''
})

// watch(
//   () => datosDeportes.otros.otro,
//   async (nuevo) => {
//     if (nuevo === false) {
//       datosDeportes.otro = ''
//     }
//   }
// )
</script>

<template>
  <div class="page-content-inner">
    <!--Edit Profile-->
    <div class="account-wrapper">
      <div class="columns">
        <!--Navigation-->
        <div class="column is-6">
          <div class="account-box is-form is-footerless">
            <div class="form-head stuck-header" :class="[isScrolling && 'is-stuck']">
              <div class="form-head-inner">
                <div class="left">
                  <h3>Información General</h3>
                  <p>Edita la informacíon general de tu cuenta</p>
                </div>
                <div class="right">
                  <div class="buttons">
                    <VButton
                      :to="{ name: 'deportista' }"
                      icon="lnir lnir-arrow-left rem-100"
                      light
                      dark-outlined
                    >
                      Regresar
                    </VButton>
                    <VButton
                      color="primary"
                      raised
                      :loading="isLoading"
                      :disabled="activarBoton"
                      tabindex="0"
                      @keydown.space.prevent="onSave"
                      @click="onSave"
                    >
                      Guardar cambios
                    </VButton>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-body">
              <!--Fieldset-->
              <div class="fieldset">
                <div class="fieldset-heading">
                  <h4>Información Deportes:</h4>
                  <p>Otras personas quieren conocerte más</p>
                </div>
                <div class="columns is-multiline">
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label"
                          >Edad Deportiva <font size="4" color="red">* </font>
                          <span
                            v-tooltip.primary.bubble="
                              'Tiempo que le has dedicado al deporte'
                            "
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.edad_deportiva"
                          :value="datosDeportes.edad_deportiva"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="[
                            '< 1 Año',
                            '1 - 2 Años',
                            '3 - 5 Años',
                            '6 - 10 Años',
                            '10 + Años',
                          ]"
                          required
                        />
                        <p v-if="selectedEdadDeportiva()" class="help is-danger">
                          {{ edadDeportivaMensaje }}
                        </p>
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Nivel Deportivo Subjetivo
                          <span
                            v-tooltip.primary.bubble="'Valoración de tu nivel'"
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.subjetivo"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']"
                          required
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Usa Pulsometro
                          <span
                            v-tooltip.primary.bubble="'Tienes pulsometro'"
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.pulsometro"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['si', 'no']"
                          required
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Esfuerzo fisico en el trabajo
                          <span
                            v-tooltip.primary.bubble="
                              'Califica el nivel de esfuerzo en tu trabajo'
                            "
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.esfuerzo_trabajo"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']"
                          required
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Nutrición
                          <span
                            v-tooltip.primary.bubble="
                              'De 1 a 10 cuál es tu nivel de nutrición'
                            "
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.nutricion"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']"
                          required
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">
                          Sueño
                          <span
                            v-tooltip.primary.bubble="'¿Cuántas horas duermes?'"
                            onclick=""
                            color="solid"
                            label="Bubble"
                          >
                            <i
                              class="iconify"
                              data-icon="feather:help-circle"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </VLabel>
                        <Multiselect
                          v-model="datosDeportes.sueño"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']"
                          required
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-12">
                    <label raw class="auth-label">
                      Otros Deportes
                      <span
                        v-tooltip.primary.bubble="'¿Te gustan otros deportes?'"
                        onclick=""
                        color="solid"
                        label="Bubble"
                      >
                        <i
                          class="iconify"
                          data-icon="feather:help-circle"
                          aria-hidden="true"
                        ></i>
                      </span>
                    </label>
                    <VField class="columns is-multiline">
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.ciclismo"
                          label="Ciclismo"
                          color="success"
                        />
                      </VControl>
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.natacion"
                          label="Natación"
                          color="success"
                        />
                      </VControl>
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.triatlon"
                          label="Triatlon"
                          color="success"
                        />
                      </VControl>
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.gimnasio"
                          label="Gimnasio"
                          color="success"
                        />
                      </VControl>
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.trail"
                          label="Trail"
                          color="success"
                        />
                      </VControl>
                      <VControl raw subcontrol>
                        <VCheckbox
                          v-model="datosDeportes.otros.otro"
                          label="Otro"
                          color="success"
                        />
                      </VControl>
                    </VField>
                    <!--Field-->
                    <div v-if="datosDeportes.otros.otro" class="column is-12">
                      <p>Otro deporte</p>
                      <VField>
                        <VControl icon="feather:user">
                          <VInput
                            v-model="datosDeportes.otro"
                            type="text"
                            placeholder="Otro deporte"
                            autocomplete="on"
                          />
                        </VControl>
                      </VField>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Tablas -->
        <div class="column is-6">
          <div class="account-box is-navigation">
            <div>
              <VButton color="primary" outlined @click="addLesion">
                Añadir Lesion</VButton
              >
            </div>
            <div class="form-body">
              <div class="fieldset">
                <div class="fieldset-heading">
                  <h4>Lesiones:</h4>
                </div>
                <div class="columns is-multiline">
                  <!--Field-->
                  <div class="column is-6">
                    <p>Zona</p>
                    <VField>
                      <VControl icon="feather:user">
                        <VInput
                          v-model="inputZona"
                          type="text"
                          placeholder="Zona"
                          autocomplete="off"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!--Field-->
                  <div class="column is-6">
                    <p>Tratamiento</p>
                    <VField>
                      <VControl icon="feather:user">
                        <VInput
                          v-model="inputTratamieto"
                          type="text"
                          placeholder="Tratamiento"
                          autocomplete="off"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!--Field Fecha Inicio-->
                  <div class="column is-6">
                    <p>Fecha Inicio</p>
                    <VField>
                      <VControl icon="feather:calendar">
                        <ClientOnly>
                          <VDatePicker
                            v-model="inputFecha_inicio"
                            color="green"
                            trim-weeks
                          >
                            <template #default="{ inputValue, inputEvents }">
                              <VField>
                                <VControl icon="feather:calendar">
                                  <VInput :value="inputValue" v-on="inputEvents" />
                                </VControl>
                              </VField>
                            </template>
                          </VDatePicker>
                        </ClientOnly>
                      </VControl>
                    </VField>
                  </div>
                  <!--Field-->
                  <div class="column is-6">
                    <p>Duracion</p>
                    <VField>
                      <VControl icon="feather:user">
                        <VInput
                          v-model="inputDuracion"
                          type="text"
                          placeholder="Duracion de lesion"
                          autocomplete="off"
                        />
                      </VControl>
                    </VField>
                  </div>
                  <!-- Field  -->
                  <div class="column is-6">
                    <VField v-slot="{ id }">
                      <VControl>
                        <VLabel raw class="auth-label">¿Actualmente la tiene ?</VLabel>
                        <Multiselect
                          v-model="inputLesionPresente"
                          :attrs="{ id }"
                          placeholder="Seleccione uno"
                          :options="['SI', 'NO']"
                        />
                      </VControl>
                    </VField>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            v-for="(lesion, index) in datosDeportes.lesiones"
            :key="lesion"
            class="account-box"
          >
            <div class="columns is-multiline">
              <div class="mx-2">
                <h1><u>Zona</u></h1>
                <label for="zoa"> {{ lesion.zona }}</label>
              </div>
              <div class="mx-2">
                <h1><u>Tratamiento</u></h1>
                <label for="zoa"> {{ lesion.tratamiento }}</label>
              </div>
              <div class="mx-2">
                <h1><u>Fecha Inicio</u></h1>
                <label for="zoa"> {{ lesion.fecha_inicio }}</label>
              </div>
              <div class="mx-2">
                <h1><u>Duracion</u></h1>
                <label for="zoa"> {{ lesion.duracion }}</label>
              </div>
              <div class="mx-2">
                <h1><u>Actualmente la tiene</u></h1>
                <label for="zoa"> {{ lesion.actual }}</label>
              </div>
            </div>
            <div class="colmuns">
              <VIconButton
                color="warning"
                outlined
                circle
                icon="feather:trash-2"
                @click="eliminarLesion(index)"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/abstracts/all';

.is-navbar {
  .account-wrapper {
    margin-top: 30px;
  }
}

.account-wrapper {
  padding-bottom: 60px;

  .account-box {
    @include vuero-s-card;

    &.is-navigation {
      .media-flex-center {
        padding-bottom: 20px;

        .flex-meta {
          span {
            &:first-child {
              font-size: 1.3rem;
            }
          }
        }
      }

      .account-menu {
        .account-menu-item {
          display: flex;
          align-items: center;
          padding: 12px 16px;
          border: 1px solid transparent;
          border-radius: 8px;
          margin-bottom: 5px;
          transition: all 0.3s; // transition-all test

          &.router-link-exact-active {
            box-shadow: var(--light-box-shadow);
            border-color: var(--fade-grey-dark-3);

            span,
            i {
              color: var(--primary);
            }

            .end {
              display: block;
            }
          }

          &:not(.router-link-exact-active) {
            &:hover {
              background: var(--fade-grey-light-3);
            }
          }

          i {
            margin-right: 8px;
            font-size: 1.1rem;
            color: var(--light-text);

            &.fas,
            .fal,
            .far {
              font-size: 0.9rem;
            }
          }

          span {
            font-family: var(--font-alt);
            font-size: 0.95rem;
            color: var(--dark-text);
          }

          .end {
            margin-left: auto;
            display: none;
          }
        }
      }
    }

    &.is-form {
      padding: 0;

      &.is-footerless {
        padding-bottom: 20px;
      }

      .form-head,
      .form-foot {
        padding: 12px 20px;

        .form-head-inner,
        .form-foot-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
      }

      .form-head {
        border-bottom: 1px solid var(--fade-grey-dark-3);
        transition: all 0.3s; // transition-all test

        &.is-stuck {
          background: var(--white);
          padding-right: 80px;
          border-left: 1px solid var(--fade-grey-dark-3);
        }

        .left {
          h3 {
            font-family: var(--font-alt);
            font-size: 1.2rem;
            line-height: 1.3;
          }

          p {
            font-size: 0.95rem;
          }
        }
      }

      .form-foot {
        border-top: 1px solid var(--fade-grey-dark-3);
      }

      .form-body {
        padding: 20px;

        .fieldset {
          padding: 20px 0;
          max-width: 480px;
          margin: 0 auto;

          .fieldset-heading {
            margin-bottom: 20px;

            h4 {
              font-family: var(--font-alt);
              font-weight: 600;
              font-size: 1rem;
            }

            p {
              font-size: 0.9rem;
            }
          }

          .v-avatar {
            position: relative;
            display: block;
            margin: 0 auto;

            .edit-button {
              position: absolute;
              bottom: 0;
              right: 0;
            }
          }

          .setting-list {
            .setting-form {
              text-align: center;

              .filepond-profile-wrap {
                margin: 0 auto 10px !important;
              }
            }

            .setting-item {
              display: flex;
              align-items: center;
              margin-bottom: 24px;

              .icon-wrap {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                background: var(--fade-grey-light-2);
                border: 1px solid var(--fade-grey-dark-3);
                color: var(--light-text);

                &.has-img {
                  border-color: var(--primary);

                  img {
                    width: 36px;
                    min-width: 36px;
                    height: 36px;
                  }
                }

                i {
                  font-size: 1.4rem;
                }
              }

              img {
                display: block;
                width: 50px;
                min-width: 50px;
                height: 50px;
                border-radius: var(--radius-rounded);
                border: 1px solid transparent;
              }

              .meta {
                margin-left: 10px;

                > span {
                  font-family: var(--font);
                  display: block;

                  &:first-child {
                    font-family: var(--font-alt);
                    font-weight: 600;
                    color: var(--dark-text);
                    font-size: 0.9rem;
                  }

                  &:nth-child(2),
                  &:nth-child(3) {
                    font-size: 0.85rem;
                    color: var(--light-text);

                    i {
                      position: relative;
                      top: -2px;
                      font-size: 4px;
                      margin: 0 6px;
                    }
                  }

                  &:nth-child(3) {
                    color: var(--primary);
                  }

                  span {
                    display: inline-block;
                  }
                }
              }

              .end {
                margin-left: auto;
              }
            }
          }
        }
      }
    }
  }
}

.is-dark {
  .account-wrapper {
    .account-box {
      @include vuero-card--dark;

      &.is-navigation {
        .account-menu {
          .account-menu-item {
            &.router-link-exact-active {
              background: var(--dark-sidebar-light-8);
              border-color: var(--dark-sidebar-light-12);

              i,
              span {
                color: var(--primary);
              }
            }

            &:not(.router-link-exact-active) {
              &:hover {
                background: var(--dark-sidebar-light-10);
              }
            }

            span {
              color: var(--dark-dark-text);
            }
          }
        }
      }

      &.is-form {
        .form-head,
        .form-foot {
          border-color: var(--dark-sidebar-light-12);
        }

        .form-head {
          &.is-stuck {
            background: var(--dark-sidebar);
            border-color: var(--dark-sidebar-light-6);
          }

          .left {
            h3 {
              color: var(--dark-dark-text);
            }
          }
        }

        .form-body {
          .fieldset {
            .fieldset-heading {
              h4 {
                color: var(--dark-dark-text);
              }
            }

            .setting-list {
              .setting-item {
                > img,
                > .icon-wrap,
                > .icon-wrap img {
                  border-color: var(--dark-sidebar-light-12);
                }

                > .icon-wrap {
                  background: var(--dark-sidebar-light-2);
                }

                .meta {
                  > span {
                    &:nth-child(3) {
                      color: var(--primary);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
