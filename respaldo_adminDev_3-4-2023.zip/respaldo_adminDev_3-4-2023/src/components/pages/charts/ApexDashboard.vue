<script setup lang="ts">
import * as chartOptions from '/@src/data/dashboards/apex-demo/chartOptions'
import ApexChart from 'vue3-apexcharts'
</script>

<template>
  <div class="apex-dashboard">
    <div class="columns is-multiline">
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-1"
            :height="chartOptions.options1.chart.height"
            :type="chartOptions.options1.chart.type"
            :series="chartOptions.options1.series"
            :options="chartOptions.options1"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-2"
            :height="chartOptions.options2.chart.height"
            :type="chartOptions.options2.chart.type"
            :series="chartOptions.options2.series"
            :options="chartOptions.options2"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-4"
            :height="chartOptions.options4.chart.height"
            :type="chartOptions.options4.chart.type"
            :series="chartOptions.options4.series"
            :options="chartOptions.options4"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-5"
            :height="chartOptions.options5.chart.height"
            :type="chartOptions.options5.chart.type"
            :series="chartOptions.options5.series"
            :options="chartOptions.options5"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-6"
            :height="chartOptions.options6.chart.height"
            :type="chartOptions.options6.chart.type"
            :series="chartOptions.options6.series"
            :options="chartOptions.options6"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-7"
            :height="chartOptions.options7.chart.height"
            :type="chartOptions.options7.chart.type"
            :series="chartOptions.options7.series"
            :options="chartOptions.options7"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-8"
            :height="chartOptions.options8.chart.height"
            :type="chartOptions.options8.chart.type"
            :series="chartOptions.options8.series"
            :options="chartOptions.options8"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-9"
            :height="chartOptions.options9.chart.height"
            :type="chartOptions.options9.chart.type"
            :series="chartOptions.options9.series"
            :options="chartOptions.options9"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-10"
            :height="chartOptions.options10.chart.height"
            :type="chartOptions.options10.chart.type"
            :series="chartOptions.options10.series"
            :options="chartOptions.options10"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-11"
            :height="chartOptions.options11.chart.height"
            :type="chartOptions.options11.chart.type"
            :series="chartOptions.options11.series"
            :options="chartOptions.options11"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-12"
            :height="chartOptions.options12.chart.height"
            :type="chartOptions.options12.chart.type"
            :series="chartOptions.options12.series"
            :options="chartOptions.options12"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-13"
            :height="chartOptions.options13.chart.height"
            :type="chartOptions.options13.chart.type"
            :series="chartOptions.options13.series"
            :options="chartOptions.options13"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-14"
            :height="chartOptions.options14.chart.height"
            :type="chartOptions.options14.chart.type"
            :series="chartOptions.options14.series"
            :options="chartOptions.options14"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-15"
            :height="chartOptions.options15.chart.height"
            :type="chartOptions.options15.chart.type"
            :series="chartOptions.options15.series"
            :options="chartOptions.options15"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-16"
            :height="chartOptions.options16.chart.height"
            :type="chartOptions.options16.chart.type"
            :series="chartOptions.options16.series"
            :options="chartOptions.options16"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-17"
            :height="chartOptions.options17.chart.height"
            :type="chartOptions.options17.chart.type"
            :series="chartOptions.options17.series"
            :options="chartOptions.options17"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-18"
            :height="chartOptions.options18.chart.height"
            :type="chartOptions.options18.chart.type"
            :series="chartOptions.options18.series"
            :options="chartOptions.options18"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-19"
            :height="chartOptions.options19.chart.height"
            :type="chartOptions.options19.chart.type"
            :series="chartOptions.options19.series"
            :options="chartOptions.options19"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-20"
            :height="chartOptions.options20.chart.height"
            :type="chartOptions.options20.chart.type"
            :series="chartOptions.options20.series"
            :options="chartOptions.options20"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-21"
            :height="chartOptions.options21.chart.height"
            :type="chartOptions.options21.chart.type"
            :series="chartOptions.options21.series"
            :options="chartOptions.options21"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-22"
            :height="chartOptions.options22.chart.height"
            :type="chartOptions.options22.chart.type"
            :series="chartOptions.options22.series"
            :options="chartOptions.options22"
          >
          </ApexChart>
        </div>
      </div>
      <div class="column is-6">
        <div class="s-card">
          <ApexChart
            id="apex-chart-23"
            :height="chartOptions.options23.chart.height"
            :type="chartOptions.options23.chart.type"
            :series="chartOptions.options23.series"
            :options="chartOptions.options23"
          >
          </ApexChart>
        </div>
      </div>
    </div>
  </div>
</template>
