<script setup lang="ts">
//import { ref } from 'vue'
import { auth } from '../../../services/config'
import { useRouter } from 'vue-router'
import { useNotyf } from '/@src/composable/useNotyf'
import { useUserSession } from '/@src/stores/userSession'
//const profileView = ref(import.meta.env.VITE_APP_PROFILE_VIEW)

const router = useRouter()
const notyf = useNotyf()

const userSession = useUserSession()

const salir = () => {
  auth.signOut()
  router.push('/')
  notyf.success('Te esperamos pronto')
}
// Access props with `props.myCustomObject` and `props.myStringArray`
</script>

<template>
  <VDropdown right spaced class="user-dropdown profile-dropdown">
    <template #button="{ toggle }">
      <a
        tabindex="0"
        class="is-trigger dropdown-trigger"
        aria-haspopup="true"
        @keydown.space.prevent="toggle"
        @click="toggle"
      >
        <VAvatar :picture="userSession.imagenUrl" />
      </a>
    </template>

    <template #content>
      <div class="dropdown-head">
        <VAvatar size="large" :picture="userSession.imagenUrl" />

        <div class="meta">
          <span>{{ userSession.userData?.nombres }}</span>
          <span>{{ userSession.userData?.rol }}</span>
        </div>
      </div>
      <RouterLink :to="{ name: 'deportista-profile-profile-view' }" class="is-submenu">
        <a role="menuitem" class="dropdown-item is-media">
          <div class="icon">
            <i aria-hidden="true" class="lnil lnil-user-alt"></i>
          </div>
          <div class="meta">
            <span>Perfil</span>
            <span>Ver tu perfil</span>
          </div>
        </a>
      </RouterLink>
      <!-- <hr class="dropdown-divider" />

      <a href="#" role="menuitem" class="dropdown-item is-media">
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-briefcase"></i>
        </div>
        <div class="meta">
          <span>Projects</span>
          <span>All my projects</span>
        </div>
      </a> -->

      <!-- <a href="#" role="menuitem" class="dropdown-item is-media">
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-users-alt"></i>
        </div>
        <div class="meta">
          <span>Team</span>
          <span>Manage your team</span>
        </div>
      </a> -->

      <!-- <hr class="dropdown-divider" />

      <a href="#" role="menuitem" class="dropdown-item is-media">
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-cog"></i>
        </div>
        <div class="meta">
          <span>Settings</span>
          <span>Account settings</span>
        </div>
      </a> -->

      <!-- <hr class="dropdown-divider" /> -->

      <div class="dropdown-item is-button">
        <VButton
          class="btn-degrade-blue"
          icon="feather:log-out"
          color="primary"
          role="menuitem"
          raised
          fullwidth
          @click="salir"
        >
          Salir
        </VButton>
      </div>
    </template>
  </VDropdown>
</template>
