<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { onValue, ref as reff } from 'firebase/database'
import { useUserSession } from '/@src/stores/userSession'
import { OBTENER_PLAN_DEPORTISTA } from '/@src/services/deportista'
import { database } from '/@src/services/config'
import { GET_SOLICITUDES_DEPORTISTA } from '/@src/services/match'
const userSession = useUserSession()
const props = defineProps({
  datosDeportista: {
    type: Object,
    required: true,
  },
  id: {
    type: String,
    required: true,
  },
  entrenador: {
    type: Object,
    required: true,
  },
})
let solicitudes: any[] = ref([])
const emits = defineEmits<{
  (e: 'view'): void
  (e: 'projects'): void
  (e: 'schedule'): void
  (e: 'remove'): void
}>()
const plan = await OBTENER_PLAN_DEPORTISTA(userSession.userId)
const verificarSolicitud = (idEntrenador: any) => {
  let value = false
  solicitudes.value.forEach((solicitud) => {
    if (solicitud.id_entrenador === idEntrenador && solicitud.estado === 'Pendiente') {
      value = true
    }
  })
  return value
}

onMounted(async () => {
  onValue(reff(database, 'solicitudes'), (snapshot) => {
    if (snapshot.exists()) {
      solicitudes.value = GET_SOLICITUDES_DEPORTISTA(userSession.userId, snapshot.val())
    } else {
      solicitudes = null
    }
  })
})
</script>

<template>
  <VDropdown icon="feather:more-vertical" class="is-pushed-mobile" spaced right>
    <template #content="{ close }">
      <a
        role="menuitem"
        href="#"
        class="dropdown-item is-media"
        @click.prevent="
          () => {
            emits('view')
            close()
          }
        "
      >
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-eye"></i>
        </div>
        <div class="meta">
          <span>Ver</span>
          <span>Ver perfil de Entrenador</span>
          <ModalPreviewEntrenador
            :id="props.id"
            :datos-deportista="props.datosDeportista"
            :entrenador="entrenador"
          />
        </div>
      </a>

      <a
        role="menuitem"
        href="#"
        class="dropdown-item is-media"
        @click.prevent="
          () => {
            emits('projects')
            close()
          }
        "
      >
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-briefcase"></i>
        </div>
        <div class="meta">
          <VButton
            v-if="contadorSolicitudes >= plan.solicitudes"
            color="primary"
            bold
            rounded
            raised
            disabled
            >Enviar Solicitud</VButton
          >
          <ModalCancelar
            v-else-if="verificarSolicitud(entrenador.id)"
            :id="props.id"
            :solicitudes="solicitudes"
            :id-entrenador="entrenador.id"
          />
          <ModalEnviar
            v-else
            :id="props.id"
            :datos-deportista="props.datosDeportista"
            :entrenador="entrenador"
          />
        </div>
      </a>

      <!-- <a
        role="menuitem"
        href="#"
        class="dropdown-item is-media"
        @click.prevent="
          () => {
            emits('schedule')
            close()
          }
        "
      >
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-calendar"></i>
        </div>
        <div class="meta">
          <span>Schedule</span>
          <span>Schedule a meeting</span>
        </div>
      </a>

      <hr class="dropdown-divider" />

      <a
        role="menuitem"
        href="#"
        class="dropdown-item is-media"
        @click.prevent="
          () => {
            emits('remove')
            close()
          }
        "
      >
        <div class="icon">
          <i aria-hidden="true" class="lnil lnil-trash-can-alt"></i>
        </div>
        <div class="meta">
          <span>Remove</span>
          <span>Remove from list</span>
        </div>
      </a> -->
    </template>
  </VDropdown>
</template>
