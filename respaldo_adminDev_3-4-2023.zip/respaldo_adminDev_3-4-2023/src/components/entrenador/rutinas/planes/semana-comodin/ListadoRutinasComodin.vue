<script setup lang="ts">
import { ref, onMounted } from 'vue'

import { ENOpcionesCru } from '/@src/services/constantes'
import { ISemanaComodin } from '/@src/services/models/Rutinas'
import { ELIMINAR_RUTINA_COMODIN, LISTAR_RUTINAS_COMODIN } from '/@src/services/rutinas'

export interface CrudPlanesGratuitosProps {
  ver: boolean
  editar: boolean
  eliminar: boolean
}

const props = defineProps<CrudPlanesGratuitosProps>()
const planes = ref<ISemanaComodin[]>([])

const planAnterior = ref<ISemanaComodin>()

const opcionActual = ref<ENOpcionesCru>(ENOpcionesCru.CREAR)

const planEliminarId = ref('')
const mostrarCofirmarEliminar = ref(false)

const listarSemanasComodin = async () => {
  planes.value = (await LISTAR_RUTINAS_COMODIN()) || []
}

const verPlan = (rutina: ISemanaComodin) => {
  opcionActual.value = ENOpcionesCru.VER
  planAnterior.value = { ...rutina }
}

const editarPlan = (rutina: ISemanaComodin) => {
  opcionActual.value = ENOpcionesCru.EDITAR
  planAnterior.value = { ...rutina }
}

const seleccionarEliminarPlan = (idRutina: any) => {
  planEliminarId.value = idRutina
  mostrarCofirmarEliminar.value = true
}

const eliminarPlan = async () => {
  await ELIMINAR_RUTINA_COMODIN(planEliminarId.value)
  await listarSemanasComodin()
  mostrarCofirmarEliminar.value = false
}

const cerrarPlan = () => {
  opcionActual.value = ENOpcionesCru.VER
  planAnterior.value = undefined
}

const planActualizado = async () => {
  planAnterior.value = undefined
  await listarSemanasComodin()
}

onMounted(() => {
  listarSemanasComodin()
})
</script>

<template>
  <div>
    <div v-if="!planAnterior">
      <div v-for="(rutina, index) in planes" :key="index" class="columns">
        <div class="column">
          <h5>{{ rutina.deporte_rutina }}</h5>
          <p>vam {{ rutina.vam }}</p>
        </div>
        <div class="column">
          <VButton v-if="props.ver" color="warning" @click="() => verPlan(rutina)">
            Ver
          </VButton>
          <VButton v-if="props.editar" color="success" @click="() => editarPlan(rutina)">
            Editar
          </VButton>
          <VButton
            v-if="props.eliminar"
            color="danger"
            @click="seleccionarEliminarPlan(rutina.id)"
          >
            Eliminar
          </VButton>
        </div>
      </div>
    </div>
    <SemanaComodin
      v-else
      :opcioncrudplanes="opcionActual"
      :crear="false"
      :ver="props.ver"
      :editar="props.editar"
      :eliminar="props.eliminar"
      :plananterior="planAnterior"
      @cancelar="cerrarPlan"
      @actualizar-comodin="planActualizado"
    />
    <ModalOptions
      title="Confirmación"
      subtitle="Desea Eliminar este plan"
      :mostrar="mostrarCofirmarEliminar"
      classconfirm="danger"
      confirm-msm="Eliminar Plan"
      @aceptar="eliminarPlan"
      @cancelar="mostrarCofirmarEliminar = false"
    />
  </div>
</template>
