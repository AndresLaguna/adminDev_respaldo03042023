<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { z as zod } from 'zod'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'

import {
  DeportesDisponibles,
  DEPORTES_DISPONIBLES,
} from '/@src/services/models/DeportesDisponibles'
import { ISemanaComodin, Rutina } from '/@src/services/models/Rutinas'
import { usePlanSemanaComodin } from '/@src/stores/planSemanaComodin'

import { ENOpcionesCru } from '/@src/services/constantes'
import { nombreDiasSemana } from '/@src/services/constantes'

export interface IPlanGratuitoProps {
  plananterior?: ISemanaComodin
  crear: boolean
  editar: boolean
  ver: boolean
  eliminar: boolean
  opcioncrudplanes: ENOpcionesCru
}

export interface IPlanGratuitoEmits {
  (event: 'cancelar'): void
  (event: 'actualizar-comodin'): void
}

const deportesDisponibles = DEPORTES_DISPONIBLES
const diasSemana = nombreDiasSemana

const semanaComodinStore = usePlanSemanaComodin()

const emits = defineEmits<IPlanGratuitoEmits>()
const props = defineProps<IPlanGratuitoProps>()

const opcionesCrudDispo = ref({
  ver: false,
  editar: false,
  eliminar: false,
})
const plan = ref<ISemanaComodin>({
  deporte_rutina: DeportesDisponibles.ATLETISMO,
  plan: [],
  vam: 0,
})

const isOpenCrearSesion = ref(false)
const posicionPlan = reactive({
  indexsemana: 0,
  indexdia: 0,
})

const opcionactual = ref<ENOpcionesCru>(ENOpcionesCru.CREAR)
const mostrarCofirmarOpciones = ref({
  crear: false,
  actualizar: false,
})

const seleccionarPosicionPlan = (indexSemana: number, indexDia: number) => {
  posicionPlan.indexsemana = indexSemana
  posicionPlan.indexdia = indexDia
  isOpenCrearSesion.value = true
}

const crearSesion = (indexSemana: number, indexDia: number) => {
  opcionactual.value = ENOpcionesCru.CREAR
  seleccionarPosicionPlan(indexSemana, indexDia)
}

const verSesion = (indexSemana: number, indexDia: number) => {
  opcionactual.value = ENOpcionesCru.VER
  seleccionarPosicionPlan(indexSemana, indexDia)
}

const editarSesion = (indexSemana: number, indexDia: number) => {
  opcionactual.value = ENOpcionesCru.EDITAR
  seleccionarPosicionPlan(indexSemana, indexDia)
}

const eliminarSesion = (semana: number, dia: number) => {
  semanaComodinStore.eliminarSesion(semana, dia)
}

const agregarSesion = (rutina: Rutina) => {
  isOpenCrearSesion.value = false
  semanaComodinStore.adicionarSesion(
    rutina,
    posicionPlan.indexsemana,
    posicionPlan.indexdia
  )
}

const disablePlan = computed(() => {
  if (!plan.value.deporte_rutina || !plan.value.vam) return false
  return true
})
const validationSchema = toFormValidator(
  zod.object({
    deporte_rutina: zod.string({
      required_error: 'requerido',
      invalid_type_error: 'tipo ivalido',
    }),
    vam: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(0, 'Valor invalido'),
  })
)
const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    deporte_rutina: DeportesDisponibles.ATLETISMO,
    vam: 0,
  },
})

const crearSemanaComodin = handleSubmit(() => {
  semanaComodinStore.guardarPlan({ ...plan.value })
  mostrarCofirmarOpciones.value.crear = false
})

const actualizarPlan = () => {
  emits('actualizar-comodin')
  semanaComodinStore.actualizarPlan({ ...plan.value })
  mostrarCofirmarOpciones.value.actualizar = false
}

const cancelar = () => {
  emits('cancelar')
}

onMounted(() => {
  semanaComodinStore.resetValues()
  if (props.plananterior) {
    plan.value = props.plananterior
    semanaComodinStore.asignarBloquesSemana(props.plananterior.plan)
  }
  if (props.opcioncrudplanes === ENOpcionesCru.CREAR) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = true
    opcionesCrudDispo.value.eliminar = true
    opcionactual.value = ENOpcionesCru.CREAR
  }
  if (props.opcioncrudplanes === ENOpcionesCru.EDITAR) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = true
    opcionesCrudDispo.value.eliminar = true
    opcionactual.value = ENOpcionesCru.EDITAR
  }
  if (props.opcioncrudplanes === ENOpcionesCru.VER) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = false
    opcionesCrudDispo.value.eliminar = false
    opcionactual.value = ENOpcionesCru.VER
  }
})
</script>

<template>
  <div>
    <div class="login-form">
      <!-- Username -->
      <VField id="deporte_rutina" v-slot="{ field }">
        <VControl>
          <VSelect v-model="plan.deporte_rutina">
            <VOption
              v-for="(deporte, index) in deportesDisponibles"
              :key="index"
              :value="deporte"
              >{{ deporte }}</VOption
            >
            <p v-if="field?.errorMessage" class="help is-danger">
              {{ field.errorMessage }}
            </p>
          </VSelect>
        </VControl>
      </VField>

      <VField id="vam" v-slot="{ field }">
        <VControl icon="feather:user">
          <VInput
            v-model.number="plan.vam"
            type="number"
            placeholder="Ingrese valor vam..."
          />
          <p v-if="field?.errorMessage" class="help is-danger">
            {{ field.errorMessage }}
          </p>
        </VControl>
      </VField>
      <div
        v-for="(semana, indexSemana) in semanaComodinStore.semanaComodin"
        :key="indexSemana"
        class="columns"
      >
        <div v-for="(dia, indexDia) in semana" :key="indexDia" class="column">
          <div v-if="indexSemana === 0">
            {{ diasSemana[indexDia] }}
          </div>
          <div>
            <h2
              @keydown.space.prevent="crearSesion(indexSemana, indexDia)"
              @click="crearSesion(indexSemana, indexDia)"
            >
              {{ indexDia + 1 }}
            </h2>
            <div v-if="Object.keys(dia).length > 0">
              <VButton
                v-if="opcionesCrudDispo.ver"
                icon="feather:eye"
                @keydown.space.prevent="verSesion(indexSemana, indexDia)"
                @click="verSesion(indexSemana, indexDia)"
              ></VButton>
              <VButton
                v-if="opcionesCrudDispo.editar"
                icon="feather:edit"
                @keydown.space.prevent="editarSesion(indexSemana, indexDia)"
                @click="editarSesion(indexSemana, indexDia)"
              ></VButton>
              <VButton
                v-if="opcionesCrudDispo.eliminar"
                icon="feather:trash"
                @keydown.space.prevent="eliminarSesion(indexSemana, indexDia)"
                @click="eliminarSesion(indexSemana, indexDia)"
              ></VButton>
            </div>
          </div>
        </div>
      </div>
      <SesionSemanaComodin
        v-if="isOpenCrearSesion"
        :opcionactual="opcionactual"
        :semanaindex="posicionPlan.indexsemana"
        :diaindex="posicionPlan.indexdia"
        :is-open="isOpenCrearSesion"
        @close="isOpenCrearSesion = false"
        @crear-rutina="agregarSesion"
      />
      <VButton
        v-if="props.opcioncrudplanes === ENOpcionesCru.CREAR"
        color="success"
        :disabled="!disablePlan || !semanaComodinStore.validarSemana"
        @click="mostrarCofirmarOpciones.crear = true"
      >
        Crear Semana Comodin
      </VButton>
      <VButton
        v-if="props.opcioncrudplanes === ENOpcionesCru.EDITAR"
        color="warning"
        :disabled="!disablePlan || !semanaComodinStore.validarSemana"
        @click="mostrarCofirmarOpciones.actualizar = true"
      >
        Actualizar Semana Comodin
      </VButton>

      <VButton
        v-if="
          props.opcioncrudplanes === ENOpcionesCru.VER ||
          props.opcioncrudplanes === ENOpcionesCru.EDITAR
        "
        @click="cancelar"
      >
        Cancelar
      </VButton>
      <ModalOptions
        title="Registrar Semana Comodín"
        subtitle="Desea Realizar este registro"
        :mostrar="mostrarCofirmarOpciones.crear"
        confirm-msm="Guardar"
        @aceptar="crearSemanaComodin"
        @cancelar="mostrarCofirmarOpciones.crear = false"
      />
      <ModalOptions
        title="Actualizar Semana Comodín"
        subtitle="Desea Actualizar esta semana"
        :mostrar="mostrarCofirmarOpciones.actualizar"
        classconfirm="warning"
        confirm-msm="Actualizar"
        @aceptar="actualizarPlan"
        @cancelar="mostrarCofirmarOpciones.actualizar = false"
      />
    </div>
  </div>
</template>
