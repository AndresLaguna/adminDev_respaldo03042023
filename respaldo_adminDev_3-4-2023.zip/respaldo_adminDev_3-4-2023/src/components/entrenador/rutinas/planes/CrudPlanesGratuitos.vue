<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ENOpcionesCru } from '/@src/services/constantes'
import { PlanRutina } from '/@src/services/models/Rutinas'
import {
  ELIMINAR_PLAN_GRATUITO,
  LISTAR_RUTINAS_GRATUITAS_ENTRENADOR,
  LISTAR_PLANES_GRATUITOS,
} from '/@src/services/rutinas'
import { useUserSession } from '/@src/stores/userSession'

export interface CrudPlanesGratuitosProps {
  ver: boolean
  editar: boolean
  eliminar: boolean
  iddeportista?: string
}

const storeUseUserSession = useUserSession()
const props = defineProps<CrudPlanesGratuitosProps>()
const planes = ref<any[]>([])

const planAnterior = ref<PlanRutina>()

const opcionActual = ref<ENOpcionesCru>(ENOpcionesCru.CREAR)
const planEliminarId = ref('')

const mostrarCofirmarEliminar = ref(false)

const listarRutinas = async () => {
  if (props.iddeportista) {
    planes.value = await LISTAR_PLANES_GRATUITOS()
  } else {
    planes.value = await LISTAR_RUTINAS_GRATUITAS_ENTRENADOR(storeUseUserSession.userId)
  }
}

const verPlan = (rutina: PlanRutina) => {
  opcionActual.value = ENOpcionesCru.VER
  planAnterior.value = { ...rutina }
}

const editarPlan = (rutina: PlanRutina) => {
  opcionActual.value = ENOpcionesCru.EDITAR
  planAnterior.value = { ...rutina }
}

const seleccionarEliminarPlan = async (idRutina: string) => {
  planEliminarId.value = idRutina
  mostrarCofirmarEliminar.value = true
}

const eliminarPlan = async () => {
  await ELIMINAR_PLAN_GRATUITO(planEliminarId.value)
  mostrarCofirmarEliminar.value = false
  await listarRutinas()
}
const cerrarPlan = () => {
  opcionActual.value = ENOpcionesCru.VER
  planAnterior.value = undefined
}

const planActualizado = async () => {
  planAnterior.value = undefined
  mostrarCofirmarEliminar.value = false
  await listarRutinas()
}

onMounted(() => {
  listarRutinas()
})
</script>

<template>
  <div>
    <div v-if="!planAnterior">
      <div v-for="(rutina, index) in planes" :key="index" class="columns">
        <div class="column">
          <h5>{{ rutina.deporte }}</h5>
          <p>{{ rutina.descripcion }}</p>
        </div>
        <div class="column">
          <VButton v-if="props.ver" color="warning" @click="() => verPlan(rutina)">
            Ver
          </VButton>
          <VButton v-if="props.editar" color="success" @click="() => editarPlan(rutina)">
            Editar
          </VButton>
          <VButton
            v-if="props.eliminar"
            color="danger"
            @click="seleccionarEliminarPlan(rutina.id)"
          >
            Eliminar
          </VButton>
        </div>
      </div>
    </div>
    <PlanGratuito
      v-else
      :opcioncrudplanes="opcionActual"
      :crear="false"
      :ver="props.ver"
      :editar="props.editar"
      :eliminar="props.eliminar"
      :plananterior="planAnterior"
      :iddeportista="props.iddeportista"
      @cancelar="cerrarPlan"
      @actualizar-plan="planActualizado"
    />
    <ModalOptions
      title="Confirmación"
      subtitle="Desea Eliminar este plan"
      :mostrar="mostrarCofirmarEliminar"
      classconfirm="danger"
      confirm-msm="Eliminar Plan"
      @aceptar="eliminarPlan"
      @cancelar="mostrarCofirmarEliminar = false"
    />
  </div>
</template>
