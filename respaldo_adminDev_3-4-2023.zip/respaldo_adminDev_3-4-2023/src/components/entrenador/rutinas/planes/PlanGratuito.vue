<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { z as zod } from 'zod'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'

import { NEW_REVERT_SEMANA_RUTINA } from '/@src/services/funciones/rutina'
import {
  DeportesDisponibles,
  DEPORTES_DISPONIBLES,
} from '/@src/services/models/DeportesDisponibles'
import { PlanRutina, Rutina } from '/@src/services/models/Rutinas'
import { ASIGNAR_RUTINA_DESDE_BRONCE } from '/@src/services/rutinas'
import { usePlanRutina } from '/@src/stores/planRutina'

import { ENOpcionesCru } from '/@src/services/constantes'
import { nombreDiasSemana } from '/@src/services/constantes'

export interface IPlanGratuitoProps {
  plananterior?: PlanRutina
  crear: boolean
  editar: boolean
  ver: boolean
  eliminar: boolean
  opcioncrudplanes: ENOpcionesCru
  iddeportista?: string
}

export interface IPlanGratuitoEmits {
  (event: 'cancelar'): void
  (event: 'actualizar-plan'): void
}

const deportesDisponibles = DEPORTES_DISPONIBLES
const diasSemana = nombreDiasSemana

const planRutinaStore = usePlanRutina()

const emits = defineEmits<IPlanGratuitoEmits>()
const props = defineProps<IPlanGratuitoProps>()

const mostrarCofirmarOpciones = ref({
  crear: false,
  actualizar: false,
  inscribirse: false,
})

const opcionesCrudDispo = ref({
  ver: false,
  editar: false,
  eliminar: false,
})
const plan = ref<PlanRutina>({
  deporte: DeportesDisponibles.ATLETISMO,
  plan: [],
  descripcion: '',
  nombre_plan: '',
  objetivos: '',
  id_entrenador: '',
  nombre_entrenador: '',
})
const isOpenCrearSesion = ref(false)
const posicionPlan = reactive({
  indexsemana: 0,
  indexdia: 0,
})
const opcionactual = ref<ENOpcionesCru>(ENOpcionesCru.CREAR)
const verSemanasPlan = ref(2)

const seleccionarPosicionPlan = (indexSemana: number, indexDia: number) => {
  posicionPlan.indexsemana = indexSemana
  posicionPlan.indexdia = indexDia
  isOpenCrearSesion.value = true
}

const crearSesion = (indexSemana: number, indexDia: number) => {
  if (
    props.opcioncrudplanes === ENOpcionesCru.CREAR ||
    props.opcioncrudplanes === ENOpcionesCru.EDITAR
  ) {
    opcionactual.value = ENOpcionesCru.CREAR
    seleccionarPosicionPlan(indexSemana, indexDia)
  }
}

const verSesion = (indexSemana: number, indexDia: number) => {
  opcionactual.value = ENOpcionesCru.VER
  seleccionarPosicionPlan(indexSemana, indexDia)
}

const editarSesion = (indexSemana: number, indexDia: number) => {
  opcionactual.value = ENOpcionesCru.EDITAR
  seleccionarPosicionPlan(indexSemana, indexDia)
}

const eliminarSesion = (semana: number, dia: number) => {
  planRutinaStore.eliminarSesion(semana, dia)
}

const agregarSesion = (rutina: Rutina) => {
  isOpenCrearSesion.value = false
  planRutinaStore.adicionarSesion(rutina, posicionPlan.indexsemana, posicionPlan.indexdia)
}

const disablePlan = computed(() => {
  if (
    !plan.value.deporte ||
    plan.value.nombre_plan.length < 4 ||
    plan.value.nombre_plan.length > 50 ||
    plan.value.descripcion.length < 4 ||
    plan.value.descripcion.length > 200 ||
    plan.value.objetivos.length < 4
  )
    return false
  return true
})
const validationSchema = toFormValidator(
  zod.object({
    deporte: zod.string({
      required_error: 'requerido',
      invalid_type_error: 'tipo ivalido',
    }),
    nombre_plan: zod
      .string({
        required_error: 'requerido',
        invalid_type_error: 'tipo ivalido',
      })
      .min(4, 'Nombre de plan muy corto')
      .max(50, 'Nombre de plan muy largo'),
    descripcion: zod
      .string({
        required_error: 'Este campo es requerido',
        invalid_type_error: 'Valor de segundos invalido',
      })
      .min(4, 'Descripción de plan muy corto')
      .max(200, 'Descripción de plan muy largo'),
    objetivos: zod
      .string({
        required_error: 'Este campo es requerido',
        invalid_type_error: 'Valor de segundos invalido',
      })
      .min(4, 'Objetivos de plan muy corto'),
  })
)
const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    deporte: DeportesDisponibles.ATLETISMO,
    nombre: '',
    descripcion: '',
    objetivos: '',
  },
})

const crearPlan = handleSubmit(() => {
  planRutinaStore.guardarPlan({ ...plan.value })
  plan.value.descripcion = ''
  plan.value.nombre_plan = ''
  plan.value.objetivos = ''
  mostrarCofirmarOpciones.value.crear = false
})

const actualizarPlan = () => {
  emits('actualizar-plan')
  planRutinaStore.actualizarPlan({ ...plan.value })
  mostrarCofirmarOpciones.value.actualizar = false
}

const inscribirsePlan = async () => {
  if (props.iddeportista && props.plananterior) {
    await ASIGNAR_RUTINA_DESDE_BRONCE(props.iddeportista, {
      ...props.plananterior,
      plan: NEW_REVERT_SEMANA_RUTINA(props.plananterior.plan),
    })
    mostrarCofirmarOpciones.value.inscribirse = false
  }
}

const cancelar = () => {
  emits('cancelar')
}

onMounted(() => {
  planRutinaStore.resetValues()
  if (props.plananterior) {
    plan.value = props.plananterior
    planRutinaStore.asignarBloquesSemana(props.plananterior.plan)
  }
  if (props.opcioncrudplanes === ENOpcionesCru.CREAR) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = true
    opcionesCrudDispo.value.eliminar = true
    opcionactual.value = ENOpcionesCru.CREAR
  }
  if (props.opcioncrudplanes === ENOpcionesCru.EDITAR) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = true
    opcionesCrudDispo.value.eliminar = true
    opcionactual.value = ENOpcionesCru.EDITAR
  }
  if (props.opcioncrudplanes === ENOpcionesCru.VER) {
    opcionesCrudDispo.value.ver = true
    opcionesCrudDispo.value.editar = false
    opcionesCrudDispo.value.eliminar = false
    opcionactual.value = ENOpcionesCru.VER
  }
})
</script>

<template>
  <div class="login-form">
    <!-- Username -->
    <VField id="deporte" v-slot="{ field }">
      <VControl>
        <VSelect v-model="plan.deporte">
          <VOption
            v-for="(deporte, index) in deportesDisponibles"
            :key="index"
            :value="deporte"
            >{{ deporte }}</VOption
          >
          <p v-if="field?.errorMessage" class="help is-danger">
            {{ field.errorMessage }}
          </p>
        </VSelect>
      </VControl>
    </VField>
    <VField id="nombre_plan" v-slot="{ field }">
      <VControl icon="feather:user">
        <VInput
          v-model="plan.nombre_plan"
          type="text"
          placeholder="Ingrese un nombre del plan de entrenamiento"
          autocomplete="username"
        />
        <p v-if="field?.errorMessage" class="help is-danger">
          {{ field.errorMessage }}
        </p>
      </VControl>
    </VField>
    <VField id="descripcion" v-slot="{ field }">
      <VControl icon="feather:user">
        <VInput
          v-model="plan.descripcion"
          type="text"
          placeholder="Ingrese una descripcion..."
          autocomplete="username"
        />
        <p v-if="field?.errorMessage" class="help is-danger">
          {{ field.errorMessage }}
        </p>
      </VControl>
    </VField>
    <VField id="objetivos" v-slot="{ field }">
      <VControl icon="feather:user">
        <VInput
          v-model="plan.objetivos"
          type="text"
          placeholder="Ingrese los objetivos del plan..."
          autocomplete="username"
        />
        <p v-if="field?.errorMessage" class="help is-danger">
          {{ field.errorMessage }}
        </p>
      </VControl>
    </VField>

    <div
      v-for="(semana, indexSemana) in planRutinaStore.semanasRutina"
      :key="indexSemana"
      class="columns"
    >
      <div v-for="(dia, indexDia) in semana" :key="indexDia" class="column">
        <div v-if="indexSemana === 0">
          {{ diasSemana[indexDia] }}
        </div>
        <div>
          <h2
            @keydown.space.prevent="crearSesion(indexSemana, indexDia)"
            @click="crearSesion(indexSemana, indexDia)"
          >
            {{ indexDia + 1 }}
          </h2>
          <div v-if="Object.keys(dia).length > 0">
            <VButton
              v-if="opcionesCrudDispo.ver"
              icon="feather:eye"
              :disabled="indexSemana + 1 > verSemanasPlan"
              @keydown.space.prevent="verSesion(indexSemana, indexDia)"
              @click="verSesion(indexSemana, indexDia)"
            ></VButton>
            <VButton
              v-if="opcionesCrudDispo.editar"
              icon="feather:edit"
              @keydown.space.prevent="editarSesion(indexSemana, indexDia)"
              @click="editarSesion(indexSemana, indexDia)"
            ></VButton>
            <VButton
              v-if="opcionesCrudDispo.eliminar"
              icon="feather:trash"
              @keydown.space.prevent="eliminarSesion(indexSemana, indexDia)"
              @click="eliminarSesion(indexSemana, indexDia)"
            ></VButton>
          </div>
        </div>
      </div>
    </div>
    <SesionRutinaGratuita
      v-if="isOpenCrearSesion"
      :opcionactual="opcionactual"
      :semanaindex="posicionPlan.indexsemana"
      :diaindex="posicionPlan.indexdia"
      :is-open="isOpenCrearSesion"
      @close="isOpenCrearSesion = false"
      @crear-rutina="agregarSesion"
    />
    <VButton
      v-if="props.opcioncrudplanes === ENOpcionesCru.CREAR"
      color="success"
      :disabled="!disablePlan || !planRutinaStore.validarSemana"
      @click="() => (mostrarCofirmarOpciones.crear = true)"
    >
      Crear plan
    </VButton>
    <VButton
      v-if="props.opcioncrudplanes === ENOpcionesCru.EDITAR"
      color="warning"
      :disabled="!disablePlan || !planRutinaStore.validarSemana"
      @click="() => (mostrarCofirmarOpciones.actualizar = true)"
    >
      Actualizar plan
    </VButton>
    <VButton
      v-if="props.iddeportista"
      color="success"
      @click="() => (mostrarCofirmarOpciones.inscribirse = true)"
    >
      Inscribirse plan
    </VButton>

    <VButton
      v-if="
        props.opcioncrudplanes === ENOpcionesCru.VER ||
        props.opcioncrudplanes === ENOpcionesCru.EDITAR
      "
      @click="() => cancelar()"
    >
      Cancelar
    </VButton>
    <ModalOptions
      title="Registrar plan de entrenamiento"
      subtitle="Desea Guardar este plan"
      :mostrar="mostrarCofirmarOpciones.crear"
      confirm-msm="Guardar Plan"
      @aceptar="crearPlan"
      @cancelar="mostrarCofirmarOpciones.crear = false"
    />
    <ModalOptions
      title="Actualizar plan de entrenamiento"
      subtitle="Desea Actualizar este plan"
      :mostrar="mostrarCofirmarOpciones.actualizar"
      classconfirm="warning"
      confirm-msm="Actualizar Plan"
      @aceptar="actualizarPlan"
      @cancelar="mostrarCofirmarOpciones.actualizar = false"
    />
    <ModalOptions
      title="Inscribirse a este plan de entrenamiento"
      subtitle="Desea Inscribirse a este plan"
      :mostrar="mostrarCofirmarOpciones.inscribirse"
      confirm-msm="Inscribirme"
      @aceptar="inscribirsePlan"
      @cancelar="mostrarCofirmarOpciones.inscribirse = false"
    />
  </div>
</template>
