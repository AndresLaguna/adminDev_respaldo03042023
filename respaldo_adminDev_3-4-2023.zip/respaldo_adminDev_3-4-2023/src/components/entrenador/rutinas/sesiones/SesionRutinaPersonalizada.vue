<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'

import { IComentarioRutina, IRutinaPersonalizada } from '/@src/services/models/Rutinas'
import {
  GET_TIPOS_INTENSIDAD_RUTINAS,
  TIPO_MEDICION_RUTINA,
} from '/@src/services/funciones/globales'
import { BloqueDistancia, BloqueTiempo } from '/@src/services/models/Bloques'
import { useUserSession } from '/@src/stores/userSession'

export interface CrearSesionEmits {
  (e: 'close'): void
  (e: 'crear-rutina', rutina: IRutinaPersonalizada): void
  (e: 'actualizar-rutina', rutina: IRutinaPersonalizada): void
  (e: 'actualizar-comentarios', rutina: IRutinaPersonalizada): void
  (e: 'eliminar-rutina', idRutina: string): void
}

export interface CrearSesionProps {
  opcionactual: 'crear' | 'ver' | 'editar'
  isOpen: boolean
  rutinaanterior: IRutinaPersonalizada
}

const comentariosPorPaginacion = 4

const userSession = useUserSession()

const tiposIntensidad = GET_TIPOS_INTENSIDAD_RUTINAS()
const tiposMedicion = TIPO_MEDICION_RUTINA

const props = withDefaults(defineProps<CrearSesionProps>(), {
  opcionactual: undefined,
  isOpen: undefined,
  rutinaanterior: undefined,
})
const emits = defineEmits<CrearSesionEmits>()

const datosRutina = ref<IRutinaPersonalizada>({
  tipo_esfuerzo: '',
  tipo_medicion: '',
  descripcion: '',
  bloques: [],
  id: '',
  fecha: new Date(),
  id_deportista: '',
  id_entrenador: '',
  comentarios: [],
})
const nuevoComentarioBloque = ref<IComentarioRutina>({
  autor: '',
  comentario: '',
  fecha: 0,
  id: 0,
  rol: '',
})

const comentariosActuales = ref(0)
const validacionCrearRutina = ref(false)

onMounted(() => {
  if (props.opcionactual === 'ver' || props.opcionactual === 'editar') {
    datosRutina.value = { ...props.rutinaanterior }
  } else {
    datosRutina.value.tipo_esfuerzo = tiposIntensidad[0]
    datosRutina.value.tipo_medicion = tiposMedicion[1]
  }
})

const comentariosOrdenados = computed(() => {
  const comentarios = datosRutina.value.comentarios
  const order = comentarios
    .sort((a: IComentarioRutina, b: IComentarioRutina) => b.fecha - a.fecha)
    .map((comentario: IComentarioRutina) => {
      return { ...comentario, fecha: new Date(comentario.fecha).toLocaleString() }
    })
    .splice(
      comentariosActuales.value * comentariosPorPaginacion,
      comentariosPorPaginacion
    )
  return order
})

const agregarBloque = (bloque: BloqueDistancia | BloqueTiempo) => {
  datosRutina.value.bloques?.push({ ...bloque })
}

const eliminarBloque = (index: number) => {
  datosRutina.value.bloques?.splice(index, 1)
}

const cerrarRutina = () => {
  datosRutina.value.descripcion = ''
  datosRutina.value.bloques = []
  emits('close')
}

const syncValidacionCrearRutina = (valor: boolean) => {
  validacionCrearRutina.value = valor
}

const crearRutina = () => {
  emits('crear-rutina', datosRutina.value)
}

const actualizarRutina = () => {
  emits('actualizar-rutina', datosRutina.value)
}

const eliminarRutina = () => {
  emits('eliminar-rutina', datosRutina.value.id)
}

const cargarOtrosComentarios = () => {
  comentariosActuales.value++
}

const agregarComentario = () => {
  nuevoComentarioBloque.value.autor = userSession.userData?.nombres
  nuevoComentarioBloque.value.fecha = new Date().getTime()
  nuevoComentarioBloque.value.rol = userSession?.userRol
  const comentariosOrdenados = datosRutina.value.comentarios.sort(
    (a: IComentarioRutina, b: IComentarioRutina) => a.id - b.id
  )
  nuevoComentarioBloque.value.id =
    comentariosOrdenados.length > 0
      ? comentariosOrdenados[comentariosOrdenados.length - 1].id + 1
      : 1
  datosRutina.value.comentarios.push({ ...nuevoComentarioBloque.value })
  emits('actualizar-comentarios', datosRutina.value)
  nuevoComentarioBloque.value.comentario = ''
}

const resetBloques = () => {
  datosRutina.value.bloques = []
}
</script>

<template>
  <VModal
    :open="props.isOpen"
    noclosebutton
    title="Rutina"
    size="big"
    actions="center"
    noscroll
    noclose
  >
    <template #content>
      <div class="columns">
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">
            {{ datosRutina.descripcion ? datosRutina.descripcion : 'Sin descripción' }}
          </h2>
          <VControl v-else>
            <VInput
              v-model="datosRutina.descripcion"
              type="text"
              placeholder="Descripción"
            />
          </VControl>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">{{ datosRutina.tipo_esfuerzo }}</h2>
          <VControl v-else>
            <VSelect v-model="datosRutina.tipo_esfuerzo" @change="resetBloques">
              <VOption
                v-for="(deporte, index) in tiposIntensidad"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">{{ datosRutina.tipo_medicion }}</h2>
          <VControl v-else>
            <VSelect v-model="datosRutina.tipo_medicion" @change="resetBloques">
              <VOption
                v-for="(deporte, index) in tiposMedicion"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
      </div>

      <BloquesTiempo
        v-if="datosRutina.tipo_medicion === tiposMedicion[0]"
        :datosrutina="datosRutina"
        :opcionactual="props.opcionactual"
        @sync="syncValidacionCrearRutina"
        @agregar="agregarBloque"
        @eliminar="eliminarBloque"
      />
      <BloquesDistancia
        v-if="datosRutina.tipo_medicion === tiposMedicion[1]"
        :datosrutina="datosRutina"
        :opcionactual="props.opcionactual"
        @sync="syncValidacionCrearRutina"
        @agregar="agregarBloque"
        @eliminar="eliminarBloque"
      />
      <div v-if="opcionactual !== 'crear'">
        <h1>Comentarios</h1>
        <div class="columns">
          <div class="column is-10">
            <VControl>
              <VInput
                v-model="nuevoComentarioBloque.comentario"
                class="coment"
                type="text"
                placeholder="Descripción"
              />
            </VControl>
          </div>
          <div id="btn-little" class="column is-2">
            <VButton
              :disabled="!nuevoComentarioBloque.comentario"
              color="primary"
              @click="agregarComentario"
              >Comentar</VButton
            >
          </div>
        </div>
        <div
          v-for="(comentario, index) in comentariosOrdenados"
          :key="index"
          class="columns is-1 is-mobile is-desktop"
        >
          <div v-if="comentario.rol === 'Entrenador'" class="column is-8 is-half">
            <VCard radius="small" elevated color="info">
              <div class="card-head">
                <VBlock
                  :title="comentario.autor"
                  :subtitle="comentario.rol"
                  m-responsive
                  t-responsive
                  class="no-margin"
                >
                  <template #icon>
                    <VAvatar picture="/demo/avatars/19.jpg" />
                  </template>
                </VBlock>
                {{ comentario.fecha }}
              </div>

              <div class="" style="word-wrap: break-word">
                <p>
                  {{ comentario.comentario }}
                </p>
              </div>
            </VCard>
          </div>
          <div v-else class="column is-8 is-offset-4">
            <VCard radius="small" elevated color="success">
              <div class="card-head">
                <VBlock
                  :title="comentario.autor"
                  :subtitle="comentario.rol"
                  m-responsive
                  t-responsive
                  class="no-margin"
                >
                  <template #icon>
                    <VAvatar picture="/demo/avatars/19.jpg" />
                  </template>
                </VBlock>
                {{ comentario.fecha }}
              </div>
              <div class="" style="word-wrap: break-word">
                <p>
                  {{ comentario.comentario }}
                </p>
              </div>
            </VCard>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <a
              v-if="
                datosRutina.comentarios.length > comentariosPorPaginacion &&
                comentariosActuales <
                  Math.trunc(datosRutina.comentarios.length / comentariosPorPaginacion)
              "
              @click="cargarOtrosComentarios"
              @keypress="cargarOtrosComentarios"
            >
              Ver comentarios anteriores...
            </a>
          </div>
          <div class="column">
            <a
              v-if="comentariosActuales > 0"
              @click="comentariosActuales = 0"
              @keypress="comentariosActuales = 0"
            >
              Recientes
            </a>
          </div>
        </div>
      </div>
    </template>
    <template #action>
      <VButton
        v-if="props.opcionactual === 'crear'"
        color="primary"
        :disabled="!validacionCrearRutina"
        raised
        @click="crearRutina"
        >Crear Rutina</VButton
      >
      <VButton
        v-if="props.opcionactual === 'editar'"
        color="warning"
        raised
        :disabled="
          !(
            validacionCrearRutina ||
            datosRutina.descripcion !== props.rutinaanterior.descripcion
          )
        "
        @click="actualizarRutina"
        >Actualizar Rutina</VButton
      >
      <VButton
        v-if="props.opcionactual === 'editar'"
        color="danger"
        raised
        @click="eliminarRutina"
        >Eliminar Rutina</VButton
      >
    </template>
    <template #cancel>
      <VButton raised @click="cerrarRutina">Cancelar</VButton>
    </template>
  </VModal>
</template>

<style lang="scss">
.coment {
  height: 25px;
}

.btn-little {
  padding: 0;
  margin: 0;
  align-content: 0;
}

.no-pad {
  padding: 0;
}
</style>
