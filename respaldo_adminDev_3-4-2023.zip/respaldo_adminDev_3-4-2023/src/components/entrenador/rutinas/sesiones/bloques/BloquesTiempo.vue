<script setup lang="ts">
import { reactive, ref, computed, watch } from 'vue'
import { z as zod } from 'zod'
import { toFormValidator } from '@vee-validate/zod'
import { useForm } from 'vee-validate'

import { BloqueTiempo } from '/@src/services/models/Bloques'
import {
  GET_OPCIONES_INSIDAD_RUTINA,
  TIPO_BLOQUE,
} from '/@src/services/funciones/globales'
import { calcularSegundos, calcularTiempoConSeg } from '/@src/services/funciones/tiempos'
import { validarBloqueTiempo } from '/@src/services/validaciones/rutinasVal'
import { Rutina } from '/@src/services/models/Rutinas'

export interface BloquesTiempoProps {
  datosrutina: Rutina
  opcionactual: string
}

export interface BloquesTiempoEmit {
  (event: 'sync', value: boolean): void
  (event: 'agregar', value: BloqueTiempo): void
  (event: 'eliminar', value: number): void
}

const emits = defineEmits<BloquesTiempoEmit>()

const props = defineProps<BloquesTiempoProps>()

const tipoBloque = TIPO_BLOQUE
const opcionesIntensidad = ref(
  GET_OPCIONES_INSIDAD_RUTINA(props.datosrutina.tipo_esfuerzo).valuesEntrenador
)

const datosNuevoBloque = reactive<BloqueTiempo>({
  tipo: tipoBloque[0],
  duracion_min: 5,
  duracion_seg: 0,
  intensidad: opcionesIntensidad.value[0],
})

const tiempoTotalComputed = computed(() => {
  let tiempoSegundos = 0
  props.datosrutina.bloques.forEach((bloque: any) => {
    tiempoSegundos += calcularSegundos(bloque.duracion_min, bloque.duracion_seg)
  })
  return calcularTiempoConSeg(tiempoSegundos)
})

const validarNuevoBloqueComputed = computed(() => validarBloqueTiempo(datosNuevoBloque))

watch(props.datosrutina.bloques, () => {
  let valido: boolean = true
  if (props.datosrutina.bloques.length === 0) {
    valido = false
  }
  props.datosrutina.bloques.forEach((bloque) => {
    if (!validarBloqueTiempo(bloque)) {
      valido = false
    }
  })
  emits('sync', valido)
})

watch(
  () => props.datosrutina.tipo_esfuerzo,
  () => {
    opcionesIntensidad.value = GET_OPCIONES_INSIDAD_RUTINA(
      props.datosrutina.tipo_esfuerzo
    ).valuesEntrenador
    datosNuevoBloque.intensidad = opcionesIntensidad.value[0]
  }
)

const validationSchema = toFormValidator(
  zod.object({
    duracion_min: zod
      .number({
        required_error: 'Este campo es requerido',
        invalid_type_error: 'Valor de segundos invalido',
      })
      .min(0, 'Valor Mínimo debe ser 1'),
    duracion_seg: zod
      .number({
        required_error: 'Este campo es requerido',
        invalid_type_error: 'Valor de segundos invalido',
      })
      .min(0, 'Valor no valido')
      .max(59, 'Valor Máximo debe ser 59'),
  })
)
const { handleSubmit } = useForm({
  validationSchema,
  initialValues: {
    duracion_min: 5,
    duracion_seg: 0,
  },
})
const agregarBloque = handleSubmit(() => {
  emits('agregar', datosNuevoBloque)
})

const eliminarBloque = (index: number) => {
  emits('eliminar', index)
}
</script>

<template>
  <div>
    <!-- Columnas de bloque -->
    <div v-if="opcionactual !== 'ver'">
      <div class="columns">
        <div class="column">
          <h2>Tipo</h2>
        </div>
        <div class="column">
          <h2>Duración (Min)</h2>
        </div>
        <div class="column">
          <h2>Duración (Seg)</h2>
        </div>
        <div class="column">
          <h2>Intensidad</h2>
        </div>
        <div class="column">
          <h2>Agregar Bloque</h2>
        </div>
      </div>
      <!-- Agregar bloque -->
      <div class="columns">
        <div class="column">
          <VControl>
            <VSelect v-model="datosNuevoBloque.tipo">
              <VOption
                v-for="(deporte, index) in tipoBloque"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
        <div class="column">
          <VControl id="duracion_min" v-slot="{ field }">
            <VInput
              v-model.number="datosNuevoBloque.duracion_min"
              type="text"
              placeholder="Ingrese duración en minutos"
            />
            <p v-if="field?.errorMessage" class="help is-danger">
              {{ field.errorMessage }}
            </p>
          </VControl>
        </div>
        <div class="column">
          <VControl id="duracion_seg" v-slot="{ field }">
            <VInput
              v-model.number="datosNuevoBloque.duracion_seg"
              type="text"
              placeholder="Ingrese duración en segundos"
            />
            <p v-if="field?.errorMessage" class="help is-danger">
              {{ field.errorMessage }}
            </p>
          </VControl>
        </div>
        <div class="column">
          <VControl>
            <VSelect v-model="datosNuevoBloque.intensidad">
              <VOption
                v-for="(deporte, index) in opcionesIntensidad"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
        <div class="column">
          <VButton
            icon="feather:plus"
            color="success"
            :disabled="!validarNuevoBloqueComputed"
            @keydown.space.prevent="agregarBloque"
            @click="agregarBloque"
          ></VButton>
        </div>
      </div>
    </div>
    <!-- Listado de bloques -->
    <div>
      <h3 class="mb-4">Bloques</h3>
      <div
        v-for="(bloque, index) in props.datosrutina.bloques"
        :key="index"
        class="columns"
      >
        <div class="column">
          <VControl>
            <VSelect v-model="bloque.tipo">
              <VOption
                v-for="(deporte, indexTp) in tipoBloque"
                :key="indexTp"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>

        <div class="column">
          <VControl>
            <VInput
              v-model.number="bloque.duracion_min"
              type="text"
              placeholder="Ingrese duración en minutos"
            />
          </VControl>
        </div>
        <div class="column">
          <VControl>
            <VInput
              v-model.number="bloque.duracion_seg"
              type="text"
              placeholder="Ingrese duración en segundos"
            />
          </VControl>
        </div>

        <div class="column">
          <VControl>
            <VSelect v-model="bloque.intensidad">
              <VOption
                v-for="(deporte, indexIn) in opcionesIntensidad"
                :key="indexIn"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>

        <div v-if="opcionactual !== 'ver'" class="column">
          <VButton
            icon="feather:trash"
            color="danger"
            @keydown.space.prevent="eliminarBloque(index)"
            @click="eliminarBloque(index)"
          ></VButton>
        </div>
      </div>
    </div>
    <!-- Tiempo Total -->
    <div class="columns">
      <div class="column">
        <h3>Tiempo Rutina:</h3>
        <h3>
          {{ tiempoTotalComputed.minutos }} minutos /
          {{ tiempoTotalComputed.segundos }} segundos
        </h3>
      </div>
    </div>
  </div>
</template>
