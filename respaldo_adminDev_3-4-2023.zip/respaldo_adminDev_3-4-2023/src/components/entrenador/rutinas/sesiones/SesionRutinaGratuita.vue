<script setup lang="ts">
import { ref, onMounted } from 'vue'

import { Rutina } from '/@src/services/models/Rutinas'
import {
  GET_TIPOS_INTENSIDAD_RUTINAS,
  TIPO_MEDICION_RUTINA,
} from '/@src/services/funciones/globales'
import { BloqueDistancia, BloqueTiempo } from '/@src/services/models/Bloques'
import { usePlanRutina } from '/@src/stores/planRutina'

export interface CrearSesionEmits {
  (e: 'close'): void
  (e: 'crear-rutina', rutina: Rutina): void
}

export interface PosRutinaAnterior {
  indexSemana: number
  indexDia: number
}

export interface CrearSesionProps {
  opcionactual: 'crear' | 'ver' | 'editar'
  isOpen: boolean
  semanaindex: number
  diaindex: number
}

const storeUsePlanRutina = usePlanRutina()

const tiposIntensidad = GET_TIPOS_INTENSIDAD_RUTINAS()
const tiposMedicion = TIPO_MEDICION_RUTINA

const props = withDefaults(defineProps<CrearSesionProps>(), {
  opcionactual: undefined,
  isOpen: undefined,
  semanaindex: undefined,
  diaindex: undefined,
})

const emits = defineEmits<CrearSesionEmits>()

const datosRutina = ref<Rutina>({
  tipo_esfuerzo: '',
  tipo_medicion: '',
  descripcion: '',
  bloques: [],
})

const validacionCrearRutina = ref(false)

onMounted(() => {
  if (props.opcionactual === 'ver' || props.opcionactual === 'editar') {
    datosRutina.value = storeUsePlanRutina.obtenerSesion(
      props.semanaindex,
      props.diaindex
    )
  } else {
    datosRutina.value.tipo_esfuerzo = tiposIntensidad[0]
    datosRutina.value.tipo_medicion = tiposMedicion[1]
  }
})

const agregarBloque = (bloque: BloqueDistancia | BloqueTiempo) => {
  datosRutina.value.bloques?.push({ ...bloque })
}

const eliminarBloque = (index: number) => {
  datosRutina.value.bloques?.splice(index, 1)
}

const cerrarRutina = () => {
  emits('close')
}

const syncValidacionCrearRutina = (valor: boolean) => {
  validacionCrearRutina.value = valor
}

const crearRutina = () => {
  emits('crear-rutina', { ...datosRutina.value })
  datosRutina.value.descripcion = ''
  datosRutina.value.bloques = []
  emits('close')
}

const resetBloques = () => {
  datosRutina.value.bloques = []
}
</script>

<template>
  <VModal
    :open="props.isOpen"
    noclosebutton
    title="Rutina"
    size="big"
    actions="center"
    noscroll
    noclose
  >
    <template #content>
      <div class="columns">
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">
            {{ datosRutina.descripcion ? datosRutina.descripcion : 'Sin descripción' }}
          </h2>
          <VControl v-else>
            <VInput
              v-model="datosRutina.descripcion"
              type="text"
              placeholder="Descripción"
            />
          </VControl>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">{{ datosRutina.tipo_esfuerzo }}</h2>
          <VControl v-else>
            <VSelect v-model="datosRutina.tipo_esfuerzo" @change="resetBloques">
              <VOption
                v-for="(deporte, index) in tiposIntensidad"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
        <div class="column">
          <h2 v-if="opcionactual === 'ver'">{{ datosRutina.tipo_medicion }}</h2>
          <VControl v-else>
            <VSelect v-model="datosRutina.tipo_medicion" @change="resetBloques">
              <VOption
                v-for="(deporte, index) in tiposMedicion"
                :key="index"
                :value="deporte"
                >{{ deporte }}</VOption
              >
            </VSelect>
          </VControl>
        </div>
      </div>
      <BloquesTiempo
        v-if="datosRutina.tipo_medicion === tiposMedicion[0]"
        :datosrutina="datosRutina"
        :opcionactual="props.opcionactual"
        @sync="syncValidacionCrearRutina"
        @agregar="agregarBloque"
        @eliminar="eliminarBloque"
      />
      <BloquesDistancia
        v-if="datosRutina.tipo_medicion === tiposMedicion[1]"
        :datosrutina="datosRutina"
        :opcionactual="props.opcionactual"
        @sync="syncValidacionCrearRutina"
        @agregar="agregarBloque"
        @eliminar="eliminarBloque"
      />
    </template>
    <template v-if="props.opcionactual !== 'ver'" #action>
      <VButton
        color="primary"
        :disabled="!validacionCrearRutina"
        raised
        @click="crearRutina"
        >Crear Rutina</VButton
      >
    </template>
    <template #cancel>
      <VButton raised @click="cerrarRutina">Cancelar</VButton>
    </template>
  </VModal>
</template>
