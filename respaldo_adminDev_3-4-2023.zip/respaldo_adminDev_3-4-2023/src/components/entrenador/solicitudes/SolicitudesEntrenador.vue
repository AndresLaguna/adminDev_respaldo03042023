<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { EstadoSolicitudes, SolicitudMatch } from '/@src/services/models/Solicitudes'

import { onValue, ref as refFirebase } from 'firebase/database'
import { database } from '/@src/services/config'

import { useUserSession } from '/@src/stores/userSession'
import {
  GET_SOLICITUDES_DESDE_ENTRENADOR,
  CAMBIAR_ESTADO_INVITACION,
} from '/@src/services/match'
import { DeportesDisponibles } from '/@src/services/models/DeportesDisponibles'

const userStore = useUserSession()
const solicitudes = ref<SolicitudMatch[]>([])

const mostrarVerPerfilDeportista = ref(false)

const solicitudSeleccionada = ref<SolicitudMatch>({
  estado: EstadoSolicitudes.PENDIENTE,
  fecha_registro: 0,
  foto: '',
  id: '',
  id_deportista: '',
  id_entrenador: '',
  nombres: '',
  deporte: DeportesDisponibles.ATLETISMO,
})

const aceptarSolicitud = async () => {
  await CAMBIAR_ESTADO_INVITACION(solicitudSeleccionada.value, EstadoSolicitudes.APROBADO)
  mostrarVerPerfilDeportista.value = false
}

const cancelarSolicitud = async () => {
  await CAMBIAR_ESTADO_INVITACION(
    solicitudSeleccionada.value,
    EstadoSolicitudes.RECHAZADO
  )
  mostrarVerPerfilDeportista.value = false
}

const verPerfilDeportista = (idSolicitud: SolicitudMatch) => {
  solicitudSeleccionada.value = idSolicitud
  mostrarVerPerfilDeportista.value = true
}

onMounted(async () => {
  onValue(refFirebase(database, 'solicitudes'), (snapshot) => {
    if (snapshot.exists()) {
      GET_SOLICITUDES_DESDE_ENTRENADOR(userStore.userId, snapshot.val())
        .then((result) => {
          solicitudes.value = result
        })
        .catch((err) => {
          console.log(err)
        })
    } else {
      solicitudes.value = []
    }
  })
})
</script>

<template>
  <div>
    <div v-if="!mostrarVerPerfilDeportista">
      <div v-for="solicitud in solicitudes" :key="solicitud.id" class="columns">
        <div class="column">{{ solicitud.nombres }}</div>
        <div class="column">{{ solicitud.deporte }}</div>
        <div class="column">{{ solicitud.foto || 'foto' }}</div>
        <div class="row">
          <div class="column">
            <VButton color="success" @click="verPerfilDeportista(solicitud)">
              Ver Perfil
            </VButton>
          </div>
        </div>
      </div>
    </div>
    <VerPerfilDeportista
      v-if="mostrarVerPerfilDeportista"
      aprobado
      :iddeportista="solicitudSeleccionada.id_deportista"
      @cerrar="mostrarVerPerfilDeportista = false"
      @aceptar="aceptarSolicitud"
      @rechazar="cancelarSolicitud"
    />
  </div>
</template>
