<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { SolicitudMatch } from '/@src/services/models/Solicitudes'

import { onValue, ref as refFirebase } from 'firebase/database'
import { database } from '/@src/services/config'

import { useUserSession } from '/@src/stores/userSession'
import { GET_SOLICITUDES_APROBADAS_DESDE_ENTRENADOR } from '/@src/services/match'

const userStore = useUserSession()
const solicitudes = ref<SolicitudMatch[]>([])
const solicitudActual = ref<SolicitudMatch>()
const mostrarVerPerfilDeportista = ref(false)

const verSolicitud = async (solicitud: SolicitudMatch) => {
  solicitudActual.value = solicitud
}

const verPerfil = async (solicitud: SolicitudMatch) => {
  solicitudActual.value = solicitud
  mostrarVerPerfilDeportista.value = true
}

const cerrarPerfil = () => {
  mostrarVerPerfilDeportista.value = false
  solicitudActual.value = undefined
}

onMounted(async () => {
  solicitudActual.value = undefined
  onValue(refFirebase(database, 'solicitudes'), (snapshot) => {
    if (snapshot.exists()) {
      GET_SOLICITUDES_APROBADAS_DESDE_ENTRENADOR(userStore.userId, snapshot.val())
        .then((result) => {
          solicitudes.value = result
        })
        .catch((err) => {
          console.log(err)
        })
    } else {
      solicitudes.value = []
    }
  })
})
</script>

<template>
  <div>
    <div v-if="!solicitudActual">
      <div v-for="solicitud in solicitudes" :key="solicitud.id" class="columns">
        <div class="column">{{ solicitud.nombres }}</div>
        <div class="column">{{ solicitud.deporte }}</div>
        <div class="column">{{ solicitud.foto || 'foto' }}</div>
        <div class="column">
          <VButton color="warning" @click="() => verSolicitud(solicitud)">
            Ver Calendario
          </VButton>
          <VButton color="success" @click="() => verPerfil(solicitud)">
            Ver Perfil
          </VButton>
        </div>
      </div>
    </div>
    <Calendario
      v-if="solicitudActual && !mostrarVerPerfilDeportista"
      :iddeportista="solicitudActual.id_deportista"
      :identrenador="solicitudActual.id_entrenador"
      @close="solicitudActual = undefined"
    />
    <VerPerfilDeportista
      v-if="solicitudActual && mostrarVerPerfilDeportista"
      :aprobado="false"
      :iddeportista="solicitudActual.id_deportista"
      @cerrar="cerrarPerfil"
    />
  </div>
</template>
