<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { getDatosDeportista } from '/@src/services/deportista'

export interface PropsVerPerfilDeportista {
  iddeportista: string
  aprobado: boolean
}

export interface CrearSesionEmits {
  (e: 'cerrar'): void
  (e: 'aceptar'): void
  (e: 'rechazar'): void
}

const emits = defineEmits<CrearSesionEmits>()
const props = defineProps<PropsVerPerfilDeportista>()

const datosUsuario = ref()

const mostrarCofirmarOpciones = ref({
  cancelar: false,
  aceptar: false,
})

const cerrarPerfil = () => {
  emits('cerrar')
}

const aceptarSolicitud = () => {
  emits('aceptar')
}

const rechazarSolicitud = () => {
  emits('rechazar')
}

onMounted(async () => {
  const res = await getDatosDeportista(props.iddeportista)
  datosUsuario.value = res
})
</script>

<template>
  <div>
    <img
      width="200"
      :src="datosUsuario?.foto_url || '/images/avatars/svg/vuero-1.svg'"
      alt="#"
    />
    <div v-if="props.aprobado">
      <VButton color="primary" @click="mostrarCofirmarOpciones.aceptar = true">
        Aceptar Solicitud
      </VButton>
      <VButton color="danger" @click="mostrarCofirmarOpciones.cancelar = true">
        Rechazar Solicitud
      </VButton>
    </div>

    <div class="form-body">
      <!--Fieldset-->
      <div class="fieldset">
        <div class="fieldset-heading">
          <p>Bienvenido al Perfil de {{ datosUsuario?.nombres }}</p>
          <p>{{ datosUsuario?.estrellas }} estrellas</p>
        </div>
      </div>

      <div class="columns is-multiline">
        <!--Field-->
        <div class="column is-6">
          <p>Nombres</p>
          <VField>
            <h1>{{ datosUsuario?.nombres }}</h1>
          </VField>
        </div>
        <div class="column is-6">
          <p>Apellidos</p>
          <VField> {{ datosUsuario?.apellidos }} </VField>
        </div>

        <div class="column is-12">
          <p>Descripción</p>
          <VField> {{ datosUsuario?.descripcion }} </VField>
        </div>

        <div class="column is-12">
          <p>Fecha de nacimiento</p>
          <VField> {{ datosUsuario?.fecha_nacimiento }} </VField>
        </div>

        <!-- <div class="column is-6">
          <p>Nombre de usuario</p>
          <VField> {{ datosUsuario?.nameUser }} </VField>
        </div> -->

        <div class="column is-6">
          <p>Pais</p>
          <VField>{{ datosUsuario?.pais }} </VField>
        </div>

        <div class="column is-6">
          <p>Género</p>
          <VField> {{ datosUsuario?.genero }} </VField>
        </div>

        <div class="column is-6">
          <p>Ciudad</p>
          <VField> {{ datosUsuario?.ciudad }} </VField>
        </div>
      </div>
    </div>

    <VButton color="primary" @click="cerrarPerfil"> Cerrar </VButton>

    <ModalOptions
      title="Aceptar solicitud"
      subtitle="Una vez acepte la solicitud de este deportista podra tener contacto con el proximamente"
      :mostrar="mostrarCofirmarOpciones.aceptar"
      confirm-msm="Aprobar"
      @aceptar="aceptarSolicitud"
      @cancelar="mostrarCofirmarOpciones.aceptar = false"
    />
    <ModalOptions
      title="Rechazar Solicitud"
      subtitle="Desea Rechazar esta cancelar esta solicitud, ya no podra tener contacto con el deportista"
      :mostrar="mostrarCofirmarOpciones.cancelar"
      classconfirm="danger"
      confirm-msm="Rechazar"
      @aceptar="rechazarSolicitud"
      @cancelar="mostrarCofirmarOpciones.cancelar = false"
    />
  </div>
</template>
