<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { onValue, ref as reff } from 'firebase/database'
import { database } from '/@src/services/config'
import { ELIMINAR_INVITACION } from '/@src/services/match'

const centeredActionsOpen = ref(false)
const totalSolicitudes = ref(0)
const props = defineProps({
  solicitudes: {
    type: Array,
    required: true,
  },
  id: {
    type: String,
    required: true,
  },
  idEntrenador: {
    type: String,
    required: true,
  },
})

onMounted(async () => {
  onValue(
    reff(database, 'users/' + props.id + '/plan/solicitudesEnviadas'),
    (snapshot) => {
      if (snapshot.exists()) {
        totalSolicitudes.value = snapshot.val()
      } else {
        totalSolicitudes.value = null
      }
    }
  )
})

const cancelarInvitacion = async () => {
  let nuevaSolicitud = {}
  props.solicitudes.forEach((sol) => {
    if (sol.id_entrenador === props.idEntrenador) {
      nuevaSolicitud = sol
    }
  })
  const ts = totalSolicitudes.value - 1
  await ELIMINAR_INVITACION(nuevaSolicitud.id, props.id, ts)
  centeredActionsOpen.value = false
}
</script>

<template>
  <VButton rounded raised color="danger" bold @click="centeredActionsOpen = true">
    Cancelar Solicitud
  </VButton>

  <VModal
    title="Cancelar Solicitud"
    :open="centeredActionsOpen"
    actions="center"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <div>Seguro que deseas cancelar la solicitud al entrenador</div>
    </template>
    <template #action>
      <VButton color="primary" raised @click="cancelarInvitacion()">Confirmar</VButton>
    </template>
  </VModal>
</template>
