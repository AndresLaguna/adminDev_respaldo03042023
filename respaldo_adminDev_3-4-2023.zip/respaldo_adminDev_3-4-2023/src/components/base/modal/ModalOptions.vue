<script setup lang="ts">
interface IModalOptions {
  title: string
  subtitle?: string
  classconfirm?: string
  confirmMsm?: string
  classcancel?: string
  cancelMsm?: string
  mostrar: boolean
}

interface IModalOptionsEmits {
  (e: 'aceptar'): void
  (e: 'cancelar'): void
}

const emits = defineEmits<IModalOptionsEmits>()
const props = defineProps<IModalOptions>()

const aceptar = () => {
  emits('aceptar')
}

const cancelar = () => {
  emits('cancelar')
}
</script>

<template>
  <VModal
    :open="props.mostrar"
    noclosebutton
    :title="props.title || 'Confirmacíon'"
    size="big"
    actions="center"
    noscroll
    noclose
  >
    <template #content>
      <div>
        <h2>{{ props.subtitle }}</h2>
      </div>
    </template>
    <template #action>
      <VButton :color="props.classconfirm || 'primary'" raised @click="aceptar">{{
        props.confirmMsm || 'Aceptar'
      }}</VButton>
    </template>
    <template #cancel>
      <VButton :color="props.classcancel" raised @click="cancelar">{{
        props.cancelMsm || 'Cancelar'
      }}</VButton>
    </template>
  </VModal>
</template>
