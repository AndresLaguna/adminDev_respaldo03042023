<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { onValue, ref as reff } from 'firebase/database'
import { database } from '/@src/services/config'
import { ENVIAR_INVITACION } from '/@src/services/match'
const centeredActionsOpen = ref(false)
const totalSolicitudes = ref(0)
const estadoBienvenida = ref()
const props = defineProps({
  datosDeportista: {
    type: Object,
    required: true,
  },
  id: {
    type: String,
    required: true,
  },
  entrenador: {
    type: Object,
    required: true,
  },
})

onMounted(async () => {
  onValue(
    reff(database, 'users/' + props.id + '/plan/solicitudesEnviadas'),
    (snapshot) => {
      if (snapshot.exists()) {
        totalSolicitudes.value = snapshot.val()
      } else {
        totalSolicitudes.value = null
      }
    }
  )
  onValue(reff(database, 'users/' + props.id + '/bienvenida'), (snapshot) => {
    if (snapshot.exists()) {
      estadoBienvenida.value = snapshot.val()
    } else {
      estadoBienvenida.value = null
    }
  })
})
// 3
const enviarInvitacion = async () => {
  const ts = totalSolicitudes.value
  if (ts < props.datosDeportista.plan.solicitudes) {
    const actualBienvenida = estadoBienvenida.value
    const newBienvenida = estadoBienvenida.value - 1
    if (newBienvenida == 2) {
      await ENVIAR_INVITACION(
        { ...props.datosDeportista, id: props.id },
        props.entrenador,
        ts + 1,
        newBienvenida
      )
    } else {
      await ENVIAR_INVITACION(
        { ...props.datosDeportista, id: props.id },
        props.entrenador,
        ts + 1,
        actualBienvenida
      )
    }
  } else {
    // llego al limite
    // const newBienvenida = estadoBienvenida.value - 1
    // await ENVIAR_INVITACION(
    //   { ...props.datosDeportista, id: props.id },
    //   props.entrenador,
    //   ts,
    //   newBienvenida
    // )
  }
  centeredActionsOpen.value = false
}
</script>

<template>
  <VButton rounded raised color="success" bold @click="centeredActionsOpen = true">
    Enviar Solicitud
  </VButton>

  <VModal
    title="Enviar Solicitud"
    :open="centeredActionsOpen"
    actions="center"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <!-- <VPlaceholderSection
        title="Go Premium"
        subtitle="Unlock more features and business tools by going premium"
      /> -->
      <div>
        Estamos muy alegres que quieras enviar solicitud al entrenador
        {{ entrenador.nombres }} {{ entrenador.apellidos }}. Nos gustaria que confirmaras
        por favor!
      </div>
    </template>
    <template #action>
      <VButton color="primary" raised @click="enviarInvitacion()">Confirmar</VButton>
    </template>
  </VModal>
</template>
