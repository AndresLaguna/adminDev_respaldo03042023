<script setup lang="ts">
import { reactive, ref } from 'vue'
import '@fullcalendar/core/vdom'
import FullCalendar, {
  CalendarOptions,
  DateSelectArg,
  EventClickArg,
  EventInput,
} from '@fullcalendar/vue3'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import listPlugin from '@fullcalendar/list'
import interactionPlugin from '@fullcalendar/interaction'
import { IRutinaPersonalizada } from '/@src/services/models/Rutinas'
import {
  CREAR_RUTINA_PERSONALIZADA,
  LISTAR_RUTINAS_DEPORTISTA,
  ELIMINAR_RUTINA_PERSONALIZADA,
  ACTUALIZAR_RUTINA_PERSONALIZADA,
  LISTAR_RUTINAS_DEPORTISTA_ENTRENADOR,
} from '/@src/services/rutinas'

export interface CalendarioProps {
  iddeportista: string
  identrenador?: string
}

export interface CalendarioEmits {
  (event: 'close'): void
}

const props = defineProps<CalendarioProps>()
const emits = defineEmits<CalendarioEmits>()
const selectInfoEdit = ref<EventClickArg>()
const selectInfoSelect = ref<DateSelectArg>()

const rutinas = ref<IRutinaPersonalizada[]>()
//const rutinasCalendar = ref<EventInput[]>()
const fechaSeleccionada = ref(new Date())
const rutinaSelect = ref<IRutinaPersonalizada>()

const opcionactual = ref<'crear' | 'ver' | 'editar'>('crear')
const isOpenCrearSesion = ref(false)

const listarRutinas = async () => {
  if (props.identrenador) {
    rutinas.value = await LISTAR_RUTINAS_DEPORTISTA_ENTRENADOR(
      props.iddeportista,
      props.identrenador
    )
  } else {
    rutinas.value = await LISTAR_RUTINAS_DEPORTISTA(props.iddeportista)
  }
}

const listarRutinasInitial = async (): Promise<EventInput[]> => {
  await listarRutinas()
  const INITIAL_EVENTS: EventInput[] = []
  rutinas.value?.forEach((rutina: any) => {
    const t = new Date(1970, 0, 1) // Epoch
    t.setSeconds(rutina.fecha.seconds)
    const rutinaEv: EventInput = {
      id: rutina.id,
      title: rutina.descripcion,
      start: t.toISOString().replace(/T.*$/, ''),
    }
    INITIAL_EVENTS.push(rutinaEv)
  })
  return INITIAL_EVENTS
}

const abrirMenuNuevaRutina = (selectInfo: DateSelectArg) => {
  selectInfoSelect.value = selectInfo
  if (props.identrenador) {
    fechaSeleccionada.value = selectInfo.start
    opcionactual.value = 'crear'
    isOpenCrearSesion.value = true
  }
}

const abrirMenuEditarRutina = (selectInfo: EventClickArg) => {
  selectInfoEdit.value = selectInfo
  rutinas.value?.forEach((rutina: IRutinaPersonalizada) => {
    if (rutina.id === selectInfoEdit.value?.event.id) {
      rutinaSelect.value = { ...rutina }
      if (props.identrenador) {
        opcionactual.value = 'editar'
      } else {
        opcionactual.value = 'ver'
      }
      isOpenCrearSesion.value = true
    }
  })
}

const cerrarFullCalendario = () => {
  emits('close')
}

const crearRutinaPersonalizada = async (rutina: IRutinaPersonalizada) => {
  isOpenCrearSesion.value = false
  rutina.id_entrenador = props.identrenador || ''
  rutina.id_deportista = props.iddeportista
  rutina.fecha = fechaSeleccionada.value

  const id = await CREAR_RUTINA_PERSONALIZADA(rutina)

  selectInfoSelect.value?.view.calendar.addEvent({
    id: id,
    title: rutina.descripcion,
    start: selectInfoSelect.value?.start.toISOString().replace(/T.*$/, ''),
  })
  listarRutinas()
}

const actualizarRutinaPersonalizada = async (rutina: IRutinaPersonalizada) => {
  await ACTUALIZAR_RUTINA_PERSONALIZADA(rutina.id, rutina)
  isOpenCrearSesion.value = false
  await listarRutinas()
}

const actualizarComentarios = async (rutina: IRutinaPersonalizada) => {
  await ACTUALIZAR_RUTINA_PERSONALIZADA(rutina.id, rutina)
}

const eliminarRutinaPersonalizada = async (idRutina: string) => {
  await ELIMINAR_RUTINA_PERSONALIZADA(idRutina)
  isOpenCrearSesion.value = false
  selectInfoEdit.value?.event.remove()
  await listarRutinas()
}

const calendarOptions = reactive<CalendarOptions>({
  plugins: [dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin],
  initialView: 'dayGridMonth',
  headerToolbar: {
    left: 'prev,next today',
    center: 'title',
    right: 'dayGridMonth,timeGridWeek,timeGridDay',
  },
  initialEvents: await listarRutinasInitial(),
  eventClick: abrirMenuEditarRutina,
  editable: true,
  selectable: true,
  selectMirror: false,
  dayMaxEvents: true,
  weekends: true,
  select: abrirMenuNuevaRutina,
  eventStartEditable: false,
  eventDurationEditable: false,
})
</script>

<template>
  <div>
    <FullCalendar :options="calendarOptions" />
    <SesionRutinaPersonalizada
      v-if="isOpenCrearSesion"
      :opcionactual="opcionactual"
      :rutinaanterior="rutinaSelect"
      :is-open="isOpenCrearSesion"
      @close="isOpenCrearSesion = false"
      @crear-rutina="crearRutinaPersonalizada"
      @actualizar-rutina="actualizarRutinaPersonalizada"
      @actualizar-comentarios="actualizarComentarios"
      @eliminar-rutina="eliminarRutinaPersonalizada"
    />
    <VButton raised @click="cerrarFullCalendario">Cerrar</VButton>
  </div>
</template>
