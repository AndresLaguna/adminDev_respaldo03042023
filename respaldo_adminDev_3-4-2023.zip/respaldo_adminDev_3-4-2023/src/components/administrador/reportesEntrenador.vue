/* stylelint-disable annotation-no-unknown */
<template>
  <div class="row">
    <div class="col-lg-8 offset-lg-2">
      <div class="table-responsive">
        <DataTable
          class="table table-striped table-bordered display"
          :options="{
            responsive: true,
            autoWidth: false,
            dom: 'Bfrtip',
            language: {
              search: 'Buscar',
              zeroRecords: 'No hay registros para mostrar',
              info: 'Mostrando del _START_ a _END_ de _TOTAL_ Registros.',
              infoFiltered: '(Filtrados de _MAX_ registros.)',
              paginate: {
                first: 'Primero',
                previous: 'Anterior',
                next: 'siguiente',
                last: 'Ultimo',
              },
            },
            buttons: botones,
          }"
        >
          <thead>
            <tr>
              <th>UserID</th>
              <th>Identificacion</th>
              <th>Nombres</th>
              <th>Apellidos</th>
              <th>ciudadActual</th>
              <th>fecha_nacimiento</th>
              <th>deporte</th>
              <th>telefono</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(entrenador, index) in entrenadores" :key="index">
              <th>
                {{ entrenador.UserID }}
              </th>
              <th>
                {{ entrenador.identificacion }}
              </th>
              <th>
                {{ entrenador.nombres }}
              </th>
              <th>
                {{ entrenador.apellidos }}
              </th>
              <th>
                {{ entrenador.nameUser }}
              </th>
              <th>
                {{ entrenador.fecha_nacimiento }}
              </th>
              <th>
                {{ entrenador.deporte }}
              </th>
              <th>
                {{ entrenador.telefono }}
              </th>
            </tr>
          </tbody>
        </DataTable>
      </div>
    </div>
  </div>
</template>

<script setup>
import { administracionStore } from '../../stores/administracionStore'
import { LISTARTODOSLOSENTRENADORES } from '../../services/administracion'
import { storeToRefs } from 'pinia'
import { onMounted } from 'vue'

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import axios from 'axios'
import DataTable from 'datatables.net-vue3'
import DataTableLib from 'datatables.net-bs5'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import Buttons from 'datatables.net-buttons-bs5'
import ButtonsHtml5 from 'datatables.net-buttons/js/buttons.html5'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import print from 'datatables.net-buttons/js/buttons.print'
import pdfmake from 'pdfmake'
//import pdfFonts from 'pdfmake/build/vfs_fonts'
//pdfmake.vfs = pdfFonts.pdfMake.vfs
import 'datatables.net-responsive-bs5'
import JsZip from 'jszip'
window.JSZip = JsZip
DataTable.use(DataTableLib)
DataTable.use(pdfmake)
DataTable.use(ButtonsHtml5)

const { entrenadores } = storeToRefs(administracionStore())
onMounted(async () => {
  await LISTARTODOSLOSENTRENADORES()
  console.log(entrenadores.value)
})

const botones = [
  {
    title: 'Reporte de Entrenadores',
    extend: 'excelHtml5',
    text: '<span class="icon"><i class="iconify" data-icon="fa-file-excel-o" aria-hidden="true"></i></span><span>Excel</span>',
    className: 'button is-success is-outlined',
  },
  {
    title: 'Reporte de Entrenadores',
    extend: 'pdfHtml5',
    text: '<span class="icon" ><i class="iconify" data-icon="fa-file-pdf-o" aria-hidden="true"></i></span><span>PDF</span>',
    className: 'button is-danger is-outlined',
  },
  {
    title: 'Reporte de Entrenadores',
    extend: 'print',
    text: '<span class="icon"><i class="iconify" data-icon="feather:printer" aria-hidden="true"></i></span><span>Imprimir</span>',
    className: 'button is-primary is-dark is-outlined',
  },
  {
    title: 'Reporte de Entrenadores',
    extend: 'copy',
    text: '<span class="icon"><i class="iconify" data-icon="fa-copy" aria-hidden="true"></i></span><span>Copiar</span>',
    className: 'button is-warning is-dark is-outlined',
  },
]
</script>

<style lang="scss">
@import 'datatables.net-bs5';
</style>>

