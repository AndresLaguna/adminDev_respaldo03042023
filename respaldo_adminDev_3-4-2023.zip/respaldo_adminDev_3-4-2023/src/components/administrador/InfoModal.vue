<script setup lang="ts">
import { ref, onMounted } from 'vue'

import { LISTARTODOSLOSENTRENADORES } from '../../services/administracion'

const centeredActionsOpen = ref(false)
const nombres = ref('')
const apellidos = ref('')
const docId = ref('')
const genero = ref('')
const pais = ref('')
const ciudad = ref('')
const usuario = ref('')
const correo = ref('')
const telefono = ref('')
const fecha_nacimiento = ref('')

const props = defineProps({
  data: {
    type: Object,
    required: true,
  },
})

onMounted(async () => {
  await LISTARTODOSLOSENTRENADORES()
  nombres.value = props.data.nombres
  apellidos.value = props.data.apellidos
  docId.value = props.data.identificacion
  genero.value = props.data.genero
  pais.value = props.data.pais
  ciudad.value = props.data.ciudad
  usuario.value = props.data.nombre_usuario
  correo.value = props.data.email
  telefono.value = props.data.telefono
  fecha_nacimiento.value = props.data.fecha_nacimiento
})
const closeModal = () => {
  centeredActionsOpen.value = false
}
const mostrarInfo = () => {
  centeredActionsOpen.value = true
}
</script>

<template>
  <VIconBox size="medium" color="primary" rounded :bordered="true" @click="mostrarInfo">
    <i class="iconify" data-icon="feather:user"></i>
  </VIconBox>
  <VModal
    :open="centeredActionsOpen"
    title="Perfil Entrenador"
    actions="center"
    size="medium"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <div class="account-box is-form is-footerless">
        <div class="form-head stuck-header">
          <div class="form-head-inner">
            <div class="left">
              <h3>Información General</h3>
            </div>
          </div>
        </div>
        <form action="signup-form">
          <div class="form-body">
            <!--Fieldset-->
            <div class="fieldset">
              <div class="fieldset-heading">
                <h4>
                  Foto de perfil
                  <span
                    v-tooltip.primary.bubble="'Maximo 2MB, formato jpg, png'"
                    onclick=""
                    color="solid"
                    label="Bubble"
                  >
                    <i
                      class="iconify"
                      data-icon="feather:help-circle"
                      aria-hidden="true"
                    ></i>
                  </span>
                </h4>
                <p>La foto de perfil ayuda a que otras personas te reconozcan</p>
              </div>
              <div class="picture-selector">
                <div class="image-container">
                  <VAvatar size="large" :picture="props.data.foto_url" />
                </div>
              </div>
            </div>
            <!--Fieldset-->
            <div class="fieldset">
              <div class="fieldset-heading">
                <h4>Información Personal</h4>
                <p>Otras personas quieren conocerte más</p>
              </div>

              <div class="columns is-multiline">
                <!--Nombres-->
                <div class="column is-6">
                  <VField id="nombres">
                    <VLabel raw class="auth-label"> Nombres </VLabel>
                    <VControl icon="feather:user">
                      <VInput
                        v-model="nombres"
                        readonly
                        type="text"
                        autocomplete="given-name"
                      />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>

                <!--Apellidos-->
                <div class="column is-6">
                  <VField id="apellidos">
                    <VLabel raw class="auth-label"> Apellidos </VLabel>
                    <VControl icon="feather:user">
                      <VInput
                        v-model="apellidos"
                        type="text"
                        readonly
                        autocomplete="family-name"
                      />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>

                <!--Documento Identificacion-->
                <div class="column is-6">
                  <VField id="identificacion">
                    <VLabel raw class="auth-label"
                      >Documento de identificación
                      <span
                        v-tooltip.primary.bubble="'Para posible facturación'"
                        color="solid"
                        label="Bubble"
                      >
                        <i
                          class="iconify"
                          data-icon="feather:help-circle"
                          aria-hidden="true"
                        ></i> </span
                    ></VLabel>
                    <VControl icon="feather:briefcase">
                      <VInput v-model="docId" type="text" readonly autocomplete="off" />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>

                <!-- Genero  -->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label"> Genero </VLabel>
                    <VControl>
                      <VInput v-model="genero" type="text" readonly />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>

                <!-- Field  -->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label"> Pais </VLabel>
                    <VControl>
                      <VInput v-model="pais" type="text" readonly />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>
                <!-- Field  -->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label"> Ciudad </VLabel>
                    <VControl>
                      <VInput v-model="ciudad" type="text" readonly />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>

                <!--Field-->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label"
                      >Usuario
                      <span
                        v-tooltip.primary.bubble="'Apodo (No es obligatorio)'"
                        color="solid"
                        label="Bubble"
                      >
                        <i
                          class="iconify"
                          data-icon="feather:help-circle"
                          aria-hidden="true"
                        ></i> </span
                    ></VLabel>
                    <VControl icon="feather:user">
                      <VInput v-model="usuario" type="text" readonly />
                    </VControl>
                  </VField>
                </div>
                <!--Field-->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label">Correo </VLabel>
                    <VControl icon="feather:user">
                      <VInput
                        v-model="correo"
                        readonly
                        type="text"
                        autocomplete="correo"
                      />
                    </VControl>
                  </VField>
                </div>

                <!--Field-->
                <div class="column is-6">
                  <VField id="telefono">
                    <VLabel raw class="auth-label"
                      >Telefono
                      <span
                        v-tooltip.primary.bubble="
                          'Completa este campo con el número de cotacto'
                        "
                        color="solid"
                        label="Bubble"
                      >
                        <i
                          class="iconify"
                          data-icon="feather:help-circle"
                          aria-hidden="true"
                        ></i> </span
                    ></VLabel>
                    <VControl icon="feather:phone">
                      <VInput
                        v-model="telefono"
                        type="text"
                        readonly
                        autocomplete="off"
                      />
                      <p class="help is-danger"></p>
                    </VControl>
                  </VField>
                </div>
                <!--Field-->
                <div class="column is-6">
                  <VField>
                    <VLabel raw class="auth-label"
                      >Fecha de nacimiento
                      <span
                        v-tooltip.primary.bubble="
                          'Completa este campo con tu fecha de nacimiento'
                        "
                        color="solid"
                        label="Bubble"
                      >
                        <i
                          class="iconify"
                          data-icon="feather:help-circle"
                          aria-hidden="true"
                        ></i> </span
                    ></VLabel>
                    <VControl icon="feather:calendar">
                      <VField>
                        <VControl icon="feather:calendar">
                          <VInput v-model="fecha_nacimiento" readonly />
                        </VControl>
                      </VField>
                    </VControl>
                    <p class="help is-danger"></p>
                  </VField>
                </div>
              </div>
            </div>
          </div>
        </form>
        <!-- upload modal -->
      </div>
    </template>
    <template #action>
      <VButton color="primary" raised @click="closeModal">Confirm</VButton>
    </template>
  </VModal>
</template>
