<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { administracionStore } from '../../stores/administracionStore'
import { storeToRefs } from 'pinia'
import { LISTARDISTANCIAS, ACTUALIZAR_DISTANCIA } from '../../services/administracion'
import { useNotyf } from '/@src/composable/useNotyf'

const centeredActionsOpen = ref(false)
const { distancias } = storeToRefs(administracionStore())
const notif = useNotyf()

const claveAModificar = ref('')
const nuevoValor = ref('')
const props = defineProps({
  data: {
    type: Object,
    required: true,
  },
})
onMounted(async () => {
  await LISTARDISTANCIAS()
})

const closeModal = () => {
  centeredActionsOpen.value = false
  claveAModificar.value = ''
  nuevoValor.value = ''
}

const mostrarInfo = () => {
  claveAModificar.value = props.data.index
  centeredActionsOpen.value = true
}

const handleSubmit = async () => {
  notif.dismissAll()

  if (nuevoValor.value) {
    const nuevoValorFloat = parseFloat(nuevoValor.value)
    if (!isNaN(nuevoValorFloat)) {
      distancias.value[claveAModificar.value] = nuevoValorFloat
      await ACTUALIZAR_DISTANCIA(distancias.value)
      notif.success('Distancia actualizada con éxito')
    } else {
      notif.error('El valor no es un número flotante')
    }
  } else {
    notif.error('Los campos están vacíos')
  }

  closeModal()
}
</script>

<template>
  <VButton color="primary" :bold="true" @click="mostrarInfo">Actualizar</VButton>
  <VModal
    :open="centeredActionsOpen"
    :title="`Se modificara a : ${props.data.index}`"
    noscroll
    actions="center"
    size="small"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <form class="modal-form">
        <div class="field">
          <div class="control1">
            <label>Nuevo valor</label>
            <input
              v-model="nuevoValor"
              type="text"
              class="input"
              placeholder="Digite nuevo valor"
            />
          </div>
        </div>
      </form>
    </template>
    <template #action>
      <VButton color="primary" raised @click="handleSubmit">Confirm</VButton>
    </template>
  </VModal>
</template>
