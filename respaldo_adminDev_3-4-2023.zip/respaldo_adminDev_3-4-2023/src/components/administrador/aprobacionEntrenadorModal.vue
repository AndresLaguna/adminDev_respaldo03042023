<!-- eslint-disable vue/no-parsing-error -->
<script setup lang="ts">
import { ref, onMounted } from 'vue'

import {
  LISTARTODOSLOSENTRENADORES,
  CAMBIARESTADOENTRENADOR,
} from '../../services/administracion'

const centeredActionsOpen = ref(false)
const opcionDeporte = ref('')
const descripcion = ref('')
const calificacion = ref('')
onMounted(async () => {
  await LISTARTODOSLOSENTRENADORES()
  descripcion.value = props.data.descripcion
  opcionDeporte.value = props.data.categoria
  calificacion.value = props.data.estrellas
})

const props = defineProps({
  data: {
    type: Object,
    required: true,
  },
})
const mostrarInfo = () => {
  centeredActionsOpen.value = true
}
const cambiarEstadoEntrenador = (id: any, estado: any) => {
  CAMBIARESTADOENTRENADOR(
    id,
    estado === 'Aprobado' ? 'Pendiente' : 'Aprobado',
    descripcion.value,
    opcionDeporte.value,
    calificacion.value
  )
  centeredActionsOpen.value = false
}
</script>
<template>
  <VIconBox
    v-if="props.data.estado === 'Aprobado'"
    size="medium"
    color="green"
    rounded
    :bordered="true"
    @click="mostrarInfo"
  >
    <i class="iconify" :data-icon="'feather:check'"></i>
  </VIconBox>
  <VIconBox
    v-else
    size="medium"
    color="danger"
    rounded
    :bordered="true"
    @click="mostrarInfo"
  >
    <i class="iconify" :data-icon="'feather:x'"></i>
  </VIconBox>
  <VModal
    :open="centeredActionsOpen"
    title="Aprobar perfil deportista"
    actions="center"
    size="medium"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <h1>Userid: {{ props.data.UserID }}</h1>
      <br />
      <div class="imagen1 column is-4">
        <img
          class="light-image-l hero-mockup"
          src="/@src/assets/illustrations/landing/app-2.png"
          alt=""
        />
      </div>
      <h2>
        Con el fin de filtrar los entrenadores segun los objetivos de los deportistas.
      </h2>
      <h2>Seleccione Categoria!</h2>
      <VControl class="has-icons-left" icon="feather:globe">
        <VSelect v-model="opcionDeporte">
          <VOption> Deporte </VOption>
          <VOption> Gimnasio </VOption>
          <VOption> Vida Activa </VOption>
        </VSelect>
      </VControl>
      <form class="modal-form">
        <div class="field">
          <label>Descripcion</label>
          <div class="control">
            <input v-model="descripcion" type="text" class="input" />
          </div>
        </div>
        <div class="field">
          <label>Calificacion</label>
          <div class="control">
            <input
              v-model="calificacion"
              type="number"
              class="input"
              max="5"
              min="0"
              step="1"
            />
          </div>
        </div>
      </form>
    </template>
    <template #action>
      <VButton
        color="primary"
        raised
        @click="cambiarEstadoEntrenador(props.data.id, props.data.estado)"
        >Confirm</VButton
      >
    </template>
  </VModal>
</template>

