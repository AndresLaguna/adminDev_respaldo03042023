<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { administracionStore } from '../../stores/administracionStore'
import { storeToRefs } from 'pinia'
import {
  LISTARCIUDADES,
  ACTUALIZAR_CIUDAD,
  LISTARTODOSLOSUSUARIOS,
} from '../../services/administracion'
import { useNotyf } from '/@src/composable/useNotyf'

const centeredActionsOpen = ref(false)
const { ciudadaModificar, ciudades, usuarios } = storeToRefs(administracionStore())
const notif = useNotyf()

const props = defineProps({
  data: {
    type: Object,
    required: true,
  },
})

onMounted(async () => {
  await LISTARCIUDADES(props.data.pais)
  await LISTARTODOSLOSUSUARIOS()
})
const closeModal = () => {
  centeredActionsOpen.value = false
  ciudadaModificar.value = ''
}
const mostrarInfo = () => {
  centeredActionsOpen.value = true
}
const handleSubmit = () => {
  notif.dismissAll()
  const ciudadesArray = usuarios.value
  let flag = true
  ciudadesArray.forEach((element: any) => {
    if (element.ciudad == props.data.ciudad && element.pais == props.data.pais) {
      notif.error(
        'la ciudad no se puede actualizar debido a una dependencia con los usuarios'
      )
      flag = false
    }
  })
  if (flag) {
    const index = ciudades.value.indexOf(props.data.ciudad)
    if (index !== -1) {
      ciudades.value.splice(index, 1, ciudadaModificar.value)
      ACTUALIZAR_CIUDAD(props.data.pais, ciudades.value)
      notif.success('la ciudad se actualizo satisfactoriamente')
    } else {
      notif.warning('la ciudad no se pudo actualizar')
    }
  }
  closeModal()
}
</script>

<template>
  <VButton color="warning" :bold="true" @click="mostrarInfo">Actualizar</VButton>
  <VModal
    :open="centeredActionsOpen"
    title="Ciudad"
    noscroll
    actions="center"
    size="small"
    @close="centeredActionsOpen = false"
  >
    <template #content>
      <form class="modal-form" @submit.prevent="handleSubmit">
        <div class="field">
          <div class="control1">
            <label>Nombre a actualizar </label>
            <input
              id="ciudadActualizar"
              v-model="ciudadaModificar"
              type="text"
              class="input"
              placeholder="Digite nombre"
            />
          </div>
        </div>
      </form>
    </template>
    <template #action>
      <VButton color="primary" raised @click="handleSubmit">Confirm</VButton>
    </template>
  </VModal>
</template>


