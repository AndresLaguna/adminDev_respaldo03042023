<script setup lang="ts">
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const emit = defineEmits(['close'])
</script>

<template>
  <div class="sidebar-panel is-generic">
    <div class="subpanel-header">
      <h3 class="no-mb">Deportistas</h3>
      <div
        class="panel-close"
        tabindex="0"
        @keydown.space.prevent="emit('close')"
        @click="emit('close')"
      >
        <i aria-hidden="true" class="iconify" data-icon="feather:x"></i>
      </div>
    </div>
    <div class="inner" data-simplebar>
      <ul>
        <VCollapseLinks>
          <template #header>
            Solicitudes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>

          <RouterLink
            :to="{ name: 'entrenador-deportistas-solicitudes' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Solicitudes Pendientes</span>
          </RouterLink>
          <RouterLink
            :to="{ name: 'entrenador-deportistas-aprobados' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Deportistas Aprobados</span>
          </RouterLink>
        </VCollapseLinks>
        <VCollapseLinks>
          <template #header>
            Planes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>

          <RouterLink
            :to="{ name: 'entrenador-rutinas-crear-plan-gratuito' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Crear Plan Gratuito</span>
          </RouterLink>
          <RouterLink
            :to="{ name: 'entrenador-rutinas-ver-planes-gratuitos' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Ver Planes Gratuitos</span>
          </RouterLink>
          <RouterLink
            v-if="userSession.userEspecial === 'SuperEntrenador'"
            :to="{ name: 'entrenador-rutinas-crear-semana-comodin' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Crear Semana comodín</span>
          </RouterLink>
          <RouterLink
            v-if="userSession.userEspecial === 'SuperEntrenador'"
            :to="{ name: 'entrenador-rutinas-ver-semanas-comodin' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Ver Semanas comodín</span>
          </RouterLink>
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/layout/sidebar-panel';
</style>
