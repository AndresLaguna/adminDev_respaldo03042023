<script setup lang="ts">
import { onValue, ref as reff } from '@firebase/database'
import { onBeforeMount, ref } from 'vue'
import { database } from '/@src/services/config'
import { useUserSession } from '/@src/stores/userSession'
import { defineEmits } from 'vue'

const userSession = useUserSession()
const bienvenida = ref(7)
const emit = defineEmits(['close'])

onBeforeMount(async () => {
  onValue(reff(database, 'users/' + userSession.userId + '/bienvenida'), (snapshot) => {
    if (snapshot.exists()) {
      bienvenida.value = snapshot.val()
    }
  })
})
</script>
<template>
  <div class="sidebar-panel is-generic">
    <div class="subpanel-header">
      <h3 class="no-mb">Menú</h3>
      <div
        class="panel-close"
        tabindex="0"
        @keydown.space.prevent="emit('close')"
        @click="emit('close')"
      >
        <i aria-hidden="true" class="iconify" data-icon="feather:x"></i>
      </div>
    </div>
    <div class="inner" data-simplebar>
      <ul>
        <VCollapseLinks>
          <template #header>
            Administración
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Personales -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'administrador-adminPerfil-administracionEntrenadores' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Entrenadores</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Entrenadores
          </span>
          <!-- Usuarrio -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'administrador-adminPerfil-administracionCiudades' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-flag"></i>
            <span>Ciudades</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Usuario
          </span>
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'administrador-adminDistancias' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-target"></i>
            <span>Distancias</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Distancias
          </span>
        </VCollapseLinks>
        <li class="divider"></li>
        <VCollapseLinks>
          <template #header>
            Reportes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Personales -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'administrador-adminReportes' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Reporte de Entrenadores</span>
          </RouterLink>
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/layout/sidebar-panel';
</style>
