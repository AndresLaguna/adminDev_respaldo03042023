<script setup lang="ts">
import { onValue, ref as reff } from '@firebase/database'
import { onBeforeMount, ref } from 'vue'
import { database } from '/@src/services/config'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const bienvenida = ref(7)
onBeforeMount(async () => {
  onValue(reff(database, 'users/' + userSession.userId + '/bienvenida'), (snapshot) => {
    if (snapshot.exists()) {
      bienvenida.value = snapshot.val()
    }
  })
})
</script>
<template>
  <div class="sidebar-panel is-generic">
    <div class="subpanel-header">
      <h3 class="no-mb">Menú</h3>
      <div
        class="panel-close"
        tabindex="0"
        @keydown.space.prevent="emit('close')"
        @click="emit('close')"
      >
        <i aria-hidden="true" class="iconify" data-icon="feather:x"></i>
      </div>
    </div>
    <div class="inner" data-simplebar>
      <ul>
        <VCollapseLinks>
          <template #header>
            Mis datos
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Personales -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-misDatos-misDatosEdit-personalesEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Personales</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Personales
          </span>
          <!-- Usuarrio -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-misDatos-misDatosEdit-usuarioEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Usuario</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Usuario
          </span>
          <!-- Contacto -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-misDatos-misDatosEdit-contactoEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Contacto</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            Usuario
          </span>
        </VCollapseLinks>
        <li class="divider"></li>
        <!-- <li>
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-profile-contactoEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Contacto</span>
          </RouterLink>
        </li> -->
        <VCollapseLinks>
          <template #header>
            Perfil
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Morfología -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-morfologicoEdit' }"
            class="is-submenu"
          >
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            <span>Morfología</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            Morfología
          </span>
          <!-- Capacidad Fisica -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-capacidadEdit' }"
            class="is-submenu"
          >
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            <span>Capacidad Física</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            Capacidad Física
          </span>
          <!-- Rendimiento -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-rendimientoEdit' }"
            class="is-submenu"
          >
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            <span>Rendimiento</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i class="lnil lnil-ruler" aria-hidden="true"></i>
            Rendimiento
          </span>
          <!-- Deportivo -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-deportivoEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Deportivo</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Deportivo
          </span>
          <!-- Salud -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-saludEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Salud</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Salud
          </span>
          <!-- Objetivos -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-perfil-perfilEdit-objetivosEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Objetivos</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Objetivos
          </span>
        </VCollapseLinks>

        <li class="divider"></li>

        <VCollapseLinks>
          <template #header>
            Planes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Suscripción -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-planes-planesEdit-suscripcionEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Suscripción</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Suscripción
          </span>
          <!-- Facturación -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-planes-planesEdit-facturacionEdit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Facturación</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Facturación
          </span>
        </VCollapseLinks>

        <li class="divider"></li>

        <VCollapseLinks>
          <template #header>
            Entrenamiento
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Tu Entrenador -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-entrenamiento-miEntrenamiento-tuEntrenador' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Tu Entrenador</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Tu Entrenador
          </span>
          <!-- Entrenadores -->
          <span v-if="bienvenida == 0" class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Entrenadores
          </span>
          <!-- Rutinas -->
          <span v-if="bienvenida == 0" class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Rutinas
          </span>
          <!-- Explorar -->
          <span v-if="bienvenida == 0" class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Explorar
          </span>
          <!-- Sugerencias -->
          <span v-if="bienvenida == 0" class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Sugerencias
          </span>
        </VCollapseLinks>

        <li class="divider"></li>

        <VCollapseLinks>
          <template #header>
            Configuración
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Conexión -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-configuracion-configuracionEdit-showConexion' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Conexión</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Conexión
          </span>
          <!-- Ayuda -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-configuracion-configuracionEdit-showAyuda' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Ayuda</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Ayuda
          </span>
          <!-- Acerca de -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-configuracion-configuracionEdit-showAcerca' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            <span>Acerca de</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-bi-cycle"></i>
            Acerca de
          </span>
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/layout/sidebar-panel';
</style>
