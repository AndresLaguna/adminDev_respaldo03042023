<script setup lang="ts">
import { onValue, ref as reff } from '@firebase/database'
import { onBeforeMount, ref } from 'vue'
import { database } from '/@src/services/config'
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
const bienvenida = ref(7)
onBeforeMount(async () => {
  onValue(reff(database, 'users/' + userSession.userId + '/bienvenida'), (snapshot) => {
    if (snapshot.exists()) {
      bienvenida.value = snapshot.val()
    }
  })
})
</script>
<template>
  <div class="sidebar-panel is-generic">
    <div class="subpanel-header">
      <h3 class="no-mb">Menú Rutina</h3>
      <div
        class="panel-close"
        tabindex="0"
        @keydown.space.prevent="emit('close')"
        @click="emit('close')"
      >
        <i aria-hidden="true" class="iconify" data-icon="feather:x"></i>
      </div>
    </div>
    <div class="inner" data-simplebar>
      <ul>
        <!-- Rutina -->
        <VCollapseLinks>
          <template #header>
            Rutina
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>
          <!-- Ver Rutinas -->
          <RouterLink
            v-if="bienvenida == 0"
            :to="{ name: 'deportista-rutinas' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Ver Rutina</span>
          </RouterLink>
          <span v-else class="is-submenu" style="color: red">
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Ver Rutina</span>
          </span>
          <!-- <RouterLink :to="{ name: 'deportista' }" class="is-submenu">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Analisis</span>
          </RouterLink>
          <RouterLink :to="{ name: 'deportista' }" class="is-submenu">
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Estadisticas</span>
          </RouterLink> -->
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>

<style lang="scss">
@import '/@src/scss/layout/sidebar-panel';
</style>
