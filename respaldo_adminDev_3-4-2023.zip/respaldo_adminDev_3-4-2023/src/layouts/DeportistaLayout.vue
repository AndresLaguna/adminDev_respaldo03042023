<script setup lang="ts">
import { ref, watchPostEffect, watch } from 'vue'
import { useRoute } from 'vue-router'

import type { SidebarTheme } from '/@src/components/navigation/desktop/Sidebar.vue'
import { useViewWrapper } from '/@src/stores/viewWrapper'

const props = withDefaults(
  defineProps<{
    theme?: SidebarTheme
    defaultSidebar?: string
    closeOnChange?: boolean
    openOnMounted?: boolean
    nowrap?: boolean
  }>(),
  {
    defaultSidebar: 'dashboard',
    theme: 'default',
  }
)

const viewWrapper = useViewWrapper()
const route = useRoute()
const isMobileSidebarOpen = ref(false)
const isDesktopSidebarOpen = ref(props.openOnMounted)
const activeMobileSubsidebar = ref(props.defaultSidebar)

function switchSidebar(id: string) {
  if (id === activeMobileSubsidebar.value) {
    isDesktopSidebarOpen.value = !isDesktopSidebarOpen.value
  } else {
    isDesktopSidebarOpen.value = true
    activeMobileSubsidebar.value = id
  }
}

/**
 * watchPostEffect callback will be executed each time dependent reactive values has changed
 */
watchPostEffect(() => {
  viewWrapper.setPushed(isDesktopSidebarOpen.value ?? false)
})
watch(
  () => route.fullPath,
  () => {
    isMobileSidebarOpen.value = false

    if (props.closeOnChange && isDesktopSidebarOpen.value) {
      isDesktopSidebarOpen.value = false
    }
  }
)
</script>

<template>
  <div class="sidebar-layout">
    <div class="app-overlay"></div>

    <!-- Mobile navigation -->
    <DMobileNavbar
      :is-open="isMobileSidebarOpen"
      @toggle="isMobileSidebarOpen = !isMobileSidebarOpen"
    >
      <template #brand>
        <RouterLink :to="{ name: 'index' }" class="navbar-item is-brand">
          <AnimatedLogo width="38px" height="38px" />
        </RouterLink>

        <div class="brand-end">
          <NotificationsMobileDropdown />
          <UserProfileDropdown />
        </div>
      </template>
    </DMobileNavbar>

    <!-- Mobile sidebar links -->
    <DMobileSidebar
      :is-open="isMobileSidebarOpen"
      @toggle="isMobileSidebarOpen = !isMobileSidebarOpen"
    >
      <template #links>
        <!-- Perfil -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'dashboard' && 'is-active']"
            aria-label="Display dashboard content"
            tabindex="0"
            @keydown.space.prevent="activeMobileSubsidebar = 'dashboard'"
            @click="activeMobileSubsidebar = 'dashboard'"
          >
            <i aria-hidden="true" class="iconify" data-icon="feather:user"></i>
          </a>
        </li>
        <!-- Suscription -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'suscription' && 'is-active']"
            aria-label="Display dashboard content"
            tabindex="0"
            @keydown.space.prevent="activeMobileSubsidebar = 'suscription'"
            @click="activeMobileSubsidebar = 'suscription'"
          >
            <i aria-hidden="true" class="iconify" data-icon="feather:search"></i>
          </a>
        </li>
        <!-- Rutina -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'rutina' && 'is-active']"
            aria-label="Display dashboard content"
            tabindex="0"
            @keydown.space.prevent="activeMobileSubsidebar = 'rutina'"
            @click="activeMobileSubsidebar = 'rutina'"
          >
            <i aria-hidden="true" class="iconify" data-icon="feather:clock"></i>
          </a>
        </li>
      </template>

      <!-- <template #bottom-links>
        <li>
          <a href="#">
            <i aria-hidden="true" class="iconify" data-icon="feather:settings"></i>
          </a>
        </li>
      </template> -->
    </DMobileSidebar>

    <!-- Mobile subsidebar links -->
    <Transition name="slide-x">
      <KeepAlive>
        <DDashMobileSubsidebar
          v-if="isMobileSidebarOpen && activeMobileSubsidebar === 'dashboard'"
        />
        <DDashMobileSuscription
          v-else-if="isMobileSidebarOpen && activeMobileSubsidebar === 'suscription'"
        />
        <DDashMobileRutina
          v-else-if="isMobileSidebarOpen && activeMobileSubsidebar === 'rutina'"
        />
      </KeepAlive>
    </Transition>

    <!-- Desktop navigation -->
    <CircularMenu />

    <Sidebar :theme="props.theme" :is-open="isDesktopSidebarOpen">
      <template #links>
        <!-- Dashboards -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'dashboard' && 'is-active']"
            data-content="Dashboards"
            tabindex="0"
            @keydown.space.prevent="switchSidebar('dashboard')"
            @click="switchSidebar('dashboard')"
          >
            <i
              aria-hidden="true"
              class="iconify sidebar-svg"
              data-icon="feather:user"
            ></i>
          </a>
        </li>
        <!-- Suscription -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'suscription' && 'is-active']"
            data-content="Suscription"
            tabindex="0"
            @keydown.space.prevent="switchSidebar('suscription')"
            @click="switchSidebar('suscription')"
          >
            <i
              aria-hidden="true"
              class="iconify sidebar-svg"
              data-icon="feather:search"
            ></i>
          </a>
        </li>
        <!-- Rutina -->
        <li>
          <a
            :class="[activeMobileSubsidebar === 'rutina' && 'is-active']"
            data-content="Suscription"
            tabindex="0"
            @keydown.space.prevent="switchSidebar('rutina')"
            @click="switchSidebar('rutina')"
          >
            <i
              aria-hidden="true"
              class="iconify sidebar-svg"
              data-icon="feather:clock"
            ></i>
          </a>
        </li>
      </template>
      <template #bottom-links>
        <!-- Profile Dropdown -->
        <li>
          <UserProfileDropdown up />
        </li>
      </template>
    </Sidebar>

    <Transition name="slide-x">
      <KeepAlive>
        <DDashSubsidebar
          v-if="isDesktopSidebarOpen && activeMobileSubsidebar === 'dashboard'"
          @close="isDesktopSidebarOpen = false"
        />
        <DDashSuscription
          v-else-if="isDesktopSidebarOpen && activeMobileSubsidebar === 'suscription'"
          @close="isDesktopSidebarOpen = false"
        />
        <DDashRutina
          v-else-if="isDesktopSidebarOpen && activeMobileSubsidebar === 'rutina'"
          @close="isDesktopSidebarOpen = false"
        />
      </KeepAlive>
    </Transition>

    <!-- <LanguagesPanel /> -->

    <VViewWrapper>
      <VPageContentWrapper>
        <template v-if="props.nowrap">
          <slot></slot>
        </template>
        <VPageContent v-else class="is-relative">
          <div class="page-title has-text-centered">
            <!-- Sidebar Trigger -->
            <div
              class="vuero-hamburger nav-trigger push-resize"
              tabindex="0"
              @keydown.space.prevent="isDesktopSidebarOpen = !isDesktopSidebarOpen"
              @click="isDesktopSidebarOpen = !isDesktopSidebarOpen"
            >
              <span class="menu-toggle has-chevron">
                <span :class="[isDesktopSidebarOpen && 'active']" class="icon-box-toggle">
                  <span class="rotate">
                    <i aria-hidden="true" class="icon-line-top"></i>
                    <i aria-hidden="true" class="icon-line-center"></i>
                    <i aria-hidden="true" class="icon-line-bottom"></i>
                  </span>
                </span>
              </span>
            </div>

            <div class="title-wrap">
              <h1 class="title is-4">{{ viewWrapper.pageTitle }}</h1>
            </div>

            <Toolbar class="desktop-toolbar" />
          </div>

          <slot></slot>
        </VPageContent>
      </VPageContentWrapper>
    </VViewWrapper>
  </div>
</template>
