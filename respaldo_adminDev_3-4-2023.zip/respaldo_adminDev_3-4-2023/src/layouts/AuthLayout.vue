<template>
  <div class="auth-wrapper">
    <slot></slot>
  </div>
</template>
