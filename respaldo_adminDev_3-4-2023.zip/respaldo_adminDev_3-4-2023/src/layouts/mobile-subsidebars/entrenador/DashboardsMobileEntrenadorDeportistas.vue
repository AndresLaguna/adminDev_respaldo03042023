<script setup lang="ts">
import { useUserSession } from '/@src/stores/userSession'

const userSession = useUserSession()
</script>

<template>
  <div class="mobile-subsidebar">
    <div class="inner">
      <div class="sidebar-title">
        <h3>Deportistas</h3>
      </div>

      <ul class="submenu" data-simplebar>
        <VCollapseLinks>
          <template #header>
            Solicitudes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>

          <RouterLink
            :to="{ name: 'entrenador-deportistas-solicitudes' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Solicitudes Pendientes</span>
          </RouterLink>
          <RouterLink
            :to="{ name: 'entrenador-deportistas-aprobados' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Deportistas Aprobados</span>
          </RouterLink>
        </VCollapseLinks>

        <VCollapseLinks>
          <template #header>
            Planes
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>

          <RouterLink
            :to="{ name: 'entrenador-rutinas-crear-plan-gratuito' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-home"></i>
            <span>Crear Plan Gratuito</span>
          </RouterLink>
          <RouterLink
            :to="{ name: 'entrenador-rutinas-ver-planes-gratuitos' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Ver Planes Gratuitos</span>
          </RouterLink>
          <RouterLink
            v-if="userSession.userEspecial === 'SuperEntrenador'"
            :to="{ name: 'entrenador-rutinas-ver-planes-gratuitos' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Crear Semana comodín</span>
          </RouterLink>
          <RouterLink
            v-if="userSession.userEspecial === 'SuperEntrenador'"
            :to="{ name: 'entrenador-rutinas-ver-planes-gratuitos' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Ver Semana comodín</span>
          </RouterLink>
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>
