<template>
  <div class="mobile-subsidebar">
    <div class="inner">
      <div class="sidebar-title">
        <h3>Menu Principal</h3>
      </div>

      <ul class="submenu" data-simplebar>
        <VCollapseLinks>
          <template #header>
            Personal
            <i aria-hidden="true" class="iconify" data-icon="feather:chevron-right" />
          </template>

          <RouterLink
            :to="{ name: 'entrenador-profile-profile-edit' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Datos personales</span>
          </RouterLink>
          <RouterLink
            :to="{ name: 'entrenador-profile-profile-deporte' }"
            class="is-submenu"
          >
            <i aria-hidden="true" class="lnil lnil-user"></i>
            <span>Datos Deportivos</span>
          </RouterLink>
        </VCollapseLinks>
      </ul>
    </div>
  </div>
</template>
