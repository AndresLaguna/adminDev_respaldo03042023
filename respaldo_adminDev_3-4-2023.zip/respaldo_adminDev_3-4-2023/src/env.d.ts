/**
 * We can extends the env types here
 * @see https://vitejs.dev/guide/env-and-mode.html#env-files
 */

interface ImportMetaEnv extends Readonly<Record<string, string>> {
  readonly VITE_API_BASE_URL: string
  readonly VITE_MAPBOX_ACCESS_TOKEN: string
  readonly VITE_APP_API_KEY: string
  readonly VITE_APP_AUTH_DOMAIN: string
  readonly VITE_APP_DATABASE_URL: string
  readonly VITE_APP_PROJECT_ID: string
  readonly VITE_APP_STORAGE_BUCKET: string
  readonly VITE_APP_MESSAGING_SENDER_ID: string
  readonly VITE_APP_APP_ID: string
  readonly VITE_APP_MEASUREMENT_ID: string
  readonly VITE_APP_PROFILE_VIEW: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
