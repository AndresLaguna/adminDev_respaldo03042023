export const DEPORTES_DISPONIBLES = ['Atletismo', 'Ciclismo', 'Triatlon', 'Fuerza']

export const TIPO_BLOQUE = [
  'Calentamiento',
  'Ritmo',
  'Recuperación',
  'Enfriamiento',
  'Estiramiento',
]

export const TIPO_RANGO_BLOQUE = ['Kilometros', 'metros']

export const TIPO_MEDICION_RUTINA = ['Tiempo', 'Distancia']

export const INTENSIDAD_RUTINAS = [
  {
    nombre: 'Sensaciones',
    valuesEntrenador: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
    valuesDeportista: [
      'Nada',
      'Muy muy suave',
      'Muy suave',
      'Suave',
      'No tan suave',
      'Moderado',
      'No tan fuerte',
      'Medianamente fuerte',
      'Fuerte',
      'Muy fuerte',
      'Muy muy fuerte',
    ],
  },
  {
    nombre: 'Zonas FC',
    valuesEntrenador: ['Z1', 'Z2', 'Z3', 'Z4', 'Z5'],
    valuesDeportista: [
      'Aeróbico ligero',
      'Aeróbico medio',
      'Aeróbico intenso',
      'Umbral anaeróbico',
      'Máxima intensidad',
    ],
  },
  {
    nombre: 'Zona de Ritmos',
    valuesEntrenador: ['R0', 'R1', 'R2', 'R3', 'R3+', 'R4', 'R5', 'R6'],
    valuesDeportista: [
      'Regenerativo',
      'Umbral aeróbico',
      'Umbral anaeróbico',
      'Vo2 submaximo',
      'Vo2 maximo',
      'Capacidad aeróbica',
      'Potencia anaeróbica',
      'Potencia aláctica',
    ],
  },
]

export const GET_TIPOS_INTENSIDAD_RUTINAS = () => {
  return INTENSIDAD_RUTINAS.map((val) => val.nombre)
}

export const GET_OPCIONES_INSIDAD_RUTINA = (nombre: string) => {
  const result: any = {
    valuesEntrenador: [],
    valuesDeportista: [],
  }
  INTENSIDAD_RUTINAS.forEach((val) => {
    if (val.nombre === nombre) {
      result.valuesEntrenador = val.valuesEntrenador
      result.valuesDeportista = val.valuesDeportista
    }
  })
  return result
}
