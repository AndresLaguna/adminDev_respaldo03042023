export const CONVERT_SEMANA_RUTINA = (semanaRutina: any) => {
  const nuevaRutina: any = {}
  semanaRutina.forEach((semana: any, indexSemana: number) => {
    const nuevaSemana: any = {}
    semana.forEach((dia: any, indexDia: number) => {
      if (dia.length !== 0) {
        nuevaSemana['dia' + indexDia] = dia
      }
    })
    nuevaRutina['semana' + indexSemana] = nuevaSemana
  })
  return nuevaRutina
}

export const REVERT_SEMANA_RUTINA = (rutinaActual: any, semanaRutina: any) => {
  Object.keys(semanaRutina).forEach((keySemana) => {
    const semanaIndex = Number(keySemana.substring(keySemana.length - 1))
    Object.keys(semanaRutina[keySemana]).forEach((keyDia) => {
      const diaIndex = Number(keyDia.substring(keyDia.length - 1))
      rutinaActual[semanaIndex][diaIndex] = semanaRutina[keySemana][keyDia]
    })
  })
}

export const NEW_REVERT_SEMANA_RUTINA = (semanaRutina: any) => {
  const nuevaRutina: any[] = [
    [[], [], [], [], [], [], []],
    [[], [], [], [], [], [], []],
    [[], [], [], [], [], [], []],
    [[], [], [], [], [], [], []],
  ]
  Object.keys(semanaRutina).forEach((keySemana) => {
    const semanaIndex = Number(keySemana.substring(keySemana.length - 1))
    Object.keys(semanaRutina[keySemana]).forEach((keyDia) => {
      const diaIndex = Number(keyDia.substring(keyDia.length - 1))
      nuevaRutina[semanaIndex][diaIndex] = semanaRutina[keySemana][keyDia]
    })
  })

  return nuevaRutina
}

export const REVERT_SEMANA_COMODIN = (semanaRutina: any) => {
  const nuevaRutina: any[] = [[[], [], [], [], [], [], []]]
  Object.keys(semanaRutina).forEach((keySemana) => {
    const semanaIndex = Number(keySemana.substring(keySemana.length - 1))
    Object.keys(semanaRutina[keySemana]).forEach((keyDia) => {
      const diaIndex = Number(keyDia.substring(keyDia.length - 1))
      nuevaRutina[semanaIndex][diaIndex] = semanaRutina[keySemana][keyDia]
    })
  })

  return nuevaRutina
}
