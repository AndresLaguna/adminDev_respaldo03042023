export const calcularSegundos = (min: number, seg: number) => {
  if (typeof min !== 'number' || typeof seg !== 'number') return 0
  if (Number(min) < 0 || Number(seg) < 0) return 0
  return Number(min) * 60 + Number(seg)
}

export const calcularTiempoConSeg = (seg: number) => {
  if (typeof seg !== 'number') return { minutos: 0, segundos: 0 }
  if (Number(seg) < 0) return { minutos: 0, segundos: 0 }
  const minutos = Math.trunc(seg / 60)
  const segundos = Number(seg) % 60
  return { minutos, segundos }
}

export const calcularTiempo = (min: number, seg: number) => {
  if (typeof min !== 'number' || typeof seg !== 'number') return 0
  if (Number(min) < 0 || Number(seg) < 0) return 0
  const segs = calcularSegundos(min, seg)
  const { minutos, segundos } = calcularTiempoConSeg(segs)
  return { minutos, segundos }
}
