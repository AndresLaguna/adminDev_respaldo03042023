import { fechaFormatAMD } from './fechas'

export const mayorEdadFechaString = (fechaString: string) => {
  const fecha = fechaFormatAMD(fechaString)
  const fechaMinima = new Date(
    new Date().getFullYear() - 25,
    new Date().getMonth() + 1,
    new Date().getDay()
  )
  if (fecha <= fechaMinima) {
    return true
  } else {
    return false
  }
}
