import { database } from './config'
import { ref, onValue, set } from 'firebase/database'
import { ACTUALIZAR_DOCUMENTO_REALTIME } from './main'
import { administracionStore } from '../stores/administracionStore'
import { storeToRefs } from 'pinia'

export const LISTARTODOSLOSENTRENADORES = async () => {
  //Se importa la varible entrenadores del storeEntrenadores y se utiliza storeToRefs para no perder la reactividad del arreglo
  const { entrenadores } = storeToRefs(administracionStore())
  onValue(ref(database, 'users/'), (snapshot) => {
    const array: any[] = []
    const val = snapshot.val()
    Object.keys(val).forEach((element) => {
      if (val[element].rol == 'Entrenador') {
        const entre = val[element]
        entre.id = element
        array.push(entre)
      }
    })
    entrenadores.value = array
  })
}
export const LISTARTODOSLOSUSUARIOS = async () => {
  //Se importa la varible entrenadores del storeEntrenadores y se utiliza storeToRefs para no perder la reactividad del arreglo
  const { usuarios } = storeToRefs(administracionStore())
  onValue(ref(database, 'users/'), (snapshot) => {
    const array: any[] = []
    const val = snapshot.val()
    Object.keys(val).forEach((element) => {
      const entre = val[element]
      entre.id = element
      array.push(entre)
    })
    usuarios.value = array
  })
}
// export const LISTARTODOSLOSDEPORTES = async () => {
//   //Se importa la varible entrenadores del storeEntrenadores y se utiliza storeToRefs para no perder la reactividad del arreglo
//   const { deportes } = storeToRefs(administracionStore())
//   onValue(ref(database, 'users/'), (snapshot) => {
//     const array: any[] = []
//     const val = snapshot.val()
//     Object.keys(val).forEach((element) => {
//       const entre = val[element].categoria
//       if (entre != undefined && entre != '') {
//         array.push(entre)
//       }
//       //entre.id = element
//     })
//     deportes.value = array
//   })
// }

export const LISTARCIUDADES = async (pais: string) => {
  const { ciudades } = storeToRefs(administracionStore())
  onValue(ref(database, `Ciudades/${pais}`), (snapshot) => {
    const array: any[] = []
    const val = snapshot.val()
    Object.keys(val).forEach((element) => {
      const entre = val[element]
      array.push(entre)
    })
    ciudades.value = array
  })
}
export const CAMBIARESTADOENTRENADOR = (
  idEntrenador: string,
  estado: string,
  descripcion: string,
  categoria: string,
  estrellas: string
) => {
  ACTUALIZAR_DOCUMENTO_REALTIME('users', idEntrenador, {
    estado: estado,
    descripcion: descripcion,
    categoria: categoria,
    estrellas: estrellas,
  })
}

export const LISTARPAISES = async () => {
  const { paises } = storeToRefs(administracionStore())
  onValue(ref(database, 'Ciudades/'), (snapshot) => {
    const array: any[] = []
    const val = snapshot.val()
    Object.keys(val).forEach((element) => {
      array.push(element)
    })
    paises.value = array
  })
}

export const CREAR_CIUDAD = async (pais: string, ciudades: string[]) => {
  if (!pais || !ciudades) {
    throw new Error('Faltan parametros pais o ciudades')
  }
  const rutaBD = ref(database, `Ciudades/${pais}`)
  try {
    await set(rutaBD, ciudades)
  } catch (error) {
    console.log(error)
  }
}
export const ACTUALIZAR_CIUDAD = async (pais: string, ciudades: string[]) => {
  const rutaBD = ref(database, `Ciudades/${pais}`)
  try {
    await set(rutaBD, ciudades)
  } catch (error) {
    console.log(error)
  }
}
//Distancias
export const LISTARDISTANCIAS = async () => {
  const { distancias } = storeToRefs(administracionStore())
  onValue(ref(database, `prueba`), (snapshot) => {
    const val = snapshot.val()
    distancias.value = val
  })
}
export const ACTUALIZAR_DISTANCIA = async (distancias: any) => {
  const rutaBD = ref(database, `prueba`)
  try {
    await set(rutaBD, distancias)
  } catch (error) {
    console.log(error)
  }
}
