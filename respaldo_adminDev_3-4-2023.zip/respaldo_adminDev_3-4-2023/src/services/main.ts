import { database } from './config'
import { ref, get, set, push, remove, child, update } from 'firebase/database'

export const CREAR_DOCUMENTO_REALTIME = async (rutaDocumento: string, datos: any) =>
  await set(push(ref(database, rutaDocumento)), datos)

export const OBTENER_DOCUMENTO_REALTIME = async (
  rutaDocumento: string
): Promise<any | {}> => {
  const res = await get(child(ref(database), rutaDocumento))
  if (res.exists()) {
    return res.toJSON()
  }
  return {}
}

export const REEMPLAZAR_DOCUMENTO_REALTIME = async (
  rutaDocumento: string,
  idDocumento: string,
  documento: any
) => await set(ref(database, rutaDocumento + '/' + idDocumento), documento)

export const ACTUALIZAR_DOCUMENTO_REALTIME = async (
  rutaDocumento: string,
  idDocumento: string,
  documento: any
) => await update(ref(database, rutaDocumento + '/' + idDocumento), documento)

export const ACTUALIZAR_PLAN_REALTIME = async (idDocumento: string, documento: any) =>
  await update(ref(database, 'users/' + idDocumento + '/plan'), documento)

export const ELIMINAR_DOCUMENTO_REALTIME = async (
  rutaDocumento: string,
  idDocumento: string
) => await remove(child(ref(database), rutaDocumento + '/' + idDocumento))

export const LISTAR_DOCUMENTOS_REALTIME = async (rutaDocumentos: string) => {
  try {
    const datos: any[] = []
    const respuesta = await get(child(ref(database), rutaDocumentos))
    if (respuesta.exists()) {
      const val = respuesta.val()
      Object.keys(val).forEach((element) => {
        const documento = val[element]
        documento['id'] = element
        datos.push(documento)
      })
    }
    return datos
  } catch (err) {
    console.log(err)
    return []
  }
}

// obtener caracteres parciales de la tarjeta
export const sliceCard = async (card: string) => {
  const inicio = card.slice(0, 4)
  const final = card.slice(-4)
  const slice = inicio + '********' + final
  return slice
}
