import { IRutinaPersonalizada } from './models/Rutinas'
import {
  REEMPLAZAR_DOCUMENTO_REALTIME,
  CREAR_DOCUMENTO_REALTIME,
  ELIMINAR_DOCUMENTO_REALTIME,
  LISTAR_DOCUMENTOS_REALTIME,
} from './main'
import {
  CREAR_DOCUMENTO_FIRESTORE,
  CONSULTA_SIMPLE,
  ELIMINAR_DOCUMENTO_FIRESTORE,
  ACTUALIZAR_DOCUMENTO_FIRESTORE,
  CONSULTA_COMPUESTA,
} from './mainfirestore'

import { ObtenerSiguienteLunes, ObtenerLunesActual } from './funciones/fechas'
import { NEW_REVERT_SEMANA_RUTINA } from './funciones/rutina'

export const CREAR_PLAN_GRATUITO = async (planRutina: any) =>
  await CREAR_DOCUMENTO_REALTIME('planes_gratuitos', planRutina)

export const ACTUALIZAR_PLAN_GRATUITO = async (planRutina: any) => {
  const idPlan = planRutina.id
  delete planRutina.id
  return await REEMPLAZAR_DOCUMENTO_REALTIME('planes_gratuitos', idPlan, planRutina)
}

export const ELIMINAR_PLAN_GRATUITO = async (idRutina: string) =>
  await ELIMINAR_DOCUMENTO_REALTIME('planes_gratuitos', idRutina)

export const LISTAR_PLANES_GRATUITOS = async () =>
  await LISTAR_DOCUMENTOS_REALTIME('planes_gratuitos')

export const LISTAR_RUTINAS_GRATUITAS_ENTRENADOR = async (idEntrenador: string) => {
  const rutinas = await LISTAR_DOCUMENTOS_REALTIME('planes_gratuitos')
  return rutinas
    ? rutinas.filter((element) => element.id_entrenador === idEntrenador)
    : []
}

export const GUARDAR_RUTINA_DEPORTISTA = async (
  idDeportista: string,
  rutina: any,
  fecha: any
) => {
  await CREAR_DOCUMENTO_REALTIME(`rutinas/${idDeportista}`, {
    ...rutina,
    fecha,
  })
}

export const ACTUALIZAR_RUTINA_DEPORTISTA = async (
  idDeportista: string,
  idRutina: string,
  nuevaRutina: any
) => {
  await REEMPLAZAR_DOCUMENTO_REALTIME(
    'rutinas',
    `${idDeportista}/${idRutina}`,
    nuevaRutina
  )
}

export const ELIMINAR_RUTINA_DEPORTISTA = async (
  idDeportista: string,
  idRutina: string
) => {
  await ELIMINAR_DOCUMENTO_REALTIME('rutinas', `${idDeportista}/${idRutina}`)
}

export const ASIGNAR_SEMANA_COMODIN = async (idDeportista: string, fechaSemana: Date) => {
  const rutinaComodin: any = await LISTAR_RUTINAS_COMODIN()
  const plantGratis: any = NEW_REVERT_SEMANA_RUTINA(rutinaComodin[0].plan)
  const semana: any = plantGratis[0]

  const fecha = new Date(fechaSemana.getTime())

  const siguienteLunes = ObtenerSiguienteLunes(fecha)

  const idexDiaDomingo = 6
  const indexDiaSabado = 0
  while (fecha < siguienteLunes) {
    semana.forEach((dia: any, index: number) => {
      if (
        fecha.getDay() === indexDiaSabado &&
        dia.length !== 0 &&
        index === idexDiaDomingo
      ) {
        CREAR_RUTINA_PERSONALIZADA({
          ...dia,
          fecha,
          id_deportista: idDeportista,
          id_entrenador: 'QKDHvESUFrb4nPkCGAFuTdk74bo2',
        })
      } else if (dia.length !== indexDiaSabado && index === fecha.getDay() - 1) {
        CREAR_RUTINA_PERSONALIZADA({
          ...dia,
          fecha,
          id_deportista: idDeportista,
          id_entrenador: 'QKDHvESUFrb4nPkCGAFuTdk74bo2',
        })
      }
    })
    fecha.setDate(fecha.getDate() + 1)
  }
}

export const ASIGNAR_RUTINA_DESDE_BRONCE = async (
  idDeportista: string,
  rutinaBronce: any
) => {
  const { plan } = rutinaBronce
  const fechaActual = new Date(
    new Date().getFullYear(),
    new Date().getMonth(),
    new Date().getDate()
  )
  const indexLunes = 1

  let lunesSemana = ObtenerLunesActual(fechaActual)

  if (fechaActual.getDay() !== indexLunes) {
    await ASIGNAR_SEMANA_COMODIN(idDeportista, fechaActual)
    lunesSemana = ObtenerSiguienteLunes(fechaActual)
  }

  plan.forEach((semana: any) => {
    semana.forEach((dia: any, index: number) => {
      if (Object.keys(dia).length !== 0) {
        const fecha = new Date(lunesSemana.getTime())
        fecha.setDate(fecha.getDate() + index)
        CREAR_RUTINA_PERSONALIZADA({
          ...dia,
          fecha,
          id_deportista: idDeportista,
          id_entrenador: 'QKDHvESUFrb4nPkCGAFuTdk74bo2',
        })
      }
    })
    lunesSemana = ObtenerSiguienteLunes(lunesSemana)
  })
}

export const LISTAR_RUTINAS_COMODIN = async () =>
  await LISTAR_DOCUMENTOS_REALTIME('rutinas_comodin')

export const CREAR_RUTINA_COMODIN = async (datosRutina: any) =>
  await CREAR_DOCUMENTO_REALTIME('rutinas_comodin', datosRutina)

export const ACTUALIZAR_RUTINA_COMODIN = async (rutina: any) => {
  const idPlan = rutina.id
  delete rutina.id
  await REEMPLAZAR_DOCUMENTO_REALTIME('rutinas_comodin', idPlan, rutina)
}

export const ELIMINAR_RUTINA_COMODIN = async (idRutina: string) =>
  await ELIMINAR_DOCUMENTO_REALTIME('rutinas_comodin', idRutina)

//rutinas personalizadas
export const LISTAR_RUTINAS_DEPORTISTA = async (idDeportista: string) =>
  await CONSULTA_SIMPLE('rutinas', 'id_deportista', '==', idDeportista)

export const LISTAR_RUTINAS_DEPORTISTA_ENTRENADOR = async (
  idDeportista: string,
  idEntrenador: string
) =>
  await CONSULTA_COMPUESTA(
    'rutinas',
    'id_deportista',
    '==',
    idDeportista,
    'id_entrenador',
    '==',
    idEntrenador
  )

export const CREAR_RUTINA_PERSONALIZADA = async (rutina: IRutinaPersonalizada) =>
  await CREAR_DOCUMENTO_FIRESTORE('rutinas', rutina)

export const ACTUALIZAR_RUTINA_PERSONALIZADA = async (
  idRutina: string,
  rutina: Partial<IRutinaPersonalizada>
) => {
  const rutinaGuardar = { ...rutina }
  delete rutinaGuardar.id
  await ACTUALIZAR_DOCUMENTO_FIRESTORE('rutinas', idRutina, rutinaGuardar)
}

export const ELIMINAR_RUTINA_PERSONALIZADA = async (idRutina: string) =>
  await ELIMINAR_DOCUMENTO_FIRESTORE('rutinas', idRutina)
