import { calcularSegundos } from './../funciones/tiempos'
import { BloqueDistancia, BloqueTiempo } from './../models/Bloques'

export const validarBloqueTiempo = (bloque: Partial<BloqueTiempo>) => {
  if (
    !bloque.tipo ||
    bloque.intensidad === '' ||
    typeof bloque.duracion_min !== 'number' ||
    typeof bloque.duracion_seg !== 'number' ||
    calcularSegundos(bloque.duracion_min, bloque.duracion_seg) < 1 ||
    bloque.duracion_seg > 59
  ) {
    return false
  }
  return true
}

export const validarBloqueDistancia = (bloque: Partial<BloqueDistancia>) => {
  if (
    !bloque.tipo ||
    bloque.intensidad === '' ||
    bloque.tipo_medicion === '' ||
    typeof bloque.distancia !== 'number' ||
    bloque.distancia < 1
  ) {
    return false
  }
  return true
}
