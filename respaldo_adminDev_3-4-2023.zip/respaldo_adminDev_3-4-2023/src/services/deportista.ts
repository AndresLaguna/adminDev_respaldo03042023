import { database, auth } from './config'
import { ref, child, get, update } from 'firebase/database'
import { LISTAR } from './general'
import {
  EditarDatosDeportes,
  EditarDatosDeportista,
  EditarDatosMorfologia,
  EditarDatosObjetivos,
  EditarDatosSemicooper,
} from './models/Deportista'
import {
  ACTUALIZAR_DOCUMENTO_REALTIME,
  ACTUALIZAR_PLAN_REALTIME,
  OBTENER_DOCUMENTO_REALTIME,
} from './main'
// import Chart from 'chart.js/auto'

const dbRef = ref(database)

// obtener datos perfil deportista
export const getDatosDeportista = async (
  idDeportista: string
): Promise<EditarDatosDeportista> => OBTENER_DOCUMENTO_REALTIME(`users/${idDeportista}`)
// actualizar datos perfil deportista
export const updateDatosDeportista = async (
  idDeportista: string,
  datosDeportista: EditarDatosDeportista
): Promise<void> => ACTUALIZAR_DOCUMENTO_REALTIME('users', idDeportista, datosDeportista)

// obtener datos morfologia
export const getMorfologiaDeportista = async (
  idDeportista: string
): Promise<EditarDatosMorfologia> =>
  OBTENER_DOCUMENTO_REALTIME(`Morfologias/${idDeportista}`)

// actualizar datos morfologia
export const updateMorfologia = async (
  idDeportista: string,
  datosMorfologia: EditarDatosMorfologia
): Promise<void> =>
  ACTUALIZAR_DOCUMENTO_REALTIME('Morfologias', idDeportista, datosMorfologia)

// actualizar registro zonas
export const updateZonas = async (
  idDeportista: string,
  datosZonas: Object
): Promise<void> => {
  update(ref(database, 'users/' + idDeportista + '/zonas'), datosZonas)
}

// obtner zonas
export const getZonasDeportista = async (idDeportista: string) =>
  OBTENER_DOCUMENTO_REALTIME(`users/${idDeportista}/zonas`)

// obtener datos deportes
// export const getDeportes = async (idDeportista: string): Promise<EditarDatosDeportes> =>
//   OBTENER_DOCUMENTO_REALTIME(`Deportes/${idDeportista}`)
export const getDeportes = async (idDeportista: string) => {
  try {
    const res = await get(child(dbRef, `Deportes/${idDeportista}`))
    if (res.exists()) {
      const deportes = res.val()
      return deportes
    }
  } catch (error) {
    console.error(error)
  }
}

// actualizar datos deportes
export const updateDeportes = async (
  idDeportista: string,
  datosDeportes: EditarDatosDeportes
): Promise<void> => ACTUALIZAR_DOCUMENTO_REALTIME('Deportes', idDeportista, datosDeportes)

// obtener datos objetivos
// export const getObjetivos = async (idDeportista: string): Promise<EditarDatosObjetivos> =>
//   OBTENER_DOCUMENTO_REALTIME(`Objetivos/${idDeportista}`)

export const getObjetivos = async (idDeportista: string) => {
  try {
    const res = await get(child(dbRef, `Objetivos/${idDeportista}`))
    if (res.exists()) {
      const objetivos = res.val()
      return objetivos
    }
  } catch (error) {
    console.error(error)
  }
}

//actualizar datos objetivos
export const updateObjetivo = async (
  idDeportista: string,
  datosObjetivos: EditarDatosObjetivos
): Promise<void> =>
  ACTUALIZAR_DOCUMENTO_REALTIME('Objetivos', idDeportista, datosObjetivos)

// obtner datos semicooper
export const getSemicooper = async (idDeportista: string) => {
  // OBTENER_DOCUMENTO_REALTIME(`Semicooper/${idDeportista}`)
  try {
    const res = await get(child(dbRef, `Semicooper/${idDeportista}`))
    if (res.exists()) {
      const registros = res.val()
      return registros
    }
  } catch (error) {
    console.error(error)
  }
}
//actualizar datos semicooper
export const updateSemicooper = async (
  idDeportista: string,
  datosTest: EditarDatosSemicooper
): Promise<void> => {
  let test = ''
  const vo2max = ((22.4 * Number(datosTest.semicooper)) / 1000 - 11.3).toFixed(2)
  const testN = 6000 / Number(datosTest.semicooper)
  let tiempo = testN + ' min/km'
  if (testN.toString().length >= 3) {
    // 0.0
    const num = testN.toString().split('.')
    const minuto = num[0]
    const decimal = '.' + num[1].charAt(0) + num[1].charAt(1)
    const segundo = Math.round(Number(decimal) * 60)
    test = minuto + decimal
    tiempo = minuto + ':' + segundo + ' min/km'
  } else {
    test = testN.toString()
  }
  ACTUALIZAR_DOCUMENTO_REALTIME('Semicooper', idDeportista, {
    semicooper: datosTest.semicooper,
    VAM_decimal: test,
    VAM: tiempo,
    VO2Max: vo2max,
    marcas: datosTest.marcas,
  })
  const fecha = Date.now()
  update(ref(database, 'users/' + idDeportista + '/regVAM/' + fecha), {
    semicooper: datosTest.semicooper,
    VAM_decimal: test,
    VAM: tiempo,
    VO2Max: vo2max,
    marcas: datosTest.marcas,
  })
}

//actualizar datos en la ruta enviada con el idDeportista especificado
export const actualizarDato = async (
  ruta: string,
  idDeportista: string,
  datos: object
): Promise<void> => ACTUALIZAR_DOCUMENTO_REALTIME(ruta, idDeportista, datos)

export const updatePlan = async (idDeportista: string, plan: string): Promise<void> => {
  switch (plan) {
    case 'Plan Plata':
      await ACTUALIZAR_PLAN_REALTIME(idDeportista, {
        nombre: plan,
        solicitudes: 5,
      })
      break
    case 'Plan Oro':
      await ACTUALIZAR_PLAN_REALTIME(idDeportista, {
        nombre: plan,
        solicitudes: 10,
      })
      break
    case 'Plan Platino':
      await ACTUALIZAR_PLAN_REALTIME(idDeportista, {
        nombre: plan,
        solicitudes: 15,
      })
      break
    case 'Plan Diamante':
      await ACTUALIZAR_PLAN_REALTIME(idDeportista, {
        nombre: plan,
        solicitudes: 20,
      })
      break
    default:
      break
  }
}
//---------------------------------------------------------------------------
export const getEstadoBienvenida = async (user: string) => {
  try {
    const res = await get(child(dbRef, `users/${user}/bienvenida`))
    if (res.exists()) {
      return res.val()
    } else {
      return null
    }
  } catch (error) {
    console.error(error)
  }
}

export const getPlanes = async () => {
  return get(child(dbRef, `Planes/`))
    .then((snapshot) => {
      if (snapshot.exists()) {
        return snapshot.val()
      } else {
        console.log('No data available')
      }
    })
    .catch((error) => {
      console.error(error)
    })
}

// Obtener categorias de Deportes de la aplicacion
export const getCategorias = async () => {
  try {
    const res = await get(child(dbRef, `Categorias/`))
    if (res.exists()) {
      const deportes = Object.keys(res.val())
      return deportes
    }
  } catch (error) {
    console.error(error)
  }
}

// Obtener subcategorias de deportes
export const getSubCategorias = async (subCategoria: string) => {
  try {
    const res = await get(child(dbRef, `Categorias/${subCategoria}`))
    if (res.exists()) {
      return res.val()
    }
  } catch (error) {
    console.error(error)
  }
}

// Obtener paises
export const getPaises = async () => {
  try {
    const res = await get(child(dbRef, `Ciudades/`))
    if (res.exists()) {
      const paises = Object.keys(res.val())
      return paises
    }
  } catch (error) {
    console.error(error)
  }
}

// Obtener subcategorias de deportes
export const getCiudades = async (ciudad: string) => {
  try {
    const res = await get(child(dbRef, `Ciudades/${ciudad}`))
    if (res.exists()) {
      return res.val()
    }
  } catch (error) {
    console.error(error)
  }
}

export const getCiudadesOnObject = async () => {
  const datos: any = {}
  const res = await get(child(dbRef, 'Ciudades/'))
  if (res.exists()) {
    const val = res.val()
    Object.keys(val).forEach((element) => {
      datos[element] = val[element]
    })
  }
  return datos
}

//actualizar estado bienvenida formulario
export const updateBienvenida = (estadoBienvenida: any) => {
  const user = auth.currentUser
  if (user !== null) {
    const uid = user.uid

    update(ref(database, 'users/' + uid), estadoBienvenida)
  }
}

// Parametros (idDeportista): Identificador de usuario
//Retorno: objeto con el plan de usuario
export const OBTENER_PLAN_DEPORTISTA = async (idDeportista: any) => {
  let plan = {}
  const res = await get(child(dbRef, 'users/' + idDeportista + '/plan'))
  if (res.exists()) {
    plan = res.val()
  }
  return plan
}

// Funcion: Registrar plan bronce seleccionado en firebase
export const selectBronce = () => {
  const user = auth.currentUser
  if (user !== null) {
    const uid = user.uid
    update(ref(database, 'users/' + uid + '/plan/'), {
      nombre: 'Bronce',
      // estadoBienvenida: datosFormulario.estado,
    })
  }
}

export const LISTAR_RUTINAS = async () => {
  const rut = []
  const solicitudes = await LISTAR(`rutinas_bronce/`)
  console.log(solicitudes)
  solicitudes.forEach((soli: any) => {
    rut.push(soli)
  })
  return solicitudes
}

// let myChart

// Dibujar grafico de test semicooper
// export const chartTestDraw = async (userId: any) => {
//   const meses = []
//   const semicooper = []

//   get(child(dbRef, `users/${userId}/regVAM/`))
//     .then((snapshot) => {
//       if (snapshot.exists()) {
//         const obj = snapshot.val()

//         Object.keys(obj).forEach((element) => {
//           const fecha = new Date(parseInt(element))
//           const mesName = fecha.toLocaleString('es-CO', { month: 'long' })
//           meses.push(mesName)

//           let dato = obj[element].semicooper
//           dato = parseInt(dato)
//           semicooper.push(dato)
//         })

//         const ctx = document.getElementById('myChart')
//         myChart = new Chart(ctx, {
//           type: 'line',
//           data: {
//             labels: meses,
//             datasets: [
//               {
//                 label: 'Semicooper',
//                 data: semicooper,
//                 fill: false,
//                 borderColor: ['rgb(255, 99, 132, 1)'],
//                 tension: 0.1,
//               },
//             ],
//           },
//         })
//       } else {
//         console.log('No data available')
//       }
//     })
//     .catch((error) => {
//       console.error(error)
//     })
// }

// actualizar el grafico
// export const refreshChart = async (userId: any) => {
//   myChart.destroy()
//   chartTestDraw(userId)
// }
