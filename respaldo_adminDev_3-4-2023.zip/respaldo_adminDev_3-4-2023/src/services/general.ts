import { ACTUALIZAR_DOCUMENTO_REALTIME } from './main'
import { database } from './config'
import { ref, child, get, onValue } from 'firebase/database'

const dbRef = ref(database)

// obtener nombres de usuario
export const usernames = async () => {
  const nameusers: any[] = []
  onValue(ref(database, 'users/'), (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.val()
      Object.keys(data).forEach((element) => {
        const obj = data[element]
        // console.log(obj.nameUser);  //undeined & nameUser
        nameusers.push(obj.nameUser)
        // console.log(nameusers);
      })
    }
  })
  return nameusers
}

//obtener nombre de un solo usuario
export const getUserName = async (uid: string) => {
  let username = ''
  await get(child(dbRef, `users/${uid}`))
    .then((snapshot) => {
      if (snapshot.exists()) {
        const user = snapshot.val()
        username = user.nombres + ' ' + user.apellidos
      } else {
        console.log('No data available')
      }
    })
    .catch((error) => {
      console.error(error)
    })
  return username
}

export const CONVERTIR_RUTINA_BRONCE = async (rutinasBefore: any) => {
  const rutinas: any[] = []
  rutinasBefore.map((rutina: any) => {
    const nuevaRutina = rutina
    const nuevoPlan = []
    nuevaRutina.plan = []
    nuevoPlan.push(rutina.plan.semana1 || [])
    nuevoPlan.push(rutina.plan.semana2 || [])
    nuevoPlan.push(rutina.plan.semana3 || [])
    nuevoPlan.push(rutina.plan.semana4 || [])
    nuevaRutina.plan = nuevoPlan
    rutinas.push(nuevaRutina)
  })
  return rutinas
}

export const getRutinasBronce = async () => {
  return get(child(dbRef, `rutinas_bronce/`))
    .then((snapshot) => {
      if (snapshot.exists()) {
        return snapshot.val()
      }
    })
    .catch((error) => {
      console.error(error)
    })
}

// retornar fecha del dia anterior
export function getDateMax() {
  const today = new Date()
  const fecha = new Date(today)
  fecha.setDate(fecha.getDate() - 1)
  const anio = fecha.getFullYear()
  const dia = fecha.getDate()
  let diaFinal: string = ''
  let _mes = fecha.getMonth() //viene con valores de 0 al 11
  _mes = _mes + 1 //ahora lo tienes de 1 al 12
  let mes: string = ''

  if (_mes < 10) {
    //ahora le agregas un 0 para el formato date
    mes = '0' + _mes
  } else {
    mes = _mes.toString()
  }

  if (dia < 10) {
    //ahora le agregas un 0 para el formato date
    diaFinal = '0' + dia.toString()
  } else {
    diaFinal = dia.toString()
  }

  return anio + '-' + mes + '-' + diaFinal
}

// retornar fecha actual
export function getDateMaxToDay() {
  const fecha = new Date()
  const anio = fecha.getFullYear()
  const dia = fecha.getDate()
  let _mes = fecha.getMonth() //viene con valores de 0 al 11
  _mes = _mes + 1 //ahora lo tienes de 1 al 12
  let mes: string = ''
  let diaFinal: string = ''
  if (_mes < 10) {
    //ahora le agregas un 0 para el formato date
    mes = '0' + _mes
  } else {
    mes = _mes.toString()
  }

  if (dia < 10) {
    //ahora le agregas un 0 para el formato date
    diaFinal = '0' + dia
  } else {
    diaFinal = dia.toString()
  }
  return anio + '-' + mes + '-' + diaFinal
}

export const GET_DATOS_USUARIO = async (idUsuario: string) => {
  try {
    const respuesta = await get(child(dbRef, `users/${idUsuario}`))
    if (respuesta.exists()) {
      return { datosUsuario: respuesta.val(), idUsuario: respuesta.key }
    } else {
      return null
    }
  } catch (e) {
    console.log(e)
  }
}

export const LISTAR = async (nombreDatos: string) => {
  const datos: any = []
  return get(child(dbRef, nombreDatos))
    .then((snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val()
        Object.keys(val).forEach((element) => {
          const obj1 = val[element]
          obj1['id'] = element
          datos.push(obj1)
        })
        return datos
      }
    })
    .catch((error) => {
      console.error(error)
    })
}

export const ACTUALIZAR_FOTO = async (idUser: string, foto_url: string): Promise<void> =>
  ACTUALIZAR_DOCUMENTO_REALTIME('users', idUser, { foto_url })
