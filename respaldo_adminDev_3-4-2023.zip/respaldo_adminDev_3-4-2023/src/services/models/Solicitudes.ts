import { DeportesDisponibles } from './DeportesDisponibles'

export interface SolicitudMatch {
  id: string
  deporte: DeportesDisponibles
  estado: EstadoSolicitudes
  fecha_registro: number
  foto: string
  id_deportista: string
  id_entrenador: string
  nombres: string
}

export enum EstadoSolicitudes {
  PENDIENTE = 'Pendiente',
  APROBADO = 'Aprobado',
  CANCELADO = 'Cancelado',
  RECHAZADO = 'Rechazado',
}
