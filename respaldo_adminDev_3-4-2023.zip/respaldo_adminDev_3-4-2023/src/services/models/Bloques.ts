export interface BloqueDistancia {
  tipo: string
  tipo_medicion: string
  distancia: number
  intensidad: string
}

export interface BloqueTiempo {
  tipo: string
  duracion_min: number
  duracion_seg: number
  intensidad: string
}
