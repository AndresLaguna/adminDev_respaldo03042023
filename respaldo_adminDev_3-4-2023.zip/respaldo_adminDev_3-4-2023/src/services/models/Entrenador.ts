export interface Entrenador {
  id: string
  fecha_creacion: Date
  nombres: string
  apellidos: string
  identificacion: string
  email: string
  telefono: string
  fecha_nacimiento: number
  nombre_usuario: string
  descripcion: string
  calificacion: number
  rol: UsuarioRol
}

export enum UsuarioRol {
  APROBADO = 'Aprobado',
  PEDIENTE = 'Pendiente',
  CANCELADO = 'Cancelado',
}

export interface IDatosGeneralesEntrenador {
  genero: string
  pais: string
  ciudad: string
  direccion: string
  nombres: string
  apellidos: string
  descripcion: string
  nombre_usuario: string
  identificacion: string
  fecha_nacimiento: string
  telefono: string
}

export interface IDatosDeportivosEntrenador {
  acerca_de: string
  formacion_academica: string
  formacion_deportiva: string
  especialidad: string
  hitos: string
}
