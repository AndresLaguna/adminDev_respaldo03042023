export enum DeportesDisponibles {
  ATLETISMO = 'Atletismo',
  CICLISMO = 'Ciclismo',
  TRIATLON = 'Triatlon',
  FUERZA = 'Fuerza',
}

export const DEPORTES_DISPONIBLES = ['Atletismo', 'Ciclismo', 'Triatlon', 'Fuerza']
