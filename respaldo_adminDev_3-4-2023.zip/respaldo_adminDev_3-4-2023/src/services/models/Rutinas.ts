import { DeportesDisponibles } from './DeportesDisponibles'
export interface Rutina {
  descripcion: string
  tipo_esfuerzo: string
  tipo_medicion: string
  bloques: any[]
}

export interface IRutinaPersonalizada {
  id: string
  id_entrenador: string
  id_deportista: string
  descripcion: string
  fecha: Date
  tipo_esfuerzo: string
  tipo_medicion: string
  bloques: any[]
  comentarios: IComentarioRutina[]
}

export interface IComentarioRutina {
  rol: string
  id: number
  comentario: string
  autor: string
  fecha: number
}

export interface PlanRutina {
  id?: string
  id_entrenador: string
  deporte: DeportesDisponibles
  nombre_entrenador: string
  nombre_plan: string
  descripcion: string
  objetivos: string
  plan: Rutina[]
}

export interface ISemanaComodin {
  id?: string
  deporte_rutina: DeportesDisponibles
  vam: number
  plan: Rutina[]
}

export enum TipoEsfuerzoRutina {
  ZONA_RITMOS = 'Zona de Ritmos',
}
