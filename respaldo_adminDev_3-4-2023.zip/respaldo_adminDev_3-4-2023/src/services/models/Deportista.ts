export interface Deportista {
  fecha_creacion: Date
  id: string
  nombres: string
  apellidos: string
  identificacion: string
  email: string
  telefono: string
  fecha_nacimiento: number
  fecha_registro: string
  nameUser: string
  descripcion: string
  calificacion: number
  rol: UsuarioRol
}

export enum UsuarioRol {
  APROBADO = 'Aprobado',
  PEDIENTE = 'Pendiente',
  CANCELADO = 'Cancelado',
}

export interface EditarDatosDeportista {
  nombres: string
  apellidos: string
  email: string
  descripcion: string
  nameUser: string
  identificacion: string
  fecha_nacimiento: string
  fecha_registro: string
  telefono: string
  genero: string
  ciudad: string
  pais: string
  ciudadActual: string
  paisActual: string
  pictureName: string
  direccion: ''
}

export interface EditarDatosMorfologia {
  IMC: string
  FCmax: string
  FCmin: string
  FCprom: string
  distancia: string
  estatura: string
  fecha_brazo: string
  fecha_cintura: string
  fecha_hombros: string
  fecha_marca: string
  fecha_muslo: string
  fecha_pantorrilla: string
  fecha_pecho: string
  fecha_gluteos: string
  grasa: string
  medida_brazo: string
  medida_cintura: string
  medida_hombros: string
  medida_muslo: string
  medida_pantorrilla: string
  medida_pecho: string
  medida_gluteos: string
  peso: string
  ritmo: string
  somatipo: string
  tiempo_marca: string
}

export interface EditarDatosDeportes {
  resenia: string
  edad_deportiva: string
  lesiones: string[]
  enfermedades: string[]
  esfuerzo_trabajo: string
  nutricion: string
  otros: object
  otro: string
  pulsometro: string
  subjetivo: string
  sueño: string
  marcaPulsometro: string
}

export interface EditarDatosObjetivos {
  meta_deportiva: string[]
  dias_entrenamiento: object
}

export interface EditarDatosSemicooper {
  VAM: string
  VAM_decimal: string
  semicooper: string
  VO2Max: number
  marcas: string[]
}

export interface dataCard {
  numero: string
  anio: string
  mes: string
  cvc: string
}
