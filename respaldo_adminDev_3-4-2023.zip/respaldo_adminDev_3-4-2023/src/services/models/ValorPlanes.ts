export enum valorPlanes {
  PLATA = 10000,
  ORO = 10500,
  PLATINO = 11000,
  DIAMANTE = 11500,
}
