import { DeportesDisponibles } from './DeportesDisponibles'

export interface PlanEntrenamiento {
  id: string
  nombre: string
  deporte: DeportesDisponibles
  descripcion: string
  objetivos: string
  rutinas: any[]
}
