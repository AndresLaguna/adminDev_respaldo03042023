import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  sendPasswordResetEmail,
  getAuth,
  deleteUser,
} from 'firebase/auth'
import { ref, set, onValue, get, child } from 'firebase/database'

import { auth, database } from './config'
import { addPicture } from './managePictures'

const dbRef = ref(database)

export const CREARUSER = async (data: any) => {
  const crear = await createUserWithEmailAndPassword(auth, data.email, data.passwd)
    .then(async (userCredential: any) => {
      const user = userCredential.user
      if (data.perfil === 'Entrenador') {
        const ide = await getEntrenadoresID()
        set(ref(database, 'users/' + user.uid), {
          UserID: ide,
          estado: 'Pendiente',
          rol: 'Entrenador',
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          nombres: data.firstName,
          apellidos: data.lastName,
          nameUser: data.nameUser,
          deporte: 'Atletismo',
          genero: '',
          ciudad: '',
          pais: '',
          pasoBienvenida: 1,
          acerca_de: '',
          formacion_academica: '',
          formacion_deportiva: '',
          especialidad: '',
          hitos: '',
          direccion: '',
          nombre_usuario: '',
          identificacion: '',
          fecha_nacimiento: '',
          telefono: '',
        })
        if (data.picture) {
          addPicture(data.picture, user.uid)
        }
        // jQuery('#alert_sesion').removeClass('alert alert-danger')
        // jQuery('#alert_sesion').addClass('alert alert-success')
        // jQuery('#alert_sesion').html(
        //   "<i class='fa fa-warning'></i>Cuenta creada, ya puedes iniciar sesion"
        // )
        await addEntrenadoresID(ide)
        return user
      } else if (data.perfil == 'Deportista') {
        const idu = await getUsersID()
        set(ref(database, 'users/' + user.uid), {
          UserID: idu,
          estado: 'Pendiente',
          bienvenida: 7,
          pagoRecurrente: true,
          rol: 'Deportista',
          email: user.email,
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          telefono: '',
          direccion: '',
          identificacion: '',
          nombres: data.firstName,
          apellidos: data.lastName,
          nameUser: data.nameUser,
          genero: '',
          ciudad: '',
          ciudadActual: '',
          pais: '',
          paisActual: '',
          plan: {
            nombre: 'Bronce',
            solicitudes: 3,
            solicitudesEnviadas: 0,
            caracteres_chat: 0,
            video_min: 0,
            fotos: 0,
          },
        })

        set(ref(database, 'Morfologias/' + user.uid), {
          estatura: '',
          IMC: '',
          peso: '',
          grasa: '',
          FCmin: '60',
          FCmax: '190',
          somatipo: '',
          distancia: '',
          tiempo_marca: '',
          fecha_marca: '',
          ritmo: '',
          FCprom: '',
          fecha_cintura: '',
          medida_cintura: '',
          fecha_brazo: '',
          medida_brazo: '',
          fecha_muslo: '',
          medida_muslo: '',
          fecha_pantorrilla: '',
          medida_pantorrilla: '',
          fecha_pecho: '',
          medida_pecho: '',
          fecha_hombros: '',
          medida_hombros: '',
          fecha_gluteos: '',
          medida_gluteos: '',
        })

        set(ref(database, 'Deportes/' + user.uid), {
          edad_deportiva: '',
          subjetivo: '',
          otros: {
            ciclismo: true,
            natacion: true,
            triatlon: true,
            gimnasio: true,
            trail: true,
            otro: false,
          },
          otro: '',
          pulsometro: '',
          esfuerzo_trabajo: '',
          nutricion: '',
          sueño: '',
          lesiones: '',
          enfermedad_zona: '',
          enfermedad_tratamiento: '',
          enfermedad_fech_inicio: '',
          enfermedad_duracion: '',
          enfermedad_actual: '',
        })

        set(ref(database, 'Objetivos/' + user.uid), {
          meta_deportiva: '',
          dias_entrenamiento: {
            lunesM: true,
            lunesT: true,
            martesM: true,
            martesT: true,
            miercolesM: true,
            miercolesT: true,
            juevesM: true,
            juevesT: true,
            viernesM: true,
            viernesT: true,
            sabadoM: true,
            sabadoT: true,
            domingoM: true,
            domingoT: true,
          },
        })

        set(ref(database, 'Semicooper/' + user.uid), {
          semicooper: '1000',
          VAM_decimal: '',
          VAM: '',
          VO2Max: '',
          marcas: '',
        })
        if (data.picture) {
          addPicture(data.picture, user.uid)
        }

        await addUsersID(idu)
        return user
      } else {
        console.log('Debe seleccionar un rol')
        const user = auth.currentUser
        deleteUser(user)
          .then(() => {
            // User deleted.
            console.log('Cuenta no creada')
          })
          .catch((error) => {
            // An error ocurred
            // ...
            console.log(error)
          })
      }
      auth.signOut()
      return user.uid
    })
    .catch(async (error: any) => {
      const errorCode = error.code
      console.log('errorCode: ', errorCode)
      return errorCode
      // jQuery('#alert_sesion').addClass('alert alert-danger')
      // jQuery('#alert_sesion').html("<i class='fa fa-warning'></i>" + errorMessage)
    })

  return crear.uid
}

export const LOGIN_USER_PASSWD = async (userr: string, passwd: string) => {
  try {
    const res = await signInWithEmailAndPassword(auth, userr, passwd)
    return res.user.uid
  } catch (e) {
    console.log(e)
    // jQuery('#alert_sesion').addClass('alert alert-danger')
    // jQuery('#alert_sesion').html("<i class='fa fa-warning'></i>" + e.message)
  }
}

export const CREARUSERGOOGLE = async (checked: string) => {
  const provider = new GoogleAuthProvider()
  signInWithPopup(auth, provider)
    .then(async (result) => {
      // This gives you a Google Access Token. You can use it to access the Google API.
      //const credential = GoogleAuthProvider.credentialFromResult(result)
      //const token = credential.accessToken
      // The signed-in user info.
      const user = result.user
      // ...
      console.log('logueado')

      if (checked == 'Entrenador') {
        const ide = await getEntrenadoresID()
        set(ref(database, 'users/' + user.uid), {
          UserID: ide,
          estado: 'Pendiente',
          rol: 'Entrenador',
          email: user.email,
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          nombres: '',
          apellidos: '',
          categoria: 'Atletismo',
        })

        // jQuery('#alert_sesion').removeClass('alert alert-danger')
        // jQuery('#alert_sesion').addClass('alert alert-success')
        // jQuery('#alert_sesion').html(
        //   "<i class='fa fa-warning'></i>Cuenta creada, ya puedes iniciar sesion"
        // )
        await addEntrenadoresID(ide)
      } else if (checked == 'Deportista') {
        const idu = await getUsersID()
        set(ref(database, 'users/' + user.uid), {
          UserID: idu,
          estado: 'Pendiente',
          bienvenida: 7,
          pagoRecurrente: true,
          rol: 'Deportista',
          email: user.email,
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          nombres: '',
          apellidos: '',
          plan: {
            nombre: 'Bronce',
            solicitudes: 3,
            caracteres_chat: 0,
            video_min: 0,
            fotos: 0,
          },
        })

        set(ref(database, 'Morfologias/' + user.uid), {
          estatura: '',
          peso: '',
          grasa: '',
          FCmin: '60',
          FCmax: '190',
          somatipo: '',
          distancia: '',
          tiempo_marca: '',
          fecha_marca: '',
          ritmo: '',
          FCprom: '',
          fecha_cintura: '',
          medida_cintura: '',
          fecha_brazo: '',
          medida_brazo: '',
          fecha_muslo: '',
          medida_muslo: '',
          fecha_pantorrilla: '',
          medida_pantorrilla: '',
          fecha_pecho: '',
          medida_pecho: '',
          fecha_hombros: '',
          medida_hombros: '',
        })

        set(ref(database, 'Deportes/' + user.uid), {
          edad_deportiva: '',
          subjetivo: '',
          otros: '',
          pulsometro: '',
          esfuerzo_trabajo: '',
          nutricion: '',
          sueño: '',
          lesiones: '',
          enfermedad_zona: '',
          enfermedad_tratamiento: '',
          enfermedad_fech_inicio: '',
          enfermedad_duracion: '',
          enfermedad_actual: '',
        })

        set(ref(database, 'Objetivos/' + user.uid), {
          meta_deportiva: '',
          dias_entrenamiento: {
            lunesM: true,
            lunesT: true,
            martesM: true,
            martesT: true,
            miercolesM: true,
            miercolesT: true,
            juevesM: true,
            juevesT: true,
            viernesM: true,
            viernesT: true,
            sabadoM: true,
            sabadoT: true,
            domingoM: true,
            domingoT: true,
          },
        })

        set(ref(database, 'Semicooper/' + user.uid), {
          semicooper: '1000',
          VAM_decimal: '',
          VAM: '',
        })
        await addUsersID(idu)
      } else {
        console.log('Debe seleccionar un rol')
        // Eliminar la cuenta creada
        // const auth = getAuth();
        const user = auth.currentUser
        deleteUser(user)
          .then(() => {
            // User deleted.
            console.log('Cuenta no creada')
          })
          .catch((error: any) => {
            // An error ocurred
            // ...
            console.log(error)
          })
      }
    })
    .catch((error: any) => {
      // Handle Errors here.
      const errorCode = error.code
      const errorMessage = error.message
      // The email of the user's account used.
      //const email = error.email
      // The AuthCredential type that was used.
      //const credential = GoogleAuthProvider.credentialFromError(error)
      // ...
      console.log(errorCode, errorMessage)
    })
}

export const ASIGNAR_DATOS_USERGOOGLE = (rol: any) => {
  onAuthStateChanged(auth, async (user: any) => {
    if (user) {
      if (rol === 'Entrenador') {
        set(ref(database, 'users/' + user.uid), {
          estado: 'Pendiente',
          rol: 'Entrenador',
          email: user.email,
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          nombres: '',
          apellidos: '',
          deporte: 'Atletismo',
        })
        window.location.href = '/entrenador'
      } else if (rol == 'Deportista') {
        set(ref(database, 'users/' + user.uid), {
          estado: 'Pendiente',
          bienvenida: 6,
          rol: 'Deportista',
          email: user.email,
          fecha_registro: new Date().getTime(),
          estrellas: 0,
          descripcion: '',
          nombres: '',
          apellidos: '',
          plan: {
            nombre: 'Bronce',
            solicitudes: 1,
            solicitudesEnviadas: 0,
            caracteres_chat: 0,
            video_min: 0,
            fotos: 0,
          },
        })

        set(ref(database, 'Morfologias/' + user.uid), {
          estatura: '',
          peso: '',
          grasa: '',
          FCmin: '60',
          FCmax: '190',
          somatipo: '',
          distancia: '',
          tiempo_marca: '',
          fecha_marca: '',
          ritmo: '',
          FCprom: '',
          fecha_cintura: '',
          medida_cintura: '',
          fecha_brazo: '',
          medida_brazo: '',
          fecha_muslo: '',
          medida_muslo: '',
          fecha_pantorrilla: '',
          medida_pantorrilla: '',
          fecha_pecho: '',
          medida_pecho: '',
          fecha_hombros: '',
          medida_hombros: '',
        })

        set(ref(database, 'Deportes/' + user.uid), {
          edad_deportiva: '',
          subjetivo: '',
          otros: '',
          pulsometro: '',
          esfuerzo_trabajo: '',
          nutricion: '',
          sueño: '',
          lesion_zona: '',
          lesion_tratamiento: '',
          lesion_fech_inicio: '',
          lesion_duracion: '',
          lesion_actual: '',
          enfermedad_zona: '',
          enfermedad_tratamiento: '',
          enfermedad_fech_inicio: '',
          enfermedad_duracion: '',
          enfermedad_actual: '',
        })

        set(ref(database, 'Objetivos/' + user.uid), {
          meta_deportiva: '',
          dias_entrenamiento: {
            lunesM: true,
            lunesT: true,
            martesM: true,
            martesT: true,
            miercolesM: true,
            miercolesT: true,
            juevesM: true,
            juevesT: true,
            viernesM: true,
            viernesT: true,
            sabadoM: true,
            sabadoT: true,
            domingoM: true,
            domingoT: true,
          },
        })

        set(ref(database, 'Semicooper/' + user.uid), {
          semicooper: '1000',
          VAM_decimal: '',
          VAM: '',
        })
        window.location.href = '/deportista'
      }
    } else {
      window.location.href = '/login'
    }
  })
}
export const LOGINUSERGOOGLE = async () => {
  try {
    const provider = new GoogleAuthProvider()
    const result = await signInWithPopup(auth, provider)
    const user = await get(child(dbRef, `users/${result.user.uid}`))
    if (user.exists()) {
      const datosUsuario = user.val()
      if (datosUsuario.rol === 'Entrenador') {
        window.location.href = '/entrenador'
      } else if (datosUsuario.rol === 'Deportista') {
        window.location.href = '/deportista'
      }
    } else {
      window.location.href = '/seleccion'
    }
  } catch (error) {
    console.log(error)
  }
}

export const RECUPERARCONTRA = (email: string) => {
  console.log('recuperar')
  const auth1 = getAuth()

  sendPasswordResetEmail(auth1, email)
    .then(() => {
      // Password reset email sent!
      // ..
      console.log('cambio la contraseña')
      window.location.href = '/auth/login'
    })
    .catch((error) => {
      const errorCode = error.code
      const errorMessage = error.message
      // ..
      console.log(errorCode, errorMessage)
    })
}

export const USERCONECTADO = async () => {
  onAuthStateChanged(auth, async (user) => {
    if (await user) {
      const uid = await user.uid
      return uid
    } else {
      this.$router.push('login')
    }
  })
}

export const REDIRECT = () => {
  onAuthStateChanged(auth, (user) => {
    if (user) {
      const role = ref(database, 'users/' + user.uid + '/rol')
      onValue(role, (snapshot) => {
        const data = snapshot.val()
        if (data === 'Deportista') {
          window.location.replace('deportista')
        }
        if (data === 'Entrenador') {
          window.location.replace('entrenador')
        }
      })
    }
  })
}

//obtiene idactual de deportistas
const getUsersID = async () => {
  let id = ''
  return get(child(dbRef, `UsersID/`))
    .then((snapshot: any) => {
      if (snapshot.exists()) {
        id = snapshot.val()
        return id.IDactual
      } else {
        console.log('No data available')
      }
    })
    .catch((error: any) => {
      console.error(error)
    })
}

//guarda el nuevo valor idactual deportisas
const addUsersID = async (idu: number) => {
  idu = idu + 1
  set(ref(database, 'UsersID/'), {
    IDactual: idu,
  })
}

//obtiene idactual de entrenadores
const getEntrenadoresID = async () => {
  let id = ''
  return get(child(dbRef, `EntrenadoresID/`))
    .then((snapshot: any) => {
      if (snapshot.exists()) {
        id = snapshot.val()
        return id.IDactual
      } else {
        console.log('No data available')
      }
    })
    .catch((error: any) => {
      console.error(error)
    })
}

//guarda el nuevo valor idactual entrenadores
const addEntrenadoresID = async (idu: number) => {
  idu = idu + 1
  set(ref(database, 'EntrenadoresID/'), {
    IDactual: idu,
  })
}

export const ID_AUTH_USER = async () => auth.currentUser?.uid || ''

export const LOGOUT_USER = async () => auth.signOut()
