// var axios = require("axios");
import axios from 'axios'
import { ref, update } from 'firebase/database'
import { database } from './config'
import { getEstadoBienvenida, updateBienvenida } from './deportista'

const url = import.meta.env.VITE_APP_URL_BASE_EPAYCO

//----------OBTENER PLANES----------
export const getPlanesR = async () => {
  return axios.get(url + '/planes').then((data) => {
    // console.log(data.data)
    return data.data
  })
}

//----------METODO POST PRUEBA----------
export async function getTokenCard(datos: any) {
  return axios({
    method: 'post',
    url: url + '/card',
    data: datos,
  }).then(function (response) {
    return response.data
  })
}

export async function addClient(datos: any) {
  return axios({
    method: 'post',
    url: url + '/client',
    data: datos,
  }).then(function (response) {
    return response.data
  })
}

export async function subscription(datos: any) {
  return axios({
    method: 'post',
    url: url + '/subscription',
    data: datos,
  }).then(function (response) {
    return response.data
  })
}

export async function paySubscription(datos: any) {
  return axios({
    method: 'post',
    url: url + '/paySub',
    data: datos,
  }).then(function (response) {
    return response.data
  })
}

export const getToken = async () => {
  const settings = {
    url: 'https://apify.epayco.co/login',
    method: 'POST',
    timeout: 0,
    headers: {
      'Content-Type': 'application/json',
      Authorization:
        'Basic MGE4OTVjMzliZDRkMjZkNWVmOTEzMDY0OTQ3ODBlYjE6NjNlN2ViMTVmMTMyZmNiMjk1Mzg2OWZkZTExNDhkMGU=',
    },
  }
  $.ajax(settings).done(function (response: any) {
    console.log(response)
  })
}

export const getLink = async () => {
  const settings = {
    url: 'https://apify.epayco.co/collection/link/create',
    method: 'POST',
    timeout: 0,
    headers: {
      'Content-Type': 'application/json',
      Authorization:
        'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGlmeWVQYXljb0pXVCIsInN1YiI6NjM5OTYwLCJpYXQiOjE2NTQ4MDcxMTQsImV4cCI6MTY1NDgxMDcxNCwicmFuZCI6IjBjNGMyNjQzMjFmZDYyZmE3YjExMmQ0NzdiMzIxM2QwNjMwIiwicmVzIjpmYWxzZSwiaW5hIjpmYWxzZSwiZ3VpIjpudWxsfQ.edHnnAeGjReklULk_v54qMIR3YqdjpPoXfjE2wGluzI',
    },
    data: JSON.stringify({
      quantity: 1,
      onePayment: true,
      amount: '10000',
      currency: 'COP',
      id: 0,
      base: '0',
      description: 'Link de test',
      title: 'Link de cobro de prueba',
      typeSell: '1',
      tax: '0',
      email: 'felipe.mesa@payco.co',
    }),
  }
  $.ajax(settings).done(function (response: any) {
    console.log(response.data.routeLink)
  })
}

export const updatePlanUnico = async (idUsuario: string, datos: any) => {
  update(ref(database, 'Cobros/' + idUsuario + '/' + datos.x_transaction_date), {
    recibo: datos.x_transaction_id,
    bank_name: datos.x_bank_name,
    id_equipo: datos.x_customer_ip,
    plan: datos.x_description,
  })

  update(ref(database, 'users/' + idUsuario + '/plan'), {
    nombre: datos.x_description,
  })
  const estado = await getEstadoBienvenida(idUsuario)
  if (estado - 1 == 0) {
    updateBienvenida({ bienvenida: estado - 1 })
  }
}
