// import { storage, database, refDB, auth } from './config'
import { storage } from './config'
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage'
import { OBTENER_DOCUMENTO_REALTIME } from './main'
import { ACTUALIZAR_FOTO } from './general'

const imagen = {
  message: '',
  file: null,
  accept: false,
}

export const addPicture = async (file: File, uid: string) => {
  const filename = file.name
  const tipoArchivo = file.type

  let newName = ''
  let ext = ''

  //crear nuevo archivo para cambiar nombre
  const blob = file.slice(0, file.size, tipoArchivo)
  //guardar extension de archivo
  ext = filename.slice(((filename.lastIndexOf('.') - 1) >>> 0) + 2)
  // renombrar
  newName = uid + '.' + ext
  const storageRef = ref(storage, 'profilePictures/' + newName)

  const newFile = new File([blob], newName, { type: tipoArchivo })

  await uploadBytes(storageRef, newFile).then(() => {
    getDownloadURL(storageRef).then((res) => {
      ACTUALIZAR_FOTO(uid, res)
    })
  })
}

export const preview = async (event: any) => {
  const file = event.target.files[0]
  const tipoArchivo = file.type
  const sizeArchivo = file.size

  if (tipoArchivo === 'image/jpeg' || tipoArchivo === 'image/png') {
    if (sizeArchivo <= 2000000) {
      imagen.file = file
      imagen.message = 'loaded'
      imagen.accept = true
    } else {
      imagen.message = 'deniedSize'
      imagen.file = null
      imagen.accept = false
      return imagen
    }
  } else {
    imagen.message = 'denied'
    imagen.file = null
    imagen.accept = false
    return imagen
  }
  return imagen
}

export const Imagen = async (name: string) => {
  getDownloadURL(ref(storage, 'profilePictures/' + name))
    .then((url) => {
      const img = document.getElementById('ImageUser')
      if (img) {
        img.setAttribute('src', url)
      }
    })
    .catch((error) => {
      console.log('Usuario no tiene imagen de perfil: ', error)
    })
}

/* Retorna objeto con nombre
  de las imagenes disponibles
*/
export const getImagenesSignUp = async (): Promise<any> =>
  OBTENER_DOCUMENTO_REALTIME(`signUp/`)

// cargar imagen aleatoria en
// signUp de usuario
export const signUpImagen = async (
  root: string,
  imagen: string,
  movil: boolean = false
) => {
  getDownloadURL(ref(storage, root + '/' + imagen))
    .then((url) => {
      const img = document.getElementById('signUpImagen')
      if (img) {
        if (movil) {
          img.className = 'card-bg'
        }
        img.setAttribute('src', url)
      }
    })
    .catch((error) => {
      console.log(error)
    })
}
