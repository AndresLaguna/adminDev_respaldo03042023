import {
  addDoc,
  collection,
  doc,
  getDocs,
  query,
  setDoc,
  where,
  WhereFilterOp,
  deleteDoc,
} from 'firebase/firestore'
import { firestore } from './config'

export const CREAR_DOCUMENTO_FIRESTORE = async (
  rutaDocumento: string,
  datos: any
): Promise<string> => {
  const resultDb = await addDoc(collection(firestore, rutaDocumento), datos)
  return resultDb.id
}

export const CREAR_DOCUMENTO_RUTA_FIRESTORE = async (
  ruta: string,
  subruta: string,
  datos: any
): Promise<void> => await setDoc(doc(firestore, ruta, subruta), datos)

export const ACTUALIZAR_DOCUMENTO_FIRESTORE = async (
  colection: string,
  id: string,
  datos: any
) => await setDoc(doc(firestore, colection, id), datos)

export const ELIMINAR_DOCUMENTO_FIRESTORE = async (coleccion: string, id: string) =>
  await deleteDoc(doc(firestore, coleccion, id))

export const LISTAR_DOCUMENTOS = async (colection: string) =>
  await getDocs(collection(firestore, colection))

export const LISTAR_DOCUMENTOS_FIRESTORE = async (coleccion: string) => {
  const filas: any = []
  ;(await LISTAR_DOCUMENTOS(coleccion)).forEach((item) => {
    const obj: any = JSON.parse(JSON.stringify(item.data()))
    obj.id = item.id
    Object.values(obj).map(async (value: any, index: number) => {
      if (typeof value === 'object' && value) {
        const key: string = Object.keys(obj)[index].toString()
        obj[key] = value
      }
    })
    filas.push(obj)
  })
  return filas
}

export const CONSULTA_SIMPLE = async (
  coleccion: string,
  valor: string,
  condicion: WhereFilterOp,
  resultado: string
) => {
  const q = query(collection(firestore, coleccion), where(valor, condicion, resultado))
  const getConsulta = await getDocs(q)
  const datos: any = []
  getConsulta.forEach((doc) => {
    const obj: any = JSON.parse(JSON.stringify(doc.data()))
    obj.id = doc.id
    datos.push(obj)
  })
  return datos
}

export const CONSULTA_COMPUESTA = async (
  coleccion: string,
  valor1: string,
  condicion1: WhereFilterOp,
  resultado1: string,
  valor2: string,
  condicion2: WhereFilterOp,
  resultado2: string
) => {
  const q = query(
    collection(firestore, coleccion),
    where(valor1, condicion1, resultado1),
    where(valor2, condicion2, resultado2)
  )
  const getConsulta = await getDocs(q)
  const datos: any = []
  getConsulta.forEach((doc) => {
    const obj: any = JSON.parse(JSON.stringify(doc.data()))
    obj.id = doc.id
    datos.push(obj)
  })
  return datos
}
