import { SolicitudMatch, EstadoSolicitudes } from './models/Solicitudes'
import { database } from './config'
import { ref, push, set, get, child, remove, update } from 'firebase/database'
import { updateBienvenida } from './deportista'

const dbRef = ref(database)

export const LISTAR_ENTRENADORES_APROBADOS = async () => {
  const entrenadores: any[] = []
  const res = await get(child(dbRef, 'users/'))
  if (res.exists()) {
    const val = res.val()
    Object.keys(val).forEach((element) => {
      if (val[element].rol == 'Entrenador' && val[element].estado == 'Aprobado') {
        const entre = val[element]
        entre.id = element
        entrenadores.push(entre)
      }
    })
  }
  return entrenadores
}

export const LISTAR_PLAN_DEPORTISTA = async (idDeportista: string) => {
  let plan = {}
  const res = await get(child(dbRef, 'users/' + idDeportista + '/plan'))
  if (res.exists()) {
    const val = await res.val()
    plan = val
  }
  return plan
}

export const GET_SOLICITUDES_DEPORTISTA = (idDeportista: any, solicitudes: any) => {
  const solicitudesDisponibles: any[] = []
  Object.keys(solicitudes).forEach((element) => {
    if (solicitudes[element].id_deportista === idDeportista) {
      const sol = solicitudes[element]
      sol['id'] = element
      solicitudesDisponibles.push(sol)
    }
  })
  return solicitudesDisponibles
}

export const VERIFICAR_MATCH = (idDeportista: any, solicitudes: any) => {
  let estado = false
  let entrenador_id = ''
  Object.keys(solicitudes).forEach((element) => {
    if (
      solicitudes[element].id_deportista === idDeportista &&
      solicitudes[element].estado === EstadoSolicitudes.APROBADO
    ) {
      entrenador_id = solicitudes[element].id_entrenador
      estado = true
    }
  })
  return { match: estado, entrenador: entrenador_id }
}

export const GET_SOLICITUDES_DESDE_ENTRENADOR = async (
  idEntrenador: string,
  solicitudes: any
) => {
  const solicitudesDisponibles: any[] = []
  Object.keys(solicitudes).forEach((element) => {
    if (
      solicitudes[element].id_entrenador === idEntrenador &&
      solicitudes[element].estado === EstadoSolicitudes.PENDIENTE
    ) {
      const sol = solicitudes[element]
      sol['id'] = element
      solicitudesDisponibles.push(sol)
    }
  })
  return solicitudesDisponibles
}

export const GET_SOLICITUDES_APROBADAS_DESDE_ENTRENADOR = async (
  idEntrenador: string,
  solicitudes: any
) => {
  const solicitudesDisponibles: any[] = []
  Object.keys(solicitudes).forEach((element) => {
    if (
      solicitudes[element].id_entrenador === idEntrenador &&
      solicitudes[element].estado === EstadoSolicitudes.APROBADO
    ) {
      const sol = solicitudes[element]
      sol['id'] = element
      solicitudesDisponibles.push(sol)
    }
  })
  return solicitudesDisponibles
}

export const GET_MATCH_TOTAL = async (idEntrenador: string, solicitudes: any) => {
  let contador = 0
  Object.keys(solicitudes).forEach((element) => {
    if (
      solicitudes[element].id_entrenador === idEntrenador &&
      solicitudes[element].estado === EstadoSolicitudes.APROBADO
    ) {
      contador = contador + 1
    }
  })
  return contador
}

export const ENVIAR_INVITACION = async (
  datosDeportista: any,
  datosEntrenador: any,
  solicitudEnviada: any,
  newBienvenida: any
) => {
  const solicitud: Partial<SolicitudMatch> = {
    id_deportista: datosDeportista.id,
    id_entrenador: datosEntrenador.id,
    nombres: datosDeportista.nombres + ' ' + datosDeportista.apellidos,
    foto: '',
    deporte: datosEntrenador.deporte,
    estado: EstadoSolicitudes.PENDIENTE,
    fecha_registro: new Date().getTime(),
  }
  await set(push(ref(database, 'solicitudes')), solicitud)
  await update(ref(database, 'users/' + datosDeportista.id + '/plan'), {
    solicitudesEnviadas: solicitudEnviada,
  })
  updateBienvenida({ bienvenida: newBienvenida })
}

export const CAMBIAR_ESTADO_INVITACION = async (
  invitacion: Partial<SolicitudMatch>,
  estado: EstadoSolicitudes
) => {
  const idInvitacion = invitacion.id
  delete invitacion.id
  invitacion.fecha_registro = new Date().getTime()
  invitacion.estado = estado
  await set(ref(database, 'solicitudes/' + idInvitacion), invitacion)
}

export const LISTAR_INVITACIONES = async (tipo: string, idTipo: string) => {
  let campo = ''
  tipo === 'Entrenador' ? (campo = 'id_entrenador') : (campo = 'id_deportista')
  const invitaciones: any[] = []
  const res = await get(child(dbRef, 'solicitudes'))
  if (res.exists()) {
    const val = res.val()
    Object.keys(val).forEach((element) => {
      if (val[element][campo] == idTipo) {
        const sol = val[element]
        sol['id'] = element
        invitaciones.push(sol)
      }
    })
  }
  return invitaciones
}

export const ELIMINAR_INVITACION = async (
  id_invitacion: any,
  UID: any,
  contadorSolicitud: any
) => {
  await remove(child(dbRef, 'solicitudes/' + id_invitacion))
  await update(ref(database, 'users/' + UID + '/plan'), {
    solicitudesEnviadas: contadorSolicitud,
  })
}
