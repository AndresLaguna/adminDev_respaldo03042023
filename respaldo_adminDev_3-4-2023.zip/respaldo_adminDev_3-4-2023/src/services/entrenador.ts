import {
  IDatosDeportivosEntrenador,
  IDatosGeneralesEntrenador,
} from './models/Entrenador'
import { database } from './config'
import { ref, child, get } from 'firebase/database'
import { OBTENER_DOCUMENTO_REALTIME, ACTUALIZAR_DOCUMENTO_REALTIME } from './main'

export const LISTARENTRENADORES = async () => {
  const dbRef = ref(database)
  const entrenadores: any[] = []
  return get(child(dbRef, 'users/'))
    .then((snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val()
        Object.keys(val).forEach((element) => {
          if (val[element].rol == 'Entrenador' && val[element].estado == 'Aprobado') {
            const entre = val[element]
            entre.id = element
            entrenadores.push(entre)
          }
        })
      }
      return entrenadores
    })
    .catch((error) => {
      console.error(error)
    })
}

export const GET_ENTRENADORES_VALIDOS = (entrenadores: any) => {
  const entrenadoresValidos: any[] = []
  Object.keys(entrenadores).forEach((element) => {
    if (
      entrenadores[element].rol == 'Entrenador' &&
      entrenadores[element].estado == 'Aprobado'
    ) {
      const entre = entrenadores[element]
      entre.id = element
      entrenadoresValidos.push(entre)
    }
  })
  return entrenadoresValidos
}

export const GET_DATOS_GENERAL_ENTRENADOR = async (
  idEntrenador: string
): Promise<IDatosGeneralesEntrenador> =>
  OBTENER_DOCUMENTO_REALTIME(`users/${idEntrenador}`)

export const ACTUALIZAR_DATOS_GENERAL_ENTRENADOR = async (
  idEntrenador: string,
  datosGeneral: IDatosGeneralesEntrenador
): Promise<void> => ACTUALIZAR_DOCUMENTO_REALTIME('users', idEntrenador, datosGeneral)

export const GET_DATOS_DEPORTE_ENTRENADOR = async (
  idEntrenador: string
): Promise<IDatosDeportivosEntrenador> =>
  OBTENER_DOCUMENTO_REALTIME(`users/${idEntrenador}`)

export const ACTUALIZAR_DATOS_DEPORTE_ENTRENADOR = async (
  idEntrenador: string,
  datosGeneral: IDatosDeportivosEntrenador
): Promise<void> => ACTUALIZAR_DOCUMENTO_REALTIME('users', idEntrenador, datosGeneral)

export const ACTUALIZAR_PASO_BIENVENIDA = async (
  idEntrenador: string,
  pasoBienvenida: number
): Promise<void> =>
  ACTUALIZAR_DOCUMENTO_REALTIME('users', idEntrenador, { pasoBienvenida })
