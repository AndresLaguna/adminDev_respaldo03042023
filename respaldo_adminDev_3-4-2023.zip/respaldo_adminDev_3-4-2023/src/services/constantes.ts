export enum ENOpcionesCrud {
  CREAR = 'crear',
  EDITAR = 'editar',
  VER = 'ver',
  ELIMINAR = 'eliminar',
}

export enum ENOpcionesCru {
  CREAR = 'crear',
  EDITAR = 'editar',
  VER = 'ver',
}

export const nombreDiasSemana = [
  'Lunes',
  'Martes',
  'Miercoles',
  'Jueves',
  'Viernes',
  'Sabado',
  'Domingo',
]
