module.exports = {
  semi: false,
  singleQuote: true,
  printWidth: 90,
}
